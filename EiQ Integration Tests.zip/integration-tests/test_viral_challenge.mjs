#!/usr/bin/env node

/**
 * EIQ™ Viral Challenge Testing Module
 * Tests 15-second viral challenge with leaderboard integration
 */

const BASE_URL = process.env.BASE_URL || 'http://localhost:5000';

async function apiRequest(method, path, body, headers = {}) {
  const res = await fetch(`${BASE_URL}${path}`, {
    method,
    headers: { 'Content-Type': 'application/json', ...headers },
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  return { status: res.status, data, success: res.ok };
}

export async function runViralChallenge() {
  console.log('⚡ Testing 15-Second Viral Challenge...');
  
  const outcome = {
    status: 0,
    success: false,
    questionsReceived: 0,
    leaderboardAccess: false,
    instantScoring: false,
    timestamp: new Date().toISOString()
  };
  
  try {
    // Start viral challenge with actual endpoint
    const res = await apiRequest('POST', '/api/viral-challenge/start', {
      challengeType: '15_second',
      difficulty: 'medium'
    });
    
    if (res.status === 200 || res.status === 201) {
      outcome.status = res.status;
      outcome.success = true;
      
      const sessionId = res.data.sessionId || res.data.id;
      const questions = res.data.questions || [];
      outcome.questionsReceived = questions.length;
      
      if (sessionId && questions.length > 0) {
        // Submit answers quickly (15-second challenge simulation)
        const answers = questions.map(q => ({
          questionId: q.id,
          selectedAnswer: Math.floor(Math.random() * (q.options?.length || 4)),
          timeSpent: 1 + Math.random() * 3
        }));
        
        const submitRes = await apiRequest('POST', '/api/viral-challenge/submit', {
          sessionId: sessionId,
          answers: answers
        });
        
        if (submitRes.success) {
          outcome.instantScoring = !!submitRes.data?.score;
          
          // Check leaderboard access
          const leaderboardRes = await apiRequest('GET', '/api/viral-challenge/leaderboard');
          outcome.leaderboardAccess = leaderboardRes.success;
        }
      }
    } else {
      outcome.status = res.status;
      outcome.error = `Challenge did not start: ${res.status}`;
    }
    
  } catch (err) {
    outcome.status = 500;
    outcome.error = err.message;
  }
  
  return outcome;
}

// Allow direct execution for testing
if (import.meta.url === `file://${process.argv[1]}`) {
  runViralChallenge().then(result => {
    console.log('Viral Challenge Test Result:', JSON.stringify(result, null, 2));
  });
}