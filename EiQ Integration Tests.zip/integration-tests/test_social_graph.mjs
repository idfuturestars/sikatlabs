#!/usr/bin/env node

/**
 * EIQ™ Social Graph & Collaboration Testing Module
 * Tests cohort creation, study groups, and collaborative features
 */

const BASE_URL = process.env.BASE_URL || 'http://localhost:5000';

async function apiRequest(method, path, body, headers = {}) {
  const res = await fetch(`${BASE_URL}${path}`, {
    method,
    headers: { 'Content-Type': 'application/json', ...headers },
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  return { status: res.status, data, success: res.ok };
}

export async function runSocialGraph() {
  console.log('🌐 Testing Social Graph & Collaboration...');
  
  try {
    // Test cohort/study room creation
    const roomRes = await apiRequest('POST', '/api/social-graph/create-room', {
      title: 'Integration Test Study Cohort',
      description: 'Collaborative learning space for integration testing',
      maxParticipants: 10,
      type: 'study_group',
      privacy: 'public'
    });
    
    if (!roomRes.success) {
      return {
        status: roomRes.status,
        success: false,
        error: `Failed to create study room: ${roomRes.status}`
      };
    }
    
    const roomId = roomRes.data.roomId || roomRes.data.id;
    let inviteSent = false;
    let groupChallengeCreated = false;
    let collaborationEnabled = false;
    
    // Test social features if room was created successfully
    if (roomId) {
      // Test invite functionality
      const inviteRes = await apiRequest('POST', '/api/social-graph/invite', {
        roomId: roomId,
        inviteeEmail: 'testcollaborator@example.com',
        message: 'Join our study cohort for collaborative learning!'
      });
      inviteSent = inviteRes.success;
      
      // Test group challenge creation
      const groupRes = await apiRequest('POST', '/api/social-graph/group-challenge', {
        roomId: roomId,
        challengeType: 'collaborative_assessment',
        difficulty: 'medium',
        timeLimit: 900 // 15 minutes
      });
      groupChallengeCreated = groupRes.success;
      
      // Test collaboration features
      const collabRes = await apiRequest('GET', `/api/social-graph/room/${roomId}/features`);
      collaborationEnabled = collabRes.success && collabRes.data.features?.includes('collaboration');
    }
    
    // Test cohort listing
    const cohortListRes = await apiRequest('GET', '/api/social-graph/cohorts');
    const cohortsAccessible = cohortListRes.success;
    
    return {
      status: roomRes.status,
      success: roomRes.success,
      roomId: roomId,
      roomCreated: !!roomId,
      inviteSent: inviteSent,
      groupChallengeCreated: groupChallengeCreated,
      collaborationEnabled: collaborationEnabled,
      cohortsAccessible: cohortsAccessible,
      socialFeatures: inviteSent && groupChallengeCreated,
      communityEngagement: collaborationEnabled && cohortsAccessible,
      timestamp: new Date().toISOString()
    };
    
  } catch (err) {
    return {
      status: 500,
      success: false,
      error: err.message
    };
  }
}

// Allow direct execution for testing
if (import.meta.url === `file://${process.argv[1]}`) {
  runSocialGraph().then(result => {
    console.log('Social Graph Test Result:', JSON.stringify(result, null, 2));
  });
}