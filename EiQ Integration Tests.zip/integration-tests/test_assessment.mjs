#!/usr/bin/env node

/**
 * EIQ™ Assessment Flow Testing Module
 * Tests adaptive assessment functionality with real endpoints
 */

const BASE_URL = process.env.BASE_URL || 'http://localhost:5000';

async function apiRequest(method, path, body, headers = {}) {
  const res = await fetch(`${BASE_URL}${path}`, {
    method,
    headers: { 'Content-Type': 'application/json', ...headers },
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  return { status: res.status, data, success: res.ok };
}

export async function runFullAssessment() {
  console.log('🧠 Testing Full Adaptive Assessment Flow...');
  
  const outcome = { 
    status: 0, 
    success: false,
    sessionCreated: false, 
    questionReceived: false, 
    adaptive: false, 
    score: null,
    scoreInRange: false,
    timestamp: new Date().toISOString()
  };
  
  try {
    // Start assessment using actual EIQ endpoint with test API key
    const start = await apiRequest('POST', '/api/eiq/assess', {}, {
      'x-api-key': 'test-key-validation'
    });
    
    if (start.status === 200 || start.status === 201) {
      outcome.status = start.status;
      outcome.success = true;
      outcome.sessionCreated = true;
      
      // Check if we received a question immediately in the response
      if (start.data.currentQuestion) {
        outcome.questionReceived = true;
        outcome.adaptive = true;
        console.log('✅ Received question:', start.data.currentQuestion.question.substring(0, 50) + '...');
      }
      
      const assessId = start.data.id || start.data.assessmentId || start.data.sessionId;
      
      if (assessId && !outcome.questionReceived) {
        // Poll assessment status up to 10 times if no question received initially
        for (let i = 0; i < 10; i++) {
          const statusRes = await apiRequest('GET', `/api/eiq/assess/${assessId}`, null, {
            'x-api-key': 'test-key-validation'
          });
          
          if (statusRes.data && (statusRes.data.questions || statusRes.data.currentQuestion)) {
            outcome.questionReceived = true;
            outcome.adaptive = statusRes.data.adaptive || true;
          }
          
          if (statusRes.data && statusRes.data.complete) {
            outcome.score = statusRes.data.score;
            outcome.scoreInRange = outcome.score >= 300 && outcome.score <= 850;
            break;
          }
          
          // Wait 1 second between polls
          await new Promise((r) => setTimeout(r, 1000));
        }
      }
    } else {
      outcome.status = start.status;
      outcome.error = `Failed to start assessment: ${start.status}`;
    }
    
  } catch (err) {
    outcome.status = 500;
    outcome.error = err.message;
  }
  
  return outcome;
}

// Allow direct execution for testing
if (import.meta.url === `file://${process.argv[1]}`) {
  runFullAssessment().then(result => {
    console.log('Assessment Test Result:', JSON.stringify(result, null, 2));
  });
}