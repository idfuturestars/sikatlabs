#!/usr/bin/env node

/**
 * EIQ™ Admin Analytics Testing Module
 * Tests dashboard metrics, user statistics, and analytics infrastructure
 */

const BASE_URL = process.env.BASE_URL || 'http://localhost:5000';

async function apiRequest(method, path, body, headers = {}) {
  const res = await fetch(`${BASE_URL}${path}`, {
    method,
    headers: { 'Content-Type': 'application/json', ...headers },
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  return { status: res.status, data, success: res.ok };
}

export async function runAdminAnalytics() {
  console.log('📊 Testing Admin & Analytics Dashboards...');
  
  try {
    // Test core analytics endpoints
    const metricsRes = await apiRequest('GET', '/api/analytics/dashboard-metrics');
    const userStatsRes = await apiRequest('GET', '/api/analytics/user-statistics');
    const revenueRes = await apiRequest('GET', '/api/analytics/revenue-projections');
    const eiqDistributionRes = await apiRequest('GET', '/api/analytics/eiq-distribution');
    
    // Test real-time analytics
    const realtimeRes = await apiRequest('GET', '/api/analytics/realtime');
    const performanceRes = await apiRequest('GET', '/api/analytics/performance-metrics');
    
    // Collect successful data responses
    const dashboardData = {
      metrics: metricsRes.success ? metricsRes.data : null,
      userStats: userStatsRes.success ? userStatsRes.data : null,
      revenue: revenueRes.success ? revenueRes.data : null,
      eiqDistribution: eiqDistributionRes.success ? eiqDistributionRes.data : null,
      realtime: realtimeRes.success ? realtimeRes.data : null,
      performance: performanceRes.success ? performanceRes.data : null
    };
    
    // Calculate analytics completeness
    const endpointResults = [
      metricsRes.success,
      userStatsRes.success,
      revenueRes.success,
      eiqDistributionRes.success,
      realtimeRes.success,
      performanceRes.success
    ];
    
    const successfulEndpoints = endpointResults.filter(Boolean).length;
    const totalEndpoints = endpointResults.length;
    
    // Verify data completeness
    const hasUserCount = !!(dashboardData.userStats?.totalUsers || dashboardData.metrics?.totalUsers);
    const hasEiqDistribution = !!(dashboardData.eiqDistribution?.distribution || dashboardData.metrics?.eiqDistribution);
    const hasRevenueData = !!(dashboardData.revenue?.projections || dashboardData.revenue?.currentRevenue);
    const hasRealtimeData = !!(dashboardData.realtime?.activeUsers || dashboardData.performance?.activeUsers);
    
    return {
      status: metricsRes.status,
      success: successfulEndpoints >= 4, // Require 2/3 success rate
      endpointsWorking: `${successfulEndpoints}/${totalEndpoints}`,
      metricsReceived: metricsRes.success,
      userStatsReceived: userStatsRes.success,
      revenueDataReceived: revenueRes.success,
      eiqDistributionReceived: eiqDistributionRes.success,
      realtimeAnalytics: realtimeRes.success,
      performanceMetrics: performanceRes.success,
      userCount: dashboardData.userStats?.totalUsers || dashboardData.metrics?.totalUsers || null,
      eiqDistribution: hasEiqDistribution,
      revenueProjections: hasRevenueData,
      activeUsers: dashboardData.realtime?.activeUsers || dashboardData.performance?.activeUsers || null,
      dataComplete: hasUserCount && hasEiqDistribution,
      analyticsInfrastructure: successfulEndpoints > 0,
      dashboardReady: successfulEndpoints >= 3,
      timestamp: new Date().toISOString()
    };
    
  } catch (err) {
    return {
      status: 500,
      success: false,
      error: err.message
    };
  }
}

// Allow direct execution for testing
if (import.meta.url === `file://${process.argv[1]}`) {
  runAdminAnalytics().then(result => {
    console.log('Admin Analytics Test Result:', JSON.stringify(result, null, 2));
  });
}