#!/usr/bin/env node

/**
 * EIQ™ Platform Modular Integration Test Framework
 * Comprehensive testing with focused, reusable modules
 * Generates detailed JSON validation results
 */

import fs from 'fs';
import { runFullAssessment } from './test_assessment.mjs';
import { runViralChallenge } from './test_viral_challenge.mjs';
import { runRoleModelMatching } from './test_role_model_matching.mjs';
import { runSocialGraph } from './test_social_graph.mjs';
import { runDeveloperAPI } from './test_developer_api.mjs';
import { runMetaLearning } from './test_meta_learning.mjs';
import { runAdminAnalytics } from './test_admin_analytics.mjs';
import { runSecurityChecks } from './test_security.mjs';

const results = {};
const startTime = Date.now();

console.log('🚀 Starting EIQ™ Platform Modular Integration Testing...');
console.log('=' .repeat(60));

async function main() {
  try {
    // Execute all test modules with detailed logging
    console.log('📋 Running 8 comprehensive test modules...\n');
    
    console.log('1/8 - Assessment Flow Testing...');
    results.assessmentFlow = await runFullAssessment();
    
    console.log('2/8 - Viral Challenge Testing...');
    results.challengeFlow = await runViralChallenge();
    
    console.log('3/8 - Role Model Matching Testing...');
    results.roleModelMatching = await runRoleModelMatching();
    
    console.log('4/8 - Social Graph Testing...');
    results.socialGraph = await runSocialGraph();
    
    console.log('5/8 - Developer API Testing...');
    results.developerAPI = await runDeveloperAPI();
    
    console.log('6/8 - Meta-Learning Testing...');
    results.metaLearning = await runMetaLearning();
    
    console.log('7/8 - Admin Analytics Testing...');
    results.adminDashboard = await runAdminAnalytics();
    
    console.log('8/8 - Security & Compliance Testing...');
    results.securityChecks = await runSecurityChecks();
    
    // Calculate summary metrics
    const testModules = Object.keys(results);
    const passedModules = testModules.filter(module => results[module].success);
    const successRate = Math.round((passedModules.length / testModules.length) * 100);
    const duration = Date.now() - startTime;
    
    // Add comprehensive summary
    results.summary = {
      totalModules: testModules.length,
      passedModules: passedModules.length,
      failedModules: testModules.length - passedModules.length,
      successRate: `${successRate}%`,
      duration: `${duration}ms`,
      timestamp: new Date().toISOString(),
      allPassed: passedModules.length === testModules.length,
      passedTests: passedModules,
      failedTests: testModules.filter(module => !results[module].success)
    };
    
    // Ensure output directory exists
    fs.mkdirSync('../feature-validation', { recursive: true });
    
    // Save detailed results
    fs.writeFileSync(
      '../feature-validation/custom_feature_validation.json',
      JSON.stringify(results, null, 2)
    );
    
    // Display final results
    console.log('\n' + '=' .repeat(60));
    console.log('🎯 MODULAR INTEGRATION TEST RESULTS');
    console.log('=' .repeat(60));
    console.log(`✅ Passed Modules: ${passedModules.length}/${testModules.length}`);
    console.log(`📊 Success Rate: ${successRate}%`);
    console.log(`⏱️  Duration: ${duration}ms`);
    console.log(`💾 Results saved to: ../feature-validation/custom_feature_validation.json`);
    
    if (passedModules.length === testModules.length) {
      console.log('\n🎉 ALL MODULES PASSED - PLATFORM READY FOR DEPLOYMENT');
    } else {
      console.log('\n⚠️  Some modules failed - Review results for details');
      console.log(`❌ Failed: ${results.summary.failedTests.join(', ')}`);
    }
    
    console.log('=' .repeat(60));
    
  } catch (err) {
    console.error('❌ Integration test failed:', err.message);
    
    // Save error results
    fs.mkdirSync('../feature-validation', { recursive: true });
    fs.writeFileSync(
      '../feature-validation/custom_feature_validation.json',
      JSON.stringify({
        error: err.message,
        timestamp: new Date().toISOString(),
        duration: Date.now() - startTime,
        results: results
      }, null, 2)
    );
    
    process.exit(1);
  }
}

main();