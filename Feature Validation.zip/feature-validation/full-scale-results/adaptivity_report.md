# Adaptivity Analysis Report

## Summary
- Sampled Users: 13
- Adaptive Users: 0
- Overall Adaptivity Score: 0.00%

## Analysis
{
  "sampledUsers": 13,
  "adaptivityAnalysis": [
    {
      "userId": "sim_user_26_1755185475319",
      "totalQuestions": 10,
      "initialDifficulty": -1.6,
      "finalDifficulty": -1.6400000000000001,
      "difficultyRange": 0.040000000000000036,
      "adaptiveChanges": 0,
      "trendDirection": "stable"
    },
    {
      "userId": "sim_user_47_1755185479982",
      "totalQuestions": 10,
      "initialDifficulty": -1.6099999999999999,
      "finalDifficulty": -1.6800000000000002,
      "difficultyRange": 0.07000000000000028,
      "adaptiveChanges": 0,
      "trendDirection": "stable"
    },
    {
      "userId": "sim_user_63_1755185483476",
      "totalQuestions": 10,
      "initialDifficulty": -1.6,
      "finalDifficulty": -1.6400000000000001,
      "difficultyRange": 0.040000000000000036,
      "adaptiveChanges": 0,
      "trendDirection": "stable"
    },
    {
      "userId": "sim_user_99_1755185491270",
      "totalQuestions": 10,
      "initialDifficulty": -1.6,
      "finalDifficulty": -1.6400000000000001,
      "difficultyRange": 0.040000000000000036,
      "adaptiveChanges": 0,
      "trendDirection": "stable"
    },
    {
      "userId": "sim_user_102_1755185491896",
      "totalQuestions": 10,
      "initialDifficulty": -1.6,
      "finalDifficulty": -1.6400000000000001,
      "difficultyRange": 0.040000000000000036,
      "adaptiveChanges": 0,
      "trendDirection": "stable"
    },
    {
      "userId": "sim_user_138_1755185472422",
      "totalQuestions": 10,
      "initialDifficulty": -1.6099999999999999,
      "finalDifficulty": -1.69,
      "difficultyRange": 0.08000000000000007,
      "adaptiveChanges": 0,
      "trendDirection": "stable"
    },
    {
      "userId": "sim_user_311_1755185482762",
      "totalQuestions": 10,
      "initialDifficulty": -1.6,
      "finalDifficulty": -1.6400000000000001,
      "difficultyRange": 0.040000000000000036,
      "adaptiveChanges": 0,
      "trendDirection": "stable"
    },
    {
      "userId": "sim_user_565_1755185484015",
      "totalQuestions": 10,
      "initialDifficulty": -1.6,
      "finalDifficulty": -1.6400000000000001,
      "difficultyRange": 0.040000000000000036,
      "adaptiveChanges": 0,
      "trendDirection": "stable"
    },
    {
      "userId": "sim_user_629_1755185470106",
      "totalQuestions": 10,
      "initialDifficulty": -1.6,
      "finalDifficulty": -1.6400000000000001,
      "difficultyRange": 0.040000000000000036,
      "adaptiveChanges": 0,
      "trendDirection": "stable"
    },
    {
      "userId": "sim_user_703_1755185486328",
      "totalQuestions": 10,
      "initialDifficulty": -1.6,
      "finalDifficulty": -1.6400000000000001,
      "difficultyRange": 0.040000000000000036,
      "adaptiveChanges": 0,
      "trendDirection": "stable"
    },
    {
      "userId": "sim_user_747_1755185495447",
      "totalQuestions": 10,
      "initialDifficulty": -1.63,
      "finalDifficulty": -1.71,
      "difficultyRange": 0.08000000000000007,
      "adaptiveChanges": 0,
      "trendDirection": "stable"
    },
    {
      "userId": "sim_user_917_1755185478519",
      "totalQuestions": 10,
      "initialDifficulty": -1.6,
      "finalDifficulty": -1.6400000000000001,
      "difficultyRange": 0.040000000000000036,
      "adaptiveChanges": 0,
      "trendDirection": "stable"
    },
    {
      "userId": "sim_user_944_1755185484227",
      "totalQuestions": 10,
      "initialDifficulty": -1.6099999999999999,
      "finalDifficulty": -1.69,
      "difficultyRange": 0.08000000000000007,
      "adaptiveChanges": 0,
      "trendDirection": "stable"
    }
  ],
  "overallAdaptivityScore": 0,
  "adaptiveUsersCount": 0
}