import React from 'react';
import { Route, Switch } from 'wouter';
import AssessmentCenter from '../pages/assessments/Index';
import VoiceAssessment from '../pages/assessments/Voice';
import EiQScore from '../pages/analytics/EiQScore';
import BehavioralAnalytics from '../pages/analytics/Behavioral';
import AIProviders from '../pages/ai/Providers';
import TuringTest from '../pages/ai/Turing';
import RoleModelCenter from '../pages/roleModels/Index';
import Dashboard from '../pages/dashboard';

export default function AppRoutes() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/assessments" component={AssessmentCenter} />
      <Route path="/assessments/voice" component={VoiceAssessment} />
      <Route path="/analytics/eiq" component={EiQScore} />
      <Route path="/analytics/behavioral" component={BehavioralAnalytics} />
      <Route path="/ai/providers" component={AIProviders} />
      <Route path="/ai/turing" component={TuringTest} />
      <Route path="/role-models" component={RoleModelCenter} />
    </Switch>
  );
}