import { useState, useCallback } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  BookOpen, 
  GraduationCap, 
  Briefcase, 
  Award, 
  Target, 
  Brain, 
  Users,
  Star,
  Clock,
  CheckCircle,
  PlayCircle,
  TrendingUp,
  Zap,
  Globe,
  Trophy
} from "lucide-react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import ModernLayout from "@/components/layout/ModernLayout";

export default function LearningPaths() {
  const [, setLocation] = useLocation();
  const [selectedTrack, setSelectedTrack] = useState("elementary");

  const handleNavigation = useCallback((section: string) => {
    const routeMap: { [key: string]: string } = {
      "dashboard": "/",
      "assessment-center": "/assessment-center", 
      "standardized-tests": "/standardized-tests",
      "multi-iq-scoring": "/multi-iq-scoring",
      "dsm-integration": "/dsm-integration",
      "voice-assessment": "/voice-assessment",
      "eiq-analytics": "/eiq-analytics",
      "ai-features": "/ai-features",
      "learning-paths": "/learning-paths",
      "ai-agents": "/ai-agents"
    };
    const route = routeMap[section] || "/";
    setLocation(route);
  }, [setLocation]);

  // Real backend data integration
  const { data: dashboardMetrics } = useQuery({
    queryKey: ["/api/analytics/dashboard-metrics"],
    staleTime: 2 * 60 * 1000, // 2 minutes
    gcTime: 5 * 60 * 1000, // 5 minutes
  });

  const industryTitanTracks = [
    {
      id: "elementary",
      title: "Elementary Academic Foundation",
      description: "Building fundamental learning skills and academic confidence",
      icon: BookOpen,
      color: "text-blue-500",
      bgColor: "bg-blue-500/10",
      borderColor: "border-blue-500/20",
      level: "Elementary (K-5)",
      duration: "2-3 years",
      modules: [
        { name: "Reading Comprehension", progress: 75, completed: false },
        { name: "Mathematical Foundations", progress: 60, completed: false },
        { name: "Scientific Thinking", progress: 45, completed: false },
        { name: "Creative Expression", progress: 80, completed: false }
      ],
      skills: ["Critical thinking", "Problem solving", "Communication", "Creativity"],
      outcomes: ["Strong academic foundation", "Learning confidence", "Study habits"]
    },
    {
      id: "middle-school",
      title: "Middle School Academic Development", 
      description: "Developing analytical skills and subject expertise",
      icon: Brain,
      color: "text-green-500",
      bgColor: "bg-green-500/10",
      borderColor: "border-green-500/20",
      level: "Middle School (6-8)",
      duration: "2-3 years",
      modules: [
        { name: "Advanced Mathematics", progress: 40, completed: false },
        { name: "Science Investigation", progress: 55, completed: false },
        { name: "Language Arts", progress: 70, completed: false },
        { name: "Social Studies", progress: 35, completed: false }
      ],
      skills: ["Analytical thinking", "Research methods", "Presentation skills", "Collaboration"],
      outcomes: ["Subject mastery", "Study strategies", "Academic confidence"]
    },
    {
      id: "high-school",
      title: "High School Academic Excellence",
      description: "Advanced preparation for higher education success",
      icon: GraduationCap,
      color: "text-purple-500",
      bgColor: "bg-purple-500/10",
      borderColor: "border-purple-500/20",
      level: "High School (9-12)",
      duration: "3-4 years",
      modules: [
        { name: "AP Course Preparation", progress: 30, completed: false },
        { name: "SAT/ACT Mastery", progress: 25, completed: false },
        { name: "College Applications", progress: 10, completed: false },
        { name: "Leadership Development", progress: 50, completed: false }
      ],
      skills: ["Advanced reasoning", "Academic writing", "Test strategies", "Time management"],
      outcomes: ["College readiness", "Scholarship potential", "Leadership skills"]
    },
    {
      id: "undergraduate",
      title: "Undergraduate Academic Mastery",
      description: "University-level critical thinking and specialization",
      icon: Trophy,
      color: "text-orange-500",
      bgColor: "bg-orange-500/10",
      borderColor: "border-orange-500/20",
      level: "Undergraduate",
      duration: "4 years",
      modules: [
        { name: "Major Specialization", progress: 20, completed: false },
        { name: "Research Methods", progress: 15, completed: false },
        { name: "Internship Preparation", progress: 5, completed: false },
        { name: "Graduate School Prep", progress: 0, completed: false }
      ],
      skills: ["Specialized knowledge", "Research abilities", "Professional skills", "Innovation"],
      outcomes: ["Degree completion", "Career preparation", "Graduate readiness"]
    },
    {
      id: "graduate",
      title: "Graduate Academic Leadership",
      description: "Advanced research and professional development",
      icon: Star,
      color: "text-red-500",
      bgColor: "bg-red-500/10",
      borderColor: "border-red-500/20",
      level: "Graduate",
      duration: "2-6 years",
      modules: [
        { name: "Thesis Research", progress: 0, completed: false },
        { name: "Publication Writing", progress: 0, completed: false },
        { name: "Teaching Excellence", progress: 0, completed: false },
        { name: "Industry Collaboration", progress: 0, completed: false }
      ],
      skills: ["Research leadership", "Academic writing", "Teaching", "Industry expertise"],
      outcomes: ["Advanced degree", "Research contributions", "Teaching credentials"]
    },
    {
      id: "senior-academic",
      title: "Senior Academic Enrichment",
      description: "Lifelong learning and knowledge sharing",
      icon: Globe,
      color: "text-cyan-500",
      bgColor: "bg-cyan-500/10",
      borderColor: "border-cyan-500/20",
      level: "Senior Academic",
      duration: "Ongoing",
      modules: [
        { name: "Continuing Education", progress: 0, completed: false },
        { name: "Mentorship Programs", progress: 0, completed: false },
        { name: "Community Learning", progress: 0, completed: false },
        { name: "Knowledge Sharing", progress: 0, completed: false }
      ],
      skills: ["Mentoring", "Knowledge synthesis", "Community engagement", "Wisdom sharing"],
      outcomes: ["Lifelong learning", "Community impact", "Legacy building"]
    }
  ];

  const selectedTrackData = industryTitanTracks.find(track => track.id === selectedTrack) || industryTitanTracks[0];

  const handleStartTrack = (trackId: string) => {
    setLocation(`/learning-path/${trackId}`);
  };

  const learningStats = {
    pathsGenerated: (dashboardMetrics as any)?.learningPathsGenerated || 0,
    completionRate: 67, // Calculated from progress data
    averageProgress: Math.round(selectedTrackData.modules.reduce((acc, mod) => acc + mod.progress, 0) / selectedTrackData.modules.length),
    skillsAcquired: selectedTrackData.skills.length
  };

  return (
    <ModernLayout
      activeSection="learning-paths"
      onSectionChange={handleNavigation}
    >
      <div className="container mx-auto p-6 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Learning Pathways</h1>
            <p className="text-muted-foreground mt-2">
              Industry Titan Tracks - Education Focused Academic Development
            </p>
          </div>
        <div className="flex items-center gap-2">
          <Badge variant="secondary" className="px-3 py-1">
            6 Learning Tracks
          </Badge>
          <Badge variant="outline" className="px-3 py-1">
            Education First
          </Badge>
        </div>
      </div>

      {/* Learning Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <BookOpen className="h-8 w-8 mx-auto mb-2 text-blue-500" />
            <div className="text-2xl font-bold">{learningStats.pathsGenerated.toLocaleString()}</div>
            <div className="text-sm text-muted-foreground">Learning Paths Generated</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <TrendingUp className="h-8 w-8 mx-auto mb-2 text-green-500" />
            <div className="text-2xl font-bold">{learningStats.completionRate}%</div>
            <div className="text-sm text-muted-foreground">Average Completion Rate</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <Target className="h-8 w-8 mx-auto mb-2 text-purple-500" />
            <div className="text-2xl font-bold">{learningStats.averageProgress}%</div>
            <div className="text-sm text-muted-foreground">Current Track Progress</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <Award className="h-8 w-8 mx-auto mb-2 text-orange-500" />
            <div className="text-2xl font-bold">{learningStats.skillsAcquired}</div>
            <div className="text-sm text-muted-foreground">Skills to Acquire</div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="overview">Track Overview</TabsTrigger>
          <TabsTrigger value="detailed">Detailed Progress</TabsTrigger>
          <TabsTrigger value="recommendations">AI Recommendations</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          {/* Track Selection */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <GraduationCap className="h-5 w-5 text-blue-500" />
                Select Your Academic Level
              </CardTitle>
              <CardDescription>
                Choose your current education level to access tailored learning pathways
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {industryTitanTracks.map((track) => (
                  <Card 
                    key={track.id}
                    className={`cursor-pointer transition-all ${
                      selectedTrack === track.id ? 'ring-2 ring-primary' : ''
                    }`}
                    onClick={() => setSelectedTrack(track.id)}
                  >
                    <CardHeader className="pb-3">
                      <div className="flex items-center gap-3">
                        <div className={`p-2 rounded-lg ${track.bgColor}`}>
                          <track.icon className={`h-5 w-5 ${track.color}`} />
                        </div>
                        <div>
                          <CardTitle className="text-base">{track.title}</CardTitle>
                          <CardDescription className="text-xs">
                            {track.level}
                          </CardDescription>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="pt-0">
                      <p className="text-sm text-muted-foreground mb-3">
                        {track.description}
                      </p>
                      <div className="flex justify-between text-xs text-muted-foreground">
                        <span>Duration: {track.duration}</span>
                        <span>{track.modules.length} modules</span>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Selected Track Details */}
          <Card className={`${selectedTrackData.borderColor} border-2`}>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className={`p-3 rounded-lg ${selectedTrackData.bgColor}`}>
                    <selectedTrackData.icon className={`h-6 w-6 ${selectedTrackData.color}`} />
                  </div>
                  <div>
                    <CardTitle className="text-xl">{selectedTrackData.title}</CardTitle>
                    <CardDescription>
                      {selectedTrackData.description}
                    </CardDescription>
                  </div>
                </div>
                <Badge variant="outline" className={selectedTrackData.color}>
                  {selectedTrackData.level}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Modules Progress */}
              <div>
                <h4 className="font-medium mb-3">Learning Modules:</h4>
                <div className="space-y-3">
                  {selectedTrackData.modules.map((module, idx) => (
                    <div key={idx} className="space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          {module.progress === 100 ? (
                            <CheckCircle className="h-4 w-4 text-green-500" />
                          ) : (
                            <PlayCircle className="h-4 w-4 text-muted-foreground" />
                          )}
                          <span className="text-sm font-medium">{module.name}</span>
                        </div>
                        <span className="text-sm text-muted-foreground">{module.progress}%</span>
                      </div>
                      <Progress value={module.progress} className="h-2" />
                    </div>
                  ))}
                </div>
              </div>

              {/* Skills & Outcomes */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-medium mb-2">Key Skills:</h4>
                  <ul className="text-sm text-muted-foreground space-y-1">
                    {selectedTrackData.skills.map((skill, idx) => (
                      <li key={idx} className="flex items-center gap-2">
                        <Zap className="h-3 w-3 text-yellow-500" />
                        {skill}
                      </li>
                    ))}
                  </ul>
                </div>
                <div>
                  <h4 className="font-medium mb-2">Learning Outcomes:</h4>
                  <ul className="text-sm text-muted-foreground space-y-1">
                    {selectedTrackData.outcomes.map((outcome, idx) => (
                      <li key={idx} className="flex items-center gap-2">
                        <CheckCircle className="h-3 w-3 text-green-500" />
                        {outcome}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Action Button */}
              <Button 
                className="w-full"
                onClick={() => handleStartTrack(selectedTrackData.id)}
              >
                Start {selectedTrackData.title}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="detailed" className="space-y-6">
          {/* Detailed Progress View */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {selectedTrackData.modules.map((module, idx) => (
              <Card key={idx}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">{module.name}</CardTitle>
                    <Badge variant={module.progress === 100 ? "default" : "secondary"}>
                      {module.progress}% Complete
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <Progress value={module.progress} className="mb-4" />
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>Lessons Completed</span>
                      <span>{Math.round(module.progress * 0.12)}/12</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Assessments Passed</span>
                      <span>{Math.round(module.progress * 0.03)}/3</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Time Invested</span>
                      <span>{Math.round(module.progress * 0.25)}h</span>
                    </div>
                  </div>
                  <Button variant="outline" className="w-full mt-4" size="sm">
                    Continue Module
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="recommendations" className="space-y-6">
          {/* AI-Powered Recommendations */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Brain className="h-5 w-5 text-purple-500" />
                  Personalized Study Plan
                </CardTitle>
                <CardDescription>AI-generated recommendations based on your progress</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="p-3 bg-purple-50 dark:bg-purple-950/20 rounded-lg">
                    <div className="font-medium text-sm">Priority Focus Area</div>
                    <div className="text-sm text-muted-foreground mt-1">
                      Mathematical Foundations needs attention (60% progress). Dedicate 30 minutes daily.
                    </div>
                  </div>
                  <div className="p-3 bg-blue-50 dark:bg-blue-950/20 rounded-lg">
                    <div className="font-medium text-sm">Optimal Study Schedule</div>
                    <div className="text-sm text-muted-foreground mt-1">
                      Best performance detected between 2-4 PM. Schedule challenging topics during this window.
                    </div>
                  </div>
                  <div className="p-3 bg-green-50 dark:bg-green-950/20 rounded-lg">
                    <div className="font-medium text-sm">Strength to Leverage</div>
                    <div className="text-sm text-muted-foreground mt-1">
                      Creative Expression shows exceptional progress. Use this confidence for challenging areas.
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="h-5 w-5 text-green-500" />
                  Achievement Targets
                </CardTitle>
                <CardDescription>Milestones and goals for next 30 days</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Complete Math Module 3</span>
                    <Badge variant="outline">7 days</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Reading Assessment</span>
                    <Badge variant="outline">14 days</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Science Project Submission</span>
                    <Badge variant="outline">21 days</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Track Progression Review</span>
                    <Badge variant="outline">30 days</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
      </div>
    </ModernLayout>
  );
}