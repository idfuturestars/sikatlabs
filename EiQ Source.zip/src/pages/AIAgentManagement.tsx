import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { Brain, Shield, Settings, Users, MessageSquare, Activity, AlertTriangle, CheckCircle, Clock, Zap } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

// Form schemas
const createMotherAISchema = z.object({
  name: z.string().min(1, "Name is required").max(100),
  aiProvider: z.enum(["openai", "anthropic", "gemini"]),
  capabilities: z.object({
    assessment: z.boolean().default(true),
    tutoring: z.boolean().default(true),
    behavioral_analysis: z.boolean().default(true),
    content_generation: z.boolean().default(true),
  }),
  privacyLevel: z.enum(["minimal", "standard", "elevated", "full"]).default("standard"),
});

const createChildAISchema = z.object({
  name: z.string().min(1, "Name is required").max(100),
  motherAgentId: z.string().min(1, "Mother Agent ID is required"),
  specialization: z.string().min(1, "Specialization is required").max(200),
  capabilities: z.object({
    assessment: z.boolean().default(false),
    tutoring: z.boolean().default(true),
    behavioral_analysis: z.boolean().default(false),
    content_generation: z.boolean().default(true),
  }),
  privacyLevel: z.enum(["minimal", "standard", "elevated", "full"]).default("standard"),
  aiProvider: z.enum(["openai", "anthropic", "gemini"]).optional(),
});

const privacyControlSchema = z.object({
  controlType: z.enum(["data_sharing", "ai_access", "monitoring", "retention"]),
  settingName: z.string().min(1, "Setting name is required"),
  settingValue: z.record(z.any()),
  restrictionLevel: z.enum(["minimal", "moderate", "strict", "paranoid"]).default("moderate"),
  auditRequired: z.boolean().default(false),
});

type MotherAIFormData = z.infer<typeof createMotherAISchema>;
type ChildAIFormData = z.infer<typeof createChildAISchema>;
type PrivacyControlFormData = z.infer<typeof privacyControlSchema>;

export default function AIAgentManagement() {
  const [selectedAgent, setSelectedAgent] = useState<string | null>(null);
  const [createMotherDialogOpen, setCreateMotherDialogOpen] = useState(false);
  const [createChildDialogOpen, setCreateChildDialogOpen] = useState(false);
  const [privacyDialogOpen, setPrivacyDialogOpen] = useState(false);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  // Fetch AI agents
  const { data: agents = [], isLoading: agentsLoading } = useQuery<any[]>({
    queryKey: ["/api/ai-agents"],
  });

  // Fetch AI agent sessions
  const { data: sessions = [], isLoading: sessionsLoading } = useQuery<any[]>({
    queryKey: ["/api/ai-agents/sessions"],
  });

  // Fetch privacy controls
  const { data: privacyControls = [], isLoading: privacyLoading } = useQuery<any[]>({
    queryKey: ["/api/ai-agents/privacy-controls"],
  });

  // Fetch communication logs
  const { data: communicationsResponse, isLoading: communicationsLoading } = useQuery({
    queryKey: ["/api/ai-agents/communications"],
  });
  
  const communications = (communicationsResponse as any)?.communications || [];

  // Create MotherAI mutation
  const createMotherAIMutation = useMutation({
    mutationFn: async (data: MotherAIFormData) => {
      const res = await apiRequest("POST", "/api/ai-agents/mother", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/ai-agents"] });
      setCreateMotherDialogOpen(false);
      toast({
        title: "Success",
        description: "MotherAI agent created successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Create ChildAI mutation
  const createChildAIMutation = useMutation({
    mutationFn: async (data: ChildAIFormData) => {
      const res = await apiRequest("POST", "/api/ai-agents/child", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/ai-agents"] });
      setCreateChildDialogOpen(false);
      toast({
        title: "Success",
        description: "ChildAI agent created successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Privacy control mutation
  const createPrivacyControlMutation = useMutation({
    mutationFn: async (data: PrivacyControlFormData) => {
      const res = await apiRequest("POST", "/api/ai-agents/privacy-controls", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/ai-agents/privacy-controls"] });
      setPrivacyDialogOpen(false);
      toast({
        title: "Success",
        description: "Privacy control created successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Forms
  const motherAIForm = useForm<MotherAIFormData>({
    resolver: zodResolver(createMotherAISchema),
    defaultValues: {
      name: "",
      aiProvider: "openai",
      capabilities: {
        assessment: true,
        tutoring: true,
        behavioral_analysis: true,
        content_generation: true,
      },
      privacyLevel: "standard",
    },
  });

  const childAIForm = useForm<ChildAIFormData>({
    resolver: zodResolver(createChildAISchema),
    defaultValues: {
      name: "",
      motherAgentId: "",
      specialization: "",
      capabilities: {
        assessment: false,
        tutoring: true,
        behavioral_analysis: false,
        content_generation: true,
      },
      privacyLevel: "standard",
    },
  });

  const privacyForm = useForm<PrivacyControlFormData>({
    resolver: zodResolver(privacyControlSchema),
    defaultValues: {
      controlType: "data_sharing",
      settingName: "",
      settingValue: {},
      restrictionLevel: "moderate",
      auditRequired: false,
    },
  });

  const getAgentStatusIcon = (isActive: boolean, lastHealthCheck: string) => {
    if (!isActive) return <AlertTriangle className="h-4 w-4 text-red-500" />;
    
    const lastCheck = new Date(lastHealthCheck);
    const now = new Date();
    const timeDiff = now.getTime() - lastCheck.getTime();
    const hoursDiff = timeDiff / (1000 * 3600);
    
    if (hoursDiff < 1) return <CheckCircle className="h-4 w-4 text-green-500" />;
    if (hoursDiff < 24) return <Clock className="h-4 w-4 text-yellow-500" />;
    return <AlertTriangle className="h-4 w-4 text-red-500" />;
  };

  const getPrivacyLevelColor = (level: string) => {
    switch (level) {
      case "minimal": return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200";
      case "standard": return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200";
      case "elevated": return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200";
      case "full": return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200";
      default: return "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200";
    }
  };

  const motherAgents = agents.filter((agent: any) => agent.agentType === "mother");
  const childAgents = agents.filter((agent: any) => agent.agentType === "child");

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">AI Agent Management</h1>
          <p className="text-muted-foreground">
            Manage MotherAI ↔ ChildAI architecture with comprehensive privacy controls
          </p>
        </div>
        <div className="flex gap-2">
          <Dialog open={createMotherDialogOpen} onOpenChange={setCreateMotherDialogOpen}>
            <DialogTrigger asChild>
              <Button><Brain className="h-4 w-4 mr-2" />Create MotherAI</Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md">
              <DialogHeader>
                <DialogTitle>Create MotherAI Agent</DialogTitle>
                <DialogDescription>
                  Create a new MotherAI agent with full system capabilities
                </DialogDescription>
              </DialogHeader>
              <Form {...motherAIForm}>
                <form onSubmit={motherAIForm.handleSubmit((data) => createMotherAIMutation.mutate(data))} className="space-y-4">
                  <FormField
                    control={motherAIForm.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Agent Name</FormLabel>
                        <FormControl>
                          <Input placeholder="EiQ MotherAI-01" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={motherAIForm.control}
                    name="aiProvider"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>AI Provider</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select provider" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="openai">OpenAI GPT-4</SelectItem>
                            <SelectItem value="anthropic">Anthropic Claude</SelectItem>
                            <SelectItem value="gemini">Google Gemini</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={motherAIForm.control}
                    name="privacyLevel"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Privacy Level</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select privacy level" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="minimal">Minimal</SelectItem>
                            <SelectItem value="standard">Standard</SelectItem>
                            <SelectItem value="elevated">Elevated</SelectItem>
                            <SelectItem value="full">Full</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <div className="space-y-2">
                    <Label>Capabilities</Label>
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={motherAIForm.control}
                        name="capabilities.assessment"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3">
                            <div className="space-y-0.5">
                              <FormLabel>Assessment</FormLabel>
                            </div>
                            <FormControl>
                              <Switch checked={field.value} onCheckedChange={field.onChange} />
                            </FormControl>
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={motherAIForm.control}
                        name="capabilities.tutoring"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3">
                            <div className="space-y-0.5">
                              <FormLabel>Tutoring</FormLabel>
                            </div>
                            <FormControl>
                              <Switch checked={field.value} onCheckedChange={field.onChange} />
                            </FormControl>
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={motherAIForm.control}
                        name="capabilities.behavioral_analysis"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3">
                            <div className="space-y-0.5">
                              <FormLabel>Behavioral Analysis</FormLabel>
                            </div>
                            <FormControl>
                              <Switch checked={field.value} onCheckedChange={field.onChange} />
                            </FormControl>
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={motherAIForm.control}
                        name="capabilities.content_generation"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3">
                            <div className="space-y-0.5">
                              <FormLabel>Content Generation</FormLabel>
                            </div>
                            <FormControl>
                              <Switch checked={field.value} onCheckedChange={field.onChange} />
                            </FormControl>
                          </FormItem>
                        )}
                      />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button type="submit" disabled={createMotherAIMutation.isPending}>
                      {createMotherAIMutation.isPending ? "Creating..." : "Create MotherAI"}
                    </Button>
                  </DialogFooter>
                </form>
              </Form>
            </DialogContent>
          </Dialog>

          <Dialog open={createChildDialogOpen} onOpenChange={setCreateChildDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="outline"><Users className="h-4 w-4 mr-2" />Create ChildAI</Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md">
              <DialogHeader>
                <DialogTitle>Create ChildAI Agent</DialogTitle>
                <DialogDescription>
                  Create a specialized ChildAI agent supervised by a MotherAI
                </DialogDescription>
              </DialogHeader>
              <Form {...childAIForm}>
                <form onSubmit={childAIForm.handleSubmit((data) => createChildAIMutation.mutate(data))} className="space-y-4">
                  <FormField
                    control={childAIForm.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Agent Name</FormLabel>
                        <FormControl>
                          <Input placeholder="EiQ ChildAI-Math-01" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={childAIForm.control}
                    name="motherAgentId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>MotherAI Agent</FormLabel>
                        <Select onValueChange={field.onChange} value={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select MotherAI" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {motherAgents.map((agent: any) => (
                              <SelectItem key={agent.id} value={agent.id}>
                                {agent.agentName}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={childAIForm.control}
                    name="specialization"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Specialization</FormLabel>
                        <FormControl>
                          <Textarea placeholder="Mathematics tutoring and assessment" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={childAIForm.control}
                    name="privacyLevel"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Privacy Level</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select privacy level" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="minimal">Minimal</SelectItem>
                            <SelectItem value="standard">Standard</SelectItem>
                            <SelectItem value="elevated">Elevated</SelectItem>
                            <SelectItem value="full">Full</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <DialogFooter>
                    <Button type="submit" disabled={createChildAIMutation.isPending}>
                      {createChildAIMutation.isPending ? "Creating..." : "Create ChildAI"}
                    </Button>
                  </DialogFooter>
                </form>
              </Form>
            </DialogContent>
          </Dialog>

          <Dialog open={privacyDialogOpen} onOpenChange={setPrivacyDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="outline"><Shield className="h-4 w-4 mr-2" />Privacy Controls</Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create Privacy Control</DialogTitle>
                <DialogDescription>
                  Set up granular privacy controls for AI agent interactions
                </DialogDescription>
              </DialogHeader>
              <Form {...privacyForm}>
                <form onSubmit={privacyForm.handleSubmit((data) => createPrivacyControlMutation.mutate(data))} className="space-y-4">
                  <FormField
                    control={privacyForm.control}
                    name="controlType"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Control Type</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select control type" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="data_sharing">Data Sharing</SelectItem>
                            <SelectItem value="ai_access">AI Access</SelectItem>
                            <SelectItem value="monitoring">Monitoring</SelectItem>
                            <SelectItem value="retention">Data Retention</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={privacyForm.control}
                    name="settingName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Setting Name</FormLabel>
                        <FormControl>
                          <Input placeholder="Assessment Data Access" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={privacyForm.control}
                    name="restrictionLevel"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Restriction Level</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select restriction level" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="minimal">Minimal</SelectItem>
                            <SelectItem value="moderate">Moderate</SelectItem>
                            <SelectItem value="strict">Strict</SelectItem>
                            <SelectItem value="paranoid">Paranoid</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={privacyForm.control}
                    name="auditRequired"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                        <div className="space-y-0.5">
                          <FormLabel className="text-base">Audit Required</FormLabel>
                          <FormDescription>
                            Require audit logging for this control
                          </FormDescription>
                        </div>
                        <FormControl>
                          <Switch checked={field.value} onCheckedChange={field.onChange} />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                  <DialogFooter>
                    <Button type="submit" disabled={createPrivacyControlMutation.isPending}>
                      {createPrivacyControlMutation.isPending ? "Creating..." : "Create Control"}
                    </Button>
                  </DialogFooter>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <Tabs defaultValue="agents" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="agents">AI Agents</TabsTrigger>
          <TabsTrigger value="sessions">Active Sessions</TabsTrigger>
          <TabsTrigger value="privacy">Privacy Controls</TabsTrigger>
          <TabsTrigger value="communications">Communications</TabsTrigger>
        </TabsList>

        <TabsContent value="agents" className="space-y-4">
          <div className="grid gap-6 md:grid-cols-2">
            {/* MotherAI Agents */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Brain className="h-5 w-5" />
                  MotherAI Agents
                </CardTitle>
                <CardDescription>
                  Primary AI agents with full system capabilities
                </CardDescription>
              </CardHeader>
              <CardContent>
                {agentsLoading ? (
                  <div className="space-y-2">
                    {[...Array(3)].map((_, i) => (
                      <div key={i} className="h-16 bg-muted rounded animate-pulse" />
                    ))}
                  </div>
                ) : (
                  <div className="space-y-3">
                    {motherAgents.length === 0 ? (
                      <p className="text-sm text-muted-foreground">No MotherAI agents created yet</p>
                    ) : (
                      motherAgents.map((agent: any) => (
                        <Card key={agent.id} className="p-4">
                          <div className="flex items-start justify-between">
                            <div className="space-y-1">
                              <div className="flex items-center gap-2">
                                <h4 className="font-medium">{agent.agentName}</h4>
                                {getAgentStatusIcon(agent.isActive, agent.lastHealthCheck)}
                              </div>
                              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                                <Badge variant="secondary">{agent.aiProvider}</Badge>
                                <Badge className={getPrivacyLevelColor(agent.privacyLevel)}>
                                  {agent.privacyLevel}
                                </Badge>
                              </div>
                              <div className="text-xs text-muted-foreground">
                                v{agent.agentVersion} • Created {new Date(agent.createdAt).toLocaleDateString()}
                              </div>
                            </div>
                            <Button variant="outline" size="sm">
                              <Settings className="h-3 w-3" />
                            </Button>
                          </div>
                        </Card>
                      ))
                    )}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* ChildAI Agents */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  ChildAI Agents
                </CardTitle>
                <CardDescription>
                  Specialized AI agents supervised by MotherAI
                </CardDescription>
              </CardHeader>
              <CardContent>
                {agentsLoading ? (
                  <div className="space-y-2">
                    {[...Array(3)].map((_, i) => (
                      <div key={i} className="h-16 bg-muted rounded animate-pulse" />
                    ))}
                  </div>
                ) : (
                  <div className="space-y-3">
                    {childAgents.length === 0 ? (
                      <p className="text-sm text-muted-foreground">No ChildAI agents created yet</p>
                    ) : (
                      childAgents.map((agent: any) => (
                        <Card key={agent.id} className="p-4">
                          <div className="flex items-start justify-between">
                            <div className="space-y-1">
                              <div className="flex items-center gap-2">
                                <h4 className="font-medium">{agent.agentName}</h4>
                                {getAgentStatusIcon(agent.isActive, agent.lastHealthCheck)}
                              </div>
                              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                                <Badge variant="secondary">{agent.aiProvider}</Badge>
                                <Badge className={getPrivacyLevelColor(agent.privacyLevel)}>
                                  {agent.privacyLevel}
                                </Badge>
                              </div>
                              <div className="text-xs text-muted-foreground">
                                v{agent.agentVersion} • Created {new Date(agent.createdAt).toLocaleDateString()}
                              </div>
                            </div>
                            <Button variant="outline" size="sm">
                              <Settings className="h-3 w-3" />
                            </Button>
                          </div>
                        </Card>
                      ))
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="sessions" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="h-5 w-5" />
                Active AI Sessions
              </CardTitle>
              <CardDescription>
                Real-time monitoring of AI agent interactions
              </CardDescription>
            </CardHeader>
            <CardContent>
              {sessionsLoading ? (
                <div className="space-y-2">
                  {[...Array(5)].map((_, i) => (
                    <div key={i} className="h-12 bg-muted rounded animate-pulse" />
                  ))}
                </div>
              ) : (
                <div className="space-y-3">
                  {sessions.length === 0 ? (
                    <p className="text-sm text-muted-foreground">No active sessions</p>
                  ) : (
                    sessions.map((session: any) => (
                      <div key={session.id} className="flex items-center justify-between p-3 border rounded">
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <Badge variant="outline">{session.sessionType}</Badge>
                            <span className="text-sm font-medium">
                              {agents.find((a: any) => a.id === session.agentId)?.agentName || "Unknown Agent"}
                            </span>
                          </div>
                          <div className="text-xs text-muted-foreground">
                            {session.privacyMode} • {session.dataAccessLevel} access
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge variant={session.status === "active" ? "default" : "secondary"}>
                            {session.status}
                          </Badge>
                          <Button variant="outline" size="sm">
                            View
                          </Button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="privacy" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5" />
                Privacy Controls
              </CardTitle>
              <CardDescription>
                User-defined privacy settings and restrictions
              </CardDescription>
            </CardHeader>
            <CardContent>
              {privacyLoading ? (
                <div className="space-y-2">
                  {[...Array(4)].map((_, i) => (
                    <div key={i} className="h-12 bg-muted rounded animate-pulse" />
                  ))}
                </div>
              ) : (
                <div className="space-y-3">
                  {privacyControls.length === 0 ? (
                    <p className="text-sm text-muted-foreground">No privacy controls configured</p>
                  ) : (
                    privacyControls.map((control: any) => (
                      <div key={control.id} className="flex items-center justify-between p-3 border rounded">
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <Badge variant="outline">{control.controlType}</Badge>
                            <span className="text-sm font-medium">{control.settingName}</span>
                          </div>
                          <div className="text-xs text-muted-foreground">
                            {control.restrictionLevel} restriction
                            {control.auditRequired && " • Audit required"}
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge variant={control.isActive ? "default" : "secondary"}>
                            {control.isActive ? "Active" : "Inactive"}
                          </Badge>
                          <Button variant="outline" size="sm">
                            <Settings className="h-3 w-3" />
                          </Button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="communications" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MessageSquare className="h-5 w-5" />
                MotherAI ↔ ChildAI Communications
              </CardTitle>
              <CardDescription>
                Inter-agent communication logs and monitoring
              </CardDescription>
            </CardHeader>
            <CardContent>
              {communicationsLoading ? (
                <div className="space-y-2">
                  {[...Array(6)].map((_, i) => (
                    <div key={i} className="h-12 bg-muted rounded animate-pulse" />
                  ))}
                </div>
              ) : (
                <div className="space-y-3">
                  {communications.length === 0 ? (
                    <p className="text-sm text-muted-foreground">No communications logged</p>
                  ) : (
                    communications.map((comm: any) => (
                      <div key={comm.id} className="flex items-center justify-between p-3 border rounded">
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <Badge variant="outline">{comm.communicationType}</Badge>
                            <span className="text-sm">
                              {agents.find((a: any) => a.id === comm.motherAgentId)?.agentName || "MotherAI"} →{" "}
                              {agents.find((a: any) => a.id === comm.childAgentId)?.agentName || "ChildAI"}
                            </span>
                          </div>
                          <div className="text-xs text-muted-foreground flex items-center gap-2">
                            <Badge variant="secondary" className="text-xs">
                              {comm.priority}
                            </Badge>
                            {comm.encryptionUsed && <Badge variant="outline" className="text-xs">Encrypted</Badge>}
                            <span>{new Date(comm.sentAt).toLocaleString()}</span>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge variant={
                            comm.status === "delivered" ? "default" : 
                            comm.status === "processed" ? "default" : 
                            comm.status === "failed" ? "destructive" : "secondary"
                          }>
                            {comm.status}
                          </Badge>
                          <Button variant="outline" size="sm">
                            View
                          </Button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}