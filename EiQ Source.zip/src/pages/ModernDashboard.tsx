import { useState, useCallback } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import ModernLayout from "@/components/layout/ModernLayout";
import DiscoverCard from "@/components/common/DiscoverCard";
import StatsGrid from "@/components/common/StatsGrid";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  Brain, 
  Calculator, 
  Target, 
  BarChart3, 
  Bot, 
  BookOpen, 
  Award, 
  Lightbulb,
  Mic,
  PieChart,
  Cpu,
  Zap,
  Users,
  MessageSquare,
  Clock,
  Crown,
  Rocket,
  Sprout,
  Globe,
  Trophy,
  TrendingUp,
  Star,
  Play,
  ArrowRight,
  Sparkles
} from "lucide-react";

export default function ModernDashboard() {
  const [activeSection, setActiveSection] = useState("dashboard");
  const [, setLocation] = useLocation();
  const { user } = useAuth();

  const handleSectionChange = useCallback((section: string) => {
    if (section === "dashboard") {
      setActiveSection(section);
    } else {
      // Navigate to the specific page for non-dashboard sections
      const route = section.includes("-") ? `/${section}` : `/${section.replace("_", "-")}`;
      setLocation(route);
    }
  }, [setLocation]);

  const userStats = [
    {
      label: "Assessment Progress",
      value: `${user?.assessmentProgress || 72}%`,
      icon: Target,
      color: "bg-white/10 text-white",
      progress: user?.assessmentProgress || 72,
      trend: "up" as const,
      trendValue: "+12% this week"
    },
    {
      label: "Current EiQ★ Score",
      value: "645",
      icon: Brain,
      color: "bg-white/10 text-white",
      trend: "up" as const,
      trendValue: "+28 points"
    },
    {
      label: "Learning Streak",
      value: `${user?.learningStreak || 15} days`,
      icon: Zap,
      color: "bg-white/10 text-white",
      trend: "up" as const,
      trendValue: "Personal best!"
    },
    {
      label: "AI Interactions",
      value: `${user?.aiInteractions || 142}`,
      icon: MessageSquare,
      color: "bg-white/10 text-white",
      trend: "up" as const,
      trendValue: "+8 today"
    }
  ];

  const discoverFeatures = [
    {
      title: "Assessment Center",
      description: "Comprehensive EiQ★ assessment with adaptive questioning and real-time scoring",
      icon: Target,
      gradient: "from-white/5 to-white/10",
      badge: "Core",
      badgeColor: "bg-white text-black",
      onClick: () => handleSectionChange("assessment-center")
    },
    {
      title: "SAT/ACT/GRE Tests",
      description: "Standardized test preparation with AI-powered score prediction algorithms",
      icon: Calculator,
      gradient: "from-white/5 to-white/10",
      badge: "Popular",
      badgeColor: "bg-white text-black",
      onClick: () => handleSectionChange("standardized-tests")
    },
    {
      title: "Multi-IQ Assessment",
      description: "Traditional, Emotional, and Alternative IQ testing with DISC and OCEAN personality insights",
      icon: Brain,
      gradient: "from-white/5 to-white/10",
      badge: "Advanced",
      badgeColor: "bg-white text-black",
      onClick: () => handleSectionChange("multi-iq-scoring")
    },
    {
      title: "DSM-5-TR Cognitive",
      description: "Clinical-grade cognitive assessments covering attention, memory, and executive function",
      icon: Lightbulb,
      gradient: "from-white/5 to-white/10",
      badge: "Clinical",
      badgeColor: "bg-white text-black",
      onClick: () => handleSectionChange("dsm-integration")
    },
    {
      title: "Voice Assessment",
      description: "AI-powered voice analysis for cognitive evaluation and learning style identification",
      icon: Mic,
      gradient: "from-white/5 to-white/10",
      badge: "AI",
      badgeColor: "bg-white text-black",
      onClick: () => handleSectionChange("voice-assessment")
    },
    {
      title: "EiQ★ Analytics",
      description: "Advanced analytics dashboard with ML insights and personalized recommendations",
      icon: PieChart,
      gradient: "from-white/5 to-white/10",
      badge: "Insights",
      badgeColor: "bg-white text-black",
      onClick: () => handleSectionChange("eiq-analytics")
    },
    {
      title: "AI Features",
      description: "Study groups, voice processing, and ML analytics with MotherAI ↔ ChildAI architecture",
      icon: Cpu,
      gradient: "from-white/5 to-white/10",
      badge: "Beta",
      badgeColor: "bg-white text-black",
      onClick: () => handleSectionChange("ai-features")
    },
    {
      title: "Learning Paths",
      description: "Personalized learning journeys with adaptive content and progress tracking",
      icon: BookOpen,
      gradient: "from-white/5 to-white/10",
      badge: "Adaptive",
      badgeColor: "bg-white text-black",
      onClick: () => handleSectionChange("learning-paths")
    }
  ];

  const viralFeatures = [
    {
      title: "15-Second Challenge",
      description: "Viral assessment challenge with Fisher-Yates randomization",
      icon: Trophy,
      onClick: () => setLocation("/challenge")
    },
    {
      title: "Role Model Matching",
      description: "AI-powered matching with global leaders and innovators",
      icon: Star,
      onClick: () => setLocation("/role-models")
    },
    {
      title: "Public API Portal",
      description: "Open access to EiQ★ assessment APIs for developers",
      icon: Globe,
      onClick: () => setLocation("/api")
    }
  ];

  const renderDashboard = () => (
    <div className="p-8 max-w-7xl mx-auto space-y-8">
      {/* Welcome Header */}
      <div className="text-center space-y-4">
        <h1 className="text-3xl font-bold text-foreground">
          Welcome back, {user?.firstName || user?.first_name || 'Student'} ✨
        </h1>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
          Continue your EiQ★™ journey with AI-powered assessments designed to unlock your intellectual potential
        </p>
      </div>

      {/* Stats Grid */}
      <StatsGrid stats={userStats} columns={4} />

      {/* Quick Actions */}
      <div className="flex gap-4 justify-center">
        <Button 
          size="lg" 
          onClick={() => handleSectionChange("assessment-center")}
          className="bg-primary hover:bg-primary/90"
        >
          <Play className="w-4 h-4 mr-2" />
          Continue Assessment
        </Button>
        <Button 
          size="lg" 
          variant="outline"
          onClick={() => handleSectionChange("ai-features")}
        >
          <Sparkles className="w-4 h-4 mr-2" />
          Try AI Features
        </Button>
      </div>

      {/* Discover Section */}
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-bold text-foreground">Discover</h2>
          <div className="flex gap-2">
            <Badge variant="secondary">8 Features Available</Badge>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {discoverFeatures.map((feature, index) => (
            <DiscoverCard key={index} {...feature} />
          ))}
        </div>
      </div>

      {/* Viral Features */}
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-bold text-foreground">Make EiQ★ Viral</h2>
          <Badge className="bg-white text-black">Strategy</Badge>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {viralFeatures.map((feature, index) => (
            <DiscoverCard 
              key={index} 
              {...feature}
              gradient="from-white/5 to-white/10"
              className="hover:border-white/20"
            />
          ))}
        </div>
      </div>

      {/* Recent Activity */}
      <div className="space-y-6">
        <h2 className="text-2xl font-bold text-foreground">Recent Activity</h2>
        <div className="space-y-3">
          <div className="flex items-center justify-between p-4 bg-card border border-border rounded-lg">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center">
                <Calculator className="w-5 h-5 text-white" />
              </div>
              <div>
                <div className="font-medium text-foreground">Completed SAT Math Assessment</div>
                <div className="text-sm text-muted-foreground">Score: 720/800 • 2 hours ago</div>
              </div>
            </div>
            <Badge variant="secondary">Mathematics</Badge>
          </div>
          
          <div className="flex items-center justify-between p-4 bg-card border border-border rounded-lg">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center">
                <Brain className="w-5 h-5 text-white" />
              </div>
              <div>
                <div className="font-medium text-foreground">AI Tutor Session</div>
                <div className="text-sm text-muted-foreground">Logical reasoning practice • 1 day ago</div>
              </div>
            </div>
            <Badge variant="secondary">Logic</Badge>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <ModernLayout
      activeSection={activeSection}
      onSectionChange={handleSectionChange}
    >
      {renderDashboard()}
    </ModernLayout>
  );
}