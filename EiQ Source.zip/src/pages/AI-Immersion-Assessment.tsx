import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { 
  Brain, 
  Zap, 
  Bot, 
  Clock,
  Target,
  CheckCircle,
  PlayCircle,
  Users,
  Award,
  LineChart,
  Activity,
  TrendingUp,
  BarChart3
} from "lucide-react";
import { useState } from "react";

interface AssessmentState {
  sessionId?: string;
  currentTheta: number;
  questionsAsked: number;
  responses: any[];
  startTime: number;
  isActive: boolean;
}

interface EiqScore {
  score: number;
  percentile: number;
  interpretation: string;
  recommendations: string[];
  lastUpdated: string;
}

interface ProgressData {
  totalAssessments: number;
  completedAssessments: number;
  averageScore: number;
  timeSpent: number;
  strongestDomains: string[];
  improvementAreas: string[];
}

export default function AIImmersionAssessment() {
  const [currentSessionId, setCurrentSessionId] = useState<string | null>(null);
  const queryClient = useQueryClient();

  // Fetch current EIQ score (300-850 scale)
  const { data: eiqScore, isLoading: eiqLoading } = useQuery<EiqScore>({
    queryKey: ["/api/eiq/current"],
    retry: false,
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  // Fetch current assessment state
  const { data: assessmentState, isLoading: stateLoading } = useQuery<AssessmentState>({
    queryKey: ["/api/assessment/ai-immersion/state"],
    enabled: !!currentSessionId,
    refetchInterval: 5000, // Real-time updates every 5 seconds
  });

  // Fetch assessment progress
  const { data: progressData } = useQuery<ProgressData>({
    queryKey: ["/api/assessment/progress"],
    staleTime: 2 * 60 * 1000, // 2 minutes
  });

  // Start new assessment
  const startAssessmentMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest("/api/assessment/ai-immersion/start", {
        method: "POST",
        body: { sections: ["ai_conceptual", "machine_learning", "nlp"] }
      });
    },
    onSuccess: (data) => {
      setCurrentSessionId(data.sessionId);
      queryClient.invalidateQueries({ queryKey: ["/api/assessment/ai-immersion/state"] });
    },
  });

  // Calculate FICO-like score display
  const getScoreInfo = (score: number) => {
    if (score >= 800) return { level: "Exceptional", color: "text-green-600", bgColor: "bg-green-100", progress: 95 };
    if (score >= 740) return { level: "Excellent", color: "text-blue-600", bgColor: "bg-blue-100", progress: 85 };
    if (score >= 670) return { level: "Good", color: "text-yellow-600", bgColor: "bg-yellow-100", progress: 70 };
    if (score >= 580) return { level: "Fair", color: "text-orange-600", bgColor: "bg-orange-100", progress: 55 };
    return { level: "Developing", color: "text-red-600", bgColor: "bg-red-100", progress: 35 };
  };

  const scoreInfo = eiqScore ? getScoreInfo(eiqScore.score) : null;

  const assessmentPhases = [
    {
      id: "ai-literacy",
      title: "AI Literacy Assessment",
      description: "Evaluate understanding of AI concepts and applications",
      duration: "20 minutes",
      questions: 25,
      status: "completed",
      score: progressData?.averageScore || 0
    },
    {
      id: "prompt-engineering",
      title: "Prompt Engineering Skills",
      description: "Test ability to craft effective AI prompts",
      duration: "30 minutes", 
      questions: 15,
      status: assessmentState?.isActive ? "in-progress" : "pending",
      score: assessmentState?.isActive ? Math.round(assessmentState.currentTheta * 25 + 75) : null
    },
    {
      id: "ai-ethics",
      title: "AI Ethics & Safety",
      description: "Assessment of AI ethics understanding and safety protocols",
      duration: "25 minutes",
      questions: 20,
      status: "pending",
      score: null
    },
    {
      id: "collaborative-ai",
      title: "Human-AI Collaboration",
      description: "Evaluate skills in working effectively with AI systems",
      duration: "45 minutes",
      questions: 30,
      status: "pending", 
      score: null
    }
  ];

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed":
        return <CheckCircle className="w-5 h-5 text-green-500" />;
      case "in-progress":
        return <PlayCircle className="w-5 h-5 text-blue-500" />;
      default:
        return <Clock className="w-5 h-5 text-muted-foreground" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-green-100 text-green-800";
      case "in-progress":
        return "bg-blue-100 text-blue-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const completedPhases = assessmentPhases.filter(p => p.status === "completed").length;
  const totalPhases = assessmentPhases.length;
  const overallProgress = (completedPhases / totalPhases) * 100;

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-4">
          <h1 className="text-4xl font-bold gradient-text">AI Immersion Assessment</h1>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Deep dive into artificial intelligence concepts with adaptive questioning and real-time EiQ scoring (300-850 scale)
          </p>
        </div>

        {/* EIQ Score Dashboard - FICO-like 300-850 Scale */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Award className="w-5 h-5" />
                Current EiQ™ Score (FICO-like Scale)
              </CardTitle>
              <p className="text-muted-foreground">Educational Intelligence Quotient • Range: 300-850</p>
            </CardHeader>
            <CardContent>
              {eiqLoading ? (
                <div className="animate-pulse space-y-4">
                  <div className="h-20 bg-muted rounded"></div>
                  <div className="h-4 bg-muted rounded w-3/4"></div>
                </div>
              ) : eiqScore && scoreInfo ? (
                <div className="space-y-6">
                  <div className="text-center">
                    <div className="text-5xl font-bold mb-2">{eiqScore.score}</div>
                    <Badge className={`${scoreInfo.bgColor} ${scoreInfo.color}`}>
                      {scoreInfo.level} ({eiqScore.percentile}th percentile)
                    </Badge>
                  </div>
                  <Progress value={scoreInfo.progress} className="h-3" />
                  <div className="grid grid-cols-5 text-xs text-center">
                    <div>300<br/>Poor</div>
                    <div>580<br/>Fair</div>
                    <div>670<br/>Good</div>
                    <div>740<br/>Excellent</div>
                    <div>850<br/>Exceptional</div>
                  </div>
                  {eiqScore.recommendations?.length > 0 && (
                    <div className="bg-muted/50 rounded-lg p-4">
                      <h4 className="font-medium mb-2">Improvement Recommendations:</h4>
                      <ul className="space-y-1 text-sm">
                        {eiqScore.recommendations.slice(0, 3).map((rec, i) => (
                          <li key={i}>• {rec}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              ) : (
                <div className="text-center text-muted-foreground py-8">
                  <Brain className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>Complete an assessment to see your EiQ score</p>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="w-5 h-5" />
                Real-time Assessment State
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {assessmentState?.isActive ? (
                <>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Session ID</span>
                      <span className="font-mono text-xs">{currentSessionId?.slice(-8)}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Questions Answered</span>
                      <span>{assessmentState.questionsAsked}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Current Ability (θ)</span>
                      <span>{assessmentState.currentTheta.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Time Elapsed</span>
                      <span>{Math.round((Date.now() - assessmentState.startTime) / 60000)} min</span>
                    </div>
                  </div>
                  <Badge className="w-full justify-center bg-blue-100 text-blue-800">
                    Assessment Active
                  </Badge>
                </>
              ) : (
                <div className="text-center space-y-4">
                  <div className="text-muted-foreground">No active assessment</div>
                  <Button 
                    onClick={() => startAssessmentMutation.mutate()}
                    disabled={startAssessmentMutation.isPending}
                    className="w-full"
                  >
                    {startAssessmentMutation.isPending ? "Starting..." : "Start AI Assessment"}
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Progress Analytics */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="w-5 h-5" />
              Assessment Progress Analytics
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-primary">{completedPhases}</div>
                <div className="text-sm text-muted-foreground">Phases Completed</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-green-600">{Math.round(overallProgress)}%</div>
                <div className="text-sm text-muted-foreground">Overall Progress</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-600">{progressData?.timeSpent || 0}</div>
                <div className="text-sm text-muted-foreground">Minutes Spent</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-orange-600">{progressData?.averageScore || 0}%</div>
                <div className="text-sm text-muted-foreground">Average Score</div>
              </div>
            </div>
            <Progress value={overallProgress} className="h-3 mb-4" />
            <div className="flex justify-between text-sm text-muted-foreground">
              <span>{completedPhases} of {totalPhases} phases completed</span>
              <span>{progressData?.completedAssessments || 0} total assessments</span>
            </div>
          </CardContent>
        </Card>

        {/* Assessment Phases */}
        <div className="grid gap-4">
          {assessmentPhases.map((phase) => (
            <Card key={phase.id} className="relative">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    {getStatusIcon(phase.status)}
                    <div>
                      <CardTitle className="text-lg">{phase.title}</CardTitle>
                      <p className="text-sm text-muted-foreground">{phase.description}</p>
                    </div>
                  </div>
                  <Badge className={getStatusColor(phase.status)}>
                    {phase.status.replace('-', ' ')}
                  </Badge>
                </div>
              </CardHeader>
              
              <CardContent className="space-y-4">
                <div className="flex items-center gap-6 text-sm text-muted-foreground">
                  <div className="flex items-center gap-1">
                    <Clock className="w-4 h-4" />
                    <span>{phase.duration}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Brain className="w-4 h-4" />
                    <span>{phase.questions} questions</span>
                  </div>
                  {phase.score !== null && (
                    <div className="flex items-center gap-1">
                      <Zap className="w-4 h-4" />
                      <span>Score: {Math.round(phase.score)}%</span>
                    </div>
                  )}
                </div>
                
                <div className="pt-2">
                  <Button 
                    className="w-full" 
                    variant={phase.status === "completed" ? "outline" : "default"}
                    disabled={phase.status === "pending"}
                    onClick={() => phase.status === "pending" && startAssessmentMutation.mutate()}
                  >
                    {phase.status === "completed" && "Review Results"}
                    {phase.status === "in-progress" && "Continue Assessment"}
                    {phase.status === "pending" && "Coming Next"}
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* AI Skills Framework with Real Data */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="w-5 h-5" />
              AI Skills Framework & Domain Analysis
            </CardTitle>
            <p className="text-muted-foreground">
              Comprehensive evaluation of AI literacy and collaboration readiness with adaptive learning paths.
            </p>
          </CardHeader>
          <CardContent>
            <div className="grid gap-6 md:grid-cols-2">
              <div className="space-y-3">
                <h4 className="font-medium flex items-center gap-2">
                  <TrendingUp className="w-4 h-4" />
                  Core Competencies
                </h4>
                <div className="space-y-3">
                  {assessmentPhases.map((phase) => {
                    let status = "Not Started";
                    let statusColor = "text-muted-foreground";
                    
                    if (phase.status === "completed") {
                      status = `Score: ${Math.round(phase.score)}%`;
                      statusColor = phase.score >= 80 ? "text-green-600 font-medium" : 
                                   phase.score >= 70 ? "text-blue-600 font-medium" : 
                                   "text-orange-600 font-medium";
                    } else if (phase.status === "in-progress") {
                      status = "In Progress";
                      statusColor = "text-blue-600 font-medium";
                    }
                    
                    return (
                      <div key={phase.id} className="flex justify-between items-center">
                        <span className="text-sm">{phase.title.replace(' Assessment', '').replace(' Skills', '')}</span>
                        <span className={`text-sm ${statusColor}`}>{status}</span>
                      </div>
                    );
                  })}
                </div>
              </div>
              
              <div className="space-y-3">
                <h4 className="font-medium flex items-center gap-2">
                  <LineChart className="w-4 h-4" />
                  Strengths & Improvement Areas
                </h4>
                <div className="space-y-3">
                  <div>
                    <div className="text-sm font-medium text-green-600 mb-2">Strongest Domains:</div>
                    <div className="space-y-1">
                      {progressData?.strongestDomains?.length > 0 ? 
                        progressData.strongestDomains.map((domain, i) => (
                          <div key={i} className="text-sm text-muted-foreground">• {domain}</div>
                        )) : 
                        <div className="text-sm text-muted-foreground">• Complete assessments to identify strengths</div>
                      }
                    </div>
                  </div>
                  <div>
                    <div className="text-sm font-medium text-orange-600 mb-2">Focus Areas:</div>
                    <div className="space-y-1">
                      {progressData?.improvementAreas?.length > 0 ? 
                        progressData.improvementAreas.map((area, i) => (
                          <div key={i} className="text-sm text-muted-foreground">• {area}</div>
                        )) : 
                        <div className="text-sm text-muted-foreground">• AI Ethics & Safety protocols</div>
                      }
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Adaptive Learning Recommendations */}
            {eiqScore?.recommendations && (
              <div className="mt-6 p-4 bg-gradient-to-r from-blue-50 to-green-50 rounded-lg border">
                <h4 className="font-medium mb-3 flex items-center gap-2">
                  <Bot className="w-4 h-4" />
                  AI-Powered Learning Recommendations
                </h4>
                <div className="grid md:grid-cols-2 gap-4 text-sm">
                  {eiqScore.recommendations.map((recommendation, i) => (
                    <div key={i} className="flex items-start gap-2">
                      <Target className="w-3 h-3 mt-1 text-blue-500 flex-shrink-0" />
                      <span>{recommendation}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}