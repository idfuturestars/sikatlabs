import { useState, useCallback } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Brain, 
  Heart, 
  Lightbulb, 
  Users, 
  Target, 
  TrendingUp,
  BarChart3,
  Award,
  Zap,
  Eye,
  Clock,
  Calculator,
  MessageSquare,
  Palette,
  Music,
  TreePine
} from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { cn } from "@/lib/utils";
import ModernLayout from "@/components/layout/ModernLayout";
import { useLocation } from "wouter";

export default function MultiIQScoring() {
  const [, setLocation] = useLocation();
  const [activeCategory, setActiveCategory] = useState("traditional");

  const handleNavigation = useCallback((section: string) => {
    const routeMap: { [key: string]: string } = {
      "dashboard": "/",
      "assessment-center": "/assessment-center",
      "standardized-tests": "/standardized-tests",
      "multi-iq-scoring": "/multi-iq-scoring",
      "dsm-integration": "/dsm-integration",
      "voice-assessment": "/voice-assessment",
      "eiq-analytics": "/eiq-analytics",
      "ai-features": "/ai-features",
      "learning-paths": "/learning-paths",
      "ai-agents": "/ai-agents"
    };
    const route = routeMap[section] || "/";
    setLocation(route);
  }, [setLocation]);

  // Real backend data integration with fallback structure
  const { data: iqScores } = useQuery({
    queryKey: ["/api/analytics/iq-scores"],
    staleTime: 5 * 60 * 1000, // 5 minutes
    gcTime: 10 * 60 * 1000, // 10 minutes
  });

  const { data: personalityData } = useQuery({
    queryKey: ["/api/analytics/personality-profile"],
    staleTime: 10 * 60 * 1000, // 10 minutes
    gcTime: 20 * 60 * 1000, // 20 minutes
  });

  // Fallback data structure
  const scoresData = (iqScores as any) ?? {
    traditional: { overall: 142, percentile: 95, verbal: 156, perceptual: 148, memory: 134, speed: 163 },
    emotional: { overall: 138, percentile: 89, selfAware: 145, selfReg: 142, socialAware: 135, relationships: 129 },
    alternative: { overall: 151, percentile: 96, creative: 167, practical: 144, musical: 139, naturalist: 155 }
  };

  const personalityProfile = (personalityData as any) ?? {
    disc: { dominance: 72, influence: 85, steadiness: 43, conscientiousness: 67, primaryType: "Influence", secondaryType: "Dominance" },
    ocean: { openness: 89, conscientiousness: 76, extraversion: 82, agreeableness: 67, neuroticism: 34 }
  };

  const iqCategories = [
    {
      id: "traditional",
      title: "Traditional IQ",
      description: "Classic intelligence measurement across cognitive domains",
      icon: Brain,
      color: "text-blue-500",
      bgColor: "bg-blue-500/10",
      borderColor: "border-blue-500/20",
      overallScore: scoresData.traditional.overall,
      percentile: scoresData.traditional.percentile,
      domains: [
        { 
          name: "Verbal Comprehension", 
          icon: MessageSquare, 
          score: scoresData.traditional.verbal, 
          percentile: 98,
          description: "Language and verbal reasoning skills"
        },
        { 
          name: "Perceptual Reasoning", 
          icon: Eye, 
          score: scoresData.traditional.perceptual, 
          percentile: 92,
          description: "Visual-spatial and fluid reasoning"
        },
        { 
          name: "Working Memory", 
          icon: Zap, 
          score: scoresData.traditional.memory, 
          percentile: 87,
          description: "Mental manipulation and retention"
        },
        { 
          name: "Processing Speed", 
          icon: Clock, 
          score: scoresData.traditional.speed, 
          percentile: 99,
          description: "Speed of cognitive processing"
        }
      ]
    },
    {
      id: "emotional",
      title: "Emotional Intelligence (EQ)",
      description: "Understanding and managing emotions effectively",
      icon: Heart,
      color: "text-red-500",
      bgColor: "bg-red-500/10",
      borderColor: "border-red-500/20",
      overallScore: scoresData.emotional.overall,
      percentile: scoresData.emotional.percentile,
      domains: [
        { 
          name: "Self-Awareness", 
          icon: Eye, 
          score: scoresData.emotional.selfAware, 
          percentile: 94,
          description: "Understanding your own emotions"
        },
        { 
          name: "Self-Regulation", 
          icon: Target, 
          score: scoresData.emotional.selfReg, 
          percentile: 91,
          description: "Managing emotional responses"
        },
        { 
          name: "Social Awareness", 
          icon: Users, 
          score: scoresData.emotional.socialAware, 
          percentile: 85,
          description: "Reading others' emotions"
        },
        { 
          name: "Relationship Management", 
          icon: Heart, 
          score: scoresData.emotional.relationships, 
          percentile: 79,
          description: "Building positive relationships"
        }
      ]
    },
    {
      id: "alternative",
      title: "Alternative Intelligence",
      description: "Creative, practical, and specialized intelligence forms",
      icon: Lightbulb,
      color: "text-purple-500",
      bgColor: "bg-purple-500/10",
      borderColor: "border-purple-500/20",
      overallScore: scoresData.alternative.overall,
      percentile: scoresData.alternative.percentile,
      domains: [
        { 
          name: "Creative Intelligence", 
          icon: Palette, 
          score: scoresData.alternative.creative, 
          percentile: 99,
          description: "Innovation and original thinking"
        },
        { 
          name: "Practical Intelligence", 
          icon: Target, 
          score: scoresData.alternative.practical, 
          percentile: 93,
          description: "Real-world problem solving"
        },
        { 
          name: "Musical Intelligence", 
          icon: Music, 
          score: scoresData.alternative.musical, 
          percentile: 88,
          description: "Rhythm, melody, and sound patterns"
        },
        { 
          name: "Naturalist Intelligence", 
          icon: TreePine, 
          score: scoresData.alternative.naturalist, 
          percentile: 97,
          description: "Understanding natural patterns"
        }
      ]
    }
  ];

  const currentCategory = iqCategories.find(cat => cat.id === activeCategory);
  const averageScore = Math.round(iqCategories.reduce((sum, cat) => sum + cat.overallScore, 0) / iqCategories.length);

  // DISC Assessment Data
  const discProfile = personalityProfile.disc;

  // Big Five (OCEAN) Data
  const oceanProfile = personalityProfile.ocean;

  const getScoreColor = (score: number) => {
    if (score >= 130) return "text-green-500";
    if (score >= 115) return "text-blue-500";
    if (score >= 100) return "text-yellow-500";
    return "text-orange-500";
  };

  const getScoreLabel = (score: number) => {
    if (score >= 145) return "Superior";
    if (score >= 130) return "Very Superior";
    if (score >= 115) return "High Average";
    if (score >= 100) return "Average";
    if (score >= 85) return "Low Average";
    return "Below Average";
  };

  return (
    <ModernLayout
      activeSection="multi-iq-scoring"
      onSectionChange={handleNavigation}
    >
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Multi-IQ Intelligence Assessment</h1>
            <p className="text-muted-foreground">
              Comprehensive intelligence measurement across traditional, emotional, and alternative domains
            </p>
          </div>
        <Badge variant="secondary" className="text-sm">
          <Brain className="w-4 h-4 mr-1" />
          Combined IQ: {averageScore}
        </Badge>
      </div>

      {/* Overall Summary */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Combined IQ Score</CardTitle>
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${getScoreColor(averageScore)}`}>{averageScore}</div>
            <p className="text-xs text-muted-foreground">{getScoreLabel(averageScore)}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Strongest Domain</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-500">Creative</div>
            <p className="text-xs text-muted-foreground">167 score (99th percentile)</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Growth Area</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-500">EQ Relations</div>
            <p className="text-xs text-muted-foreground">129 score (79th percentile)</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Assessment Progress</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">94%</div>
            <p className="text-xs text-muted-foreground">All domains evaluated</p>
          </CardContent>
        </Card>
      </div>

      {/* IQ Categories */}
      <Tabs value={activeCategory} onValueChange={setActiveCategory} className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          {iqCategories.map((category) => (
            <TabsTrigger key={category.id} value={category.id} className="flex items-center gap-2">
              <category.icon className="w-4 h-4" />
              {category.title.split(' ')[0]} {category.title.includes('IQ') ? 'IQ' : category.title.includes('Emotional') ? 'EQ' : 'AI'}
            </TabsTrigger>
          ))}
        </TabsList>

        {iqCategories.map((category) => (
          <TabsContent key={category.id} value={category.id} className="space-y-6">
            {/* Category Overview */}
            <Card className={`${category.borderColor} border-2`}>
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className={`p-3 rounded-lg ${category.bgColor}`}>
                    <category.icon className={`w-8 h-8 ${category.color}`} />
                  </div>
                  <div className="flex-1">
                    <CardTitle className="text-xl">{category.title}</CardTitle>
                    <CardDescription>{category.description}</CardDescription>
                  </div>
                  <div className="text-right">
                    <div className={`text-3xl font-bold ${getScoreColor(category.overallScore)}`}>
                      {category.overallScore}
                    </div>
                    <p className="text-sm text-muted-foreground">{category.percentile}th percentile</p>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                  <div>
                    <div className="text-lg font-semibold">{getScoreLabel(category.overallScore)}</div>
                    <p className="text-xs text-muted-foreground">Classification</p>
                  </div>
                  <div>
                    <div className="text-lg font-semibold">{category.domains.length}</div>
                    <p className="text-xs text-muted-foreground">Domains Tested</p>
                  </div>
                  <div>
                    <div className="text-lg font-semibold">
                      {Math.max(...category.domains.map(d => d.score))}
                    </div>
                    <p className="text-xs text-muted-foreground">Highest Score</p>
                  </div>
                  <div>
                    <div className="text-lg font-semibold">
                      {Math.min(...category.domains.map(d => d.score))}
                    </div>
                    <p className="text-xs text-muted-foreground">Lowest Score</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Domain Breakdown */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="w-5 h-5" />
                  Domain Performance
                </CardTitle>
                <CardDescription>
                  Detailed breakdown of {category.title.toLowerCase()} across specific cognitive domains
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {category.domains.map((domain, index) => (
                    <div key={index} className="space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <domain.icon className={`w-5 h-5 ${category.color}`} />
                          <div>
                            <h4 className="font-medium">{domain.name}</h4>
                            <p className="text-sm text-muted-foreground">{domain.description}</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className={`text-xl font-bold ${getScoreColor(domain.score)}`}>
                            {domain.score}
                          </div>
                          <p className="text-xs text-muted-foreground">{domain.percentile}th percentile</p>
                        </div>
                      </div>
                      <Progress value={domain.percentile} className="h-2" />
                      <div className="flex justify-between text-xs text-muted-foreground">
                        <span>{getScoreLabel(domain.score)}</span>
                        <span>Rank: {domain.percentile}/100</span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        ))}
      </Tabs>

      {/* Personality Assessments */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* DISC Assessment */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="w-5 h-5" />
              DISC Personality Profile
            </CardTitle>
            <CardDescription>
              Behavioral assessment across Dominance, Influence, Steadiness, and Conscientiousness
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="text-center mb-4">
                <div className="text-2xl font-bold text-primary">
                  {discProfile.primaryType}
                </div>
                <p className="text-sm text-muted-foreground">
                  Primary Type (Secondary: {discProfile.secondaryType})
                </p>
              </div>
              
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Dominance (D)</span>
                  <span className="text-sm">{discProfile.dominance}%</span>
                </div>
                <Progress value={discProfile.dominance} className="h-2" />
                
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Influence (I)</span>
                  <span className="text-sm">{discProfile.influence}%</span>
                </div>
                <Progress value={discProfile.influence} className="h-2" />
                
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Steadiness (S)</span>
                  <span className="text-sm">{discProfile.steadiness}%</span>
                </div>
                <Progress value={discProfile.steadiness} className="h-2" />
                
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Conscientiousness (C)</span>
                  <span className="text-sm">{discProfile.conscientiousness}%</span>
                </div>
                <Progress value={discProfile.conscientiousness} className="h-2" />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Big Five (OCEAN) Assessment */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Award className="w-5 h-5" />
              Big Five Personality Traits
            </CardTitle>
            <CardDescription>
              OCEAN model assessment of fundamental personality dimensions
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Openness</span>
                  <span className="text-sm">{oceanProfile.openness}%</span>
                </div>
                <Progress value={oceanProfile.openness} className="h-2" />
                
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Conscientiousness</span>
                  <span className="text-sm">{oceanProfile.conscientiousness}%</span>
                </div>
                <Progress value={oceanProfile.conscientiousness} className="h-2" />
                
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Extraversion</span>
                  <span className="text-sm">{oceanProfile.extraversion}%</span>
                </div>
                <Progress value={oceanProfile.extraversion} className="h-2" />
                
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Agreeableness</span>
                  <span className="text-sm">{oceanProfile.agreeableness}%</span>
                </div>
                <Progress value={oceanProfile.agreeableness} className="h-2" />
                
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Neuroticism</span>
                  <span className="text-sm">{oceanProfile.neuroticism}%</span>
                </div>
                <Progress value={oceanProfile.neuroticism} className="h-2" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recommendations */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5" />
            AI-Powered Recommendations
          </CardTitle>
          <CardDescription>
            Personalized strategies to enhance your cognitive abilities and emotional intelligence
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <h4 className="font-medium text-sm text-green-500">Leverage Strengths</h4>
              <ul className="space-y-1 text-sm text-muted-foreground">
                <li>• Use your creative intelligence for innovative problem-solving</li>
                <li>• Apply high processing speed to time-sensitive tasks</li>
                <li>• Leverage verbal skills in communication-heavy roles</li>
              </ul>
            </div>
            <div className="space-y-2">
              <h4 className="font-medium text-sm text-blue-500">Skill Development</h4>
              <ul className="space-y-1 text-sm text-muted-foreground">
                <li>• Practice relationship management techniques</li>
                <li>• Engage in working memory training exercises</li>
                <li>• Develop steadiness through mindfulness practices</li>
              </ul>
            </div>
            <div className="space-y-2">
              <h4 className="font-medium text-sm text-purple-500">Learning Strategies</h4>
              <ul className="space-y-1 text-sm text-muted-foreground">
                <li>• Use visual learning for perceptual reasoning</li>
                <li>• Apply creative approaches to traditional problems</li>
                <li>• Practice emotional regulation in challenging situations</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
      </div>
    </ModernLayout>
  );
}