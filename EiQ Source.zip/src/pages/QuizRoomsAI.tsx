import { useState, useEffect, useRef } from "react";
import { useLocation } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  Users, 
  Brain, 
  Target, 
  Zap, 
  Clock, 
  Award, 
  TrendingUp, 
  MessageSquare,
  Play,
  Pause,
  Settings,
  Crown,
  Star,
  ChevronRight,
  Bot,
  Sparkles,
  BarChart3,
  Shield,
  Plus
} from "lucide-react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import ModernLayout from "@/components/layout/ModernLayout";
import { useCallback } from "react";

interface QuizRoom {
  id: string;
  name: string;
  description: string;
  maxPlayers: number;
  currentPlayers: number;
  difficulty: 'beginner' | 'intermediate' | 'advanced' | 'expert';
  category: string;
  isPrivate: boolean;
  aiEnhanced: boolean;
  estimatedDuration: number;
  createdBy: string;
  status: 'waiting' | 'active' | 'completed';
  aiRecommendations?: string[];
  competitorAnalysis?: {
    averageScore: number;
    strongestSubjects: string[];
    predictedDifficulty: number;
  };
}

interface AIMatchmakingData {
  recommendedRooms: QuizRoom[];
  skillLevel: number;
  strengths: string[];
  improvementAreas: string[];
  personalizedTips: string[];
}

interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
  aiGenerated: boolean;
  difficulty: number;
  category: string;
  explanation?: string;
  aiHint?: string;
}

export default function QuizRoomsAI() {
  const [, setLocation] = useLocation();
  
  const handleSectionChange = useCallback((section: string) => {
    if (section === "dashboard") {
      setLocation("/");
    } else {
      const route = section.includes("-") ? `/${section}` : `/${section.replace("_", "-")}`;
      setLocation(route);
    }
  }, [setLocation]);

  const [selectedRoom, setSelectedRoom] = useState<QuizRoom | null>(null);
  const [currentQuestion, setCurrentQuestion] = useState<QuizQuestion | null>(null);
  const [isInRoom, setIsInRoom] = useState(false);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [roomFilter, setRoomFilter] = useState('all');
  const [showAIInsights, setShowAIInsights] = useState(false);
  const websocketRef = useRef<WebSocket | null>(null);
  const { toast } = useToast();

  // AI Matchmaking Data
  const { data: aiMatchmaking } = useQuery<AIMatchmakingData>({
    queryKey: ["/api/quiz-rooms/ai-matchmaking"],
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  // Available Quiz Rooms
  const { data: quizRooms, refetch: refetchRooms } = useQuery<QuizRoom[]>({
    queryKey: ["/api/quiz-rooms", roomFilter],
    staleTime: 30 * 1000, // 30 seconds
  });

  // Dynamic AI Question Generation
  const generateAIQuestionMutation = useMutation({
    mutationFn: async ({ difficulty, category, userProfile }: { 
      difficulty: string; 
      category: string; 
      userProfile: any;
    }) => {
      return apiRequest("POST", "/api/quiz-rooms/generate-question", {
        difficulty,
        category,
        userProfile,
        includeHint: true,
        adaptToPreviousAnswers: true
      });
    },
    onSuccess: (question) => {
      setCurrentQuestion(question);
      toast({
        title: "AI Question Generated",
        description: "Personalized question created based on your performance",
      });
    }
  });

  // Join Room with AI Analysis
  const joinRoomMutation = useMutation({
    mutationFn: async (roomId: string) => {
      return apiRequest("POST", `/api/quiz-rooms/${roomId}/join`);
    },
    onSuccess: (data) => {
      setIsInRoom(true);
      setSelectedRoom(data.room);
      
      // Show AI competitor analysis
      if (data.aiAnalysis) {
        toast({
          title: "AI Analysis Complete",
          description: `Competitor strength: ${data.aiAnalysis.averageScore}/100. ${data.aiAnalysis.personalizedTips[0]}`,
        });
      }
      
      // Initialize WebSocket for real-time updates
      initializeWebSocket(data.room.id);
    }
  });

  // Create Enhanced AI Room
  const createRoomMutation = useMutation({
    mutationFn: async (roomData: Partial<QuizRoom>) => {
      return apiRequest("POST", "/api/quiz-rooms/create", {
        ...roomData,
        aiEnhanced: true,
        generatePersonalizedQuestions: true
      });
    },
    onSuccess: (room) => {
      setSelectedRoom(room);
      refetchRooms();
      toast({
        title: "AI Quiz Room Created",
        description: "Room created with personalized AI question generation",
      });
    }
  });

  const initializeWebSocket = (roomId: string) => {
    if (websocketRef.current) {
      websocketRef.current.close();
    }

    const token = localStorage.getItem('auth_token');
    const ws = new WebSocket(`ws://localhost:3000/ws?token=${token}&room=quiz_${roomId}`);
    
    ws.onopen = () => {
      console.log('[QUIZ ROOMS] WebSocket connected');
      ws.send(JSON.stringify({
        type: 'join_quiz_room',
        roomId: roomId
      }));
    };

    ws.onmessage = (event) => {
      const data = JSON.parse(event.data);
      handleWebSocketMessage(data);
    };

    ws.onclose = () => {
      console.log('[QUIZ ROOMS] WebSocket disconnected');
    };

    websocketRef.current = ws;
  };

  const handleWebSocketMessage = (data: any) => {
    switch (data.type) {
      case 'new_question':
        setCurrentQuestion(data.question);
        setSelectedAnswer(null);
        break;
      case 'room_update':
        if (selectedRoom) {
          setSelectedRoom({ ...selectedRoom, ...data.updates });
        }
        break;
      case 'ai_hint':
        toast({
          title: "AI Hint",
          description: data.hint,
        });
        break;
      case 'competitor_joined':
        toast({
          title: "New Competitor",
          description: `${data.username} joined. AI predicts strong performance in ${data.strengths.join(', ')}`,
        });
        break;
    }
  };

  useEffect(() => {
    return () => {
      if (websocketRef.current) {
        websocketRef.current.close();
      }
    };
  }, []);

  const aiEnhancedRooms = [
    {
      id: "ai-adaptive-math",
      name: "AI Adaptive Mathematics",
      description: "Dynamic question generation based on your math performance",
      maxPlayers: 6,
      currentPlayers: 3,
      difficulty: 'intermediate' as const,
      category: "Mathematics",
      isPrivate: false,
      aiEnhanced: true,
      estimatedDuration: 15,
      createdBy: "AI System",
      status: 'waiting' as const,
      aiRecommendations: [
        "Focus on algebra fundamentals first",
        "Practice time management with 2-minute questions",
        "Use AI hints strategically for complex problems"
      ],
      competitorAnalysis: {
        averageScore: 78.5,
        strongestSubjects: ["Geometry", "Statistics"],
        predictedDifficulty: 7.2
      }
    },
    {
      id: "ai-science-challenge",
      name: "AI Science Challenge",
      description: "Multi-domain science quiz with AI performance tracking",
      maxPlayers: 8,
      currentPlayers: 5,
      difficulty: 'advanced' as const,
      category: "Science",
      isPrivate: false,
      aiEnhanced: true,
      estimatedDuration: 20,
      createdBy: "Dr. AI",
      status: 'active' as const,
      aiRecommendations: [
        "Review physics concepts before joining",
        "Chemistry questions will be formula-heavy",
        "Biology section focuses on cellular processes"
      ],
      competitorAnalysis: {
        averageScore: 85.3,
        strongestSubjects: ["Physics", "Chemistry"],
        predictedDifficulty: 8.1
      }
    }
  ];

  const renderQuizRoomCard = (room: QuizRoom) => (
    <Card key={room.id} className="border-border hover:border-primary/50 transition-all duration-200">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-lg flex items-center gap-2">
              {room.aiEnhanced && <Bot className="w-5 h-5 text-primary" />}
              {room.name}
            </CardTitle>
            <CardDescription className="text-sm">
              {room.description}
            </CardDescription>
          </div>
          <Badge 
            variant={room.status === 'active' ? 'default' : room.status === 'waiting' ? 'secondary' : 'outline'}
          >
            {room.status}
          </Badge>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        <div className="flex items-center justify-between text-sm">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1">
              <Users className="w-4 h-4 text-muted-foreground" />
              <span>{room.currentPlayers}/{room.maxPlayers}</span>
            </div>
            <div className="flex items-center gap-1">
              <Clock className="w-4 h-4 text-muted-foreground" />
              <span>{room.estimatedDuration}min</span>
            </div>
            <div className="flex items-center gap-1">
              <Target className="w-4 h-4 text-muted-foreground" />
              <span className="capitalize">{room.difficulty}</span>
            </div>
          </div>
          <Badge variant="outline" className="text-xs">
            {room.category}
          </Badge>
        </div>

        {room.aiEnhanced && room.competitorAnalysis && (
          <div className="bg-primary/5 rounded-lg p-3 space-y-2">
            <div className="flex items-center gap-2">
              <Brain className="w-4 h-4 text-primary" />
              <span className="text-sm font-medium text-primary">AI Analysis</span>
            </div>
            <div className="text-xs space-y-1">
              <div>Avg Score: {room.competitorAnalysis.averageScore}/100</div>
              <div>Strong in: {room.competitorAnalysis.strongestSubjects.join(', ')}</div>
              <div className="flex items-center gap-1">
                <span>Difficulty:</span>
                <Progress 
                  value={room.competitorAnalysis.predictedDifficulty * 10} 
                  className="w-16 h-2"
                />
                <span>{room.competitorAnalysis.predictedDifficulty}/10</span>
              </div>
            </div>
          </div>
        )}

        {room.aiRecommendations && (
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-yellow-500" />
              <span className="text-sm font-medium">AI Recommendations</span>
            </div>
            <ul className="text-xs space-y-1">
              {room.aiRecommendations.slice(0, 2).map((rec, idx) => (
                <li key={idx} className="flex items-start gap-1">
                  <ChevronRight className="w-3 h-3 text-muted-foreground mt-0.5" />
                  <span>{rec}</span>
                </li>
              ))}
            </ul>
          </div>
        )}

        <div className="flex gap-2">
          <Button 
            onClick={() => joinRoomMutation.mutate(room.id)}
            disabled={joinRoomMutation.isPending || room.currentPlayers >= room.maxPlayers}
            className="flex-1"
            size="sm"
          >
            {room.status === 'waiting' ? 'Join Room' : 'Spectate'}
          </Button>
          <Button variant="outline" size="sm">
            <BarChart3 className="w-4 h-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );

  const renderContent = () => (
    <div className="container mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-3">
            <Bot className="w-8 h-8 text-primary" />
            AI Quiz Rooms
          </h1>
          <p className="text-muted-foreground mt-2">
            Intelligent multiplayer assessments with dynamic question generation and competitor analysis
          </p>
        </div>

        <div className="flex gap-2">
          <Button 
            onClick={() => setShowAIInsights(!showAIInsights)}
            variant="outline"
          >
            <Brain className="w-4 h-4 mr-2" />
            AI Insights
          </Button>
          <Button onClick={() => createRoomMutation.mutate({
            name: "Custom AI Room",
            description: "Personalized quiz room",
            maxPlayers: 6,
            difficulty: 'intermediate',
            category: "Mixed"
          })}>
            <Plus className="w-4 h-4 mr-2" />
            Create Room
          </Button>
        </div>
      </div>

      <Tabs defaultValue="rooms" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="rooms">Available Rooms</TabsTrigger>
          <TabsTrigger value="ai-matchmaking">AI Matchmaking</TabsTrigger>
          <TabsTrigger value="active-game">Active Game</TabsTrigger>
          <TabsTrigger value="leaderboard">Leaderboard</TabsTrigger>
        </TabsList>

        <TabsContent value="rooms" className="space-y-6">
          <div className="flex gap-4 items-center">
            <div className="flex gap-2">
              {['all', 'ai-enhanced', 'beginner', 'intermediate', 'advanced'].map((filter) => (
                <Button
                  key={filter}
                  variant={roomFilter === filter ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setRoomFilter(filter)}
                >
                  {filter.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase())}
                </Button>
              ))}
            </div>
          </div>

          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {aiEnhancedRooms.map(renderQuizRoomCard)}
            {quizRooms?.map(renderQuizRoomCard)}
          </div>
        </TabsContent>

        <TabsContent value="ai-matchmaking" className="space-y-6">
          {aiMatchmaking ? (
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Brain className="w-5 h-5 text-primary" />
                    Your AI Profile
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center gap-4">
                    <div>
                      <div className="text-2xl font-bold text-primary">
                        Level {aiMatchmaking.skillLevel}
                      </div>
                      <div className="text-sm text-muted-foreground">Skill Level</div>
                    </div>
                    <div className="flex-1">
                      <Progress value={aiMatchmaking.skillLevel * 10} className="w-full" />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <h4 className="font-medium mb-2 text-green-600">Strengths</h4>
                      <ul className="text-sm space-y-1">
                        {aiMatchmaking.strengths.map((strength, idx) => (
                          <li key={idx} className="flex items-center gap-2">
                            <Star className="w-3 h-3 text-green-500" />
                            {strength}
                          </li>
                        ))}
                      </ul>
                    </div>
                    <div>
                      <h4 className="font-medium mb-2 text-orange-600">Growth Areas</h4>
                      <ul className="text-sm space-y-1">
                        {aiMatchmaking.improvementAreas.map((area, idx) => (
                          <li key={idx} className="flex items-center gap-2">
                            <TrendingUp className="w-3 h-3 text-orange-500" />
                            {area}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <div>
                <h3 className="text-lg font-semibold mb-4">Recommended Rooms</h3>
                <div className="grid gap-4 md:grid-cols-2">
                  {aiMatchmaking.recommendedRooms.map(renderQuizRoomCard)}
                </div>
              </div>
            </div>
          ) : (
            <Card>
              <CardContent className="flex items-center justify-center py-12">
                <div className="text-center">
                  <Brain className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-medium mb-2">AI Analysis Loading</h3>
                  <p className="text-muted-foreground">Building your personalized profile...</p>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="active-game">
          {isInRoom && currentQuestion ? (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>Question {1} of 10</span>
                  <Badge variant="secondary">
                    <Clock className="w-3 h-3 mr-1" />
                    30s
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <h3 className="text-lg font-medium mb-4">{currentQuestion.question}</h3>
                  <div className="grid gap-2">
                    {currentQuestion.options.map((option, idx) => (
                      <Button
                        key={idx}
                        variant={selectedAnswer === idx ? 'default' : 'outline'}
                        className="justify-start text-left"
                        onClick={() => setSelectedAnswer(idx)}
                      >
                        <span className="w-6 h-6 rounded-full bg-muted flex items-center justify-center text-sm mr-3">
                          {String.fromCharCode(65 + idx)}
                        </span>
                        {option}
                      </Button>
                    ))}
                  </div>
                </div>

                {currentQuestion.aiHint && (
                  <div className="bg-blue-50 dark:bg-blue-950/20 border border-blue-200 dark:border-blue-800 rounded-lg p-3">
                    <div className="flex items-center gap-2 mb-2">
                      <Sparkles className="w-4 h-4 text-blue-500" />
                      <span className="text-sm font-medium text-blue-700 dark:text-blue-300">AI Hint</span>
                    </div>
                    <p className="text-sm text-blue-600 dark:text-blue-400">
                      {currentQuestion.aiHint}
                    </p>
                  </div>
                )}

                <div className="flex gap-2">
                  <Button 
                    disabled={selectedAnswer === null}
                    className="flex-1"
                  >
                    Submit Answer
                  </Button>
                  <Button variant="outline">
                    <Bot className="w-4 h-4 mr-2" />
                    Get AI Hint
                  </Button>
                </div>
              </CardContent>
            </Card>
          ) : (
            <Card>
              <CardContent className="flex items-center justify-center py-12">
                <div className="text-center">
                  <Play className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-medium mb-2">No Active Game</h3>
                  <p className="text-muted-foreground">Join a room to start playing</p>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="leaderboard">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Crown className="w-5 h-5 text-yellow-500" />
                Global Leaderboard
              </CardTitle>
              <CardDescription>
                Top performers across all AI quiz rooms
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[1,2,3,4,5].map((rank) => (
                  <div key={rank} className="flex items-center gap-4 p-3 rounded-lg border">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold ${
                      rank === 1 ? 'bg-yellow-100 text-yellow-800' :
                      rank === 2 ? 'bg-gray-100 text-gray-800' :
                      rank === 3 ? 'bg-orange-100 text-orange-800' :
                      'bg-muted text-muted-foreground'
                    }`}>
                      {rank}
                    </div>
                    <div className="flex-1">
                      <div className="font-medium">Player {rank}</div>
                      <div className="text-sm text-muted-foreground">
                        {Math.floor(Math.random() * 50) + 50} games played
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-medium">{95 - rank}% Win Rate</div>
                      <div className="text-sm text-muted-foreground">
                        {1000 - rank * 50} EiQ Points
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );

  return (
    <ModernLayout 
      activeSection="quiz-rooms-ai"
      onSectionChange={handleSectionChange}
    >
      {renderContent()}
    </ModernLayout>
  );
}