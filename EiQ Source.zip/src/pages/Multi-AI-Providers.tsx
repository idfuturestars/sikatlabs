import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { 
  Bot, 
  Zap, 
  Settings,
  Activity,
  Cpu,
  Globe,
  Shield,
  TrendingUp,
  DollarSign,
  Clock,
  BarChart3,
  AlertTriangle,
  CheckCircle,
  LineChart,
  Gauge,
  Eye,
  Wrench,
  RefreshCw
} from "lucide-react";
import { useState } from "react";

interface AIProvider {
  id: string;
  name: string;
  status: "active" | "standby" | "inactive" | "error";
  usage: number;
  responseTime: number;
  accuracy: number;
  costPerQuery: number;
  capabilities: string[];
  requests24h: number;
  errors24h: number;
  lastUsed: string;
  modelVersion: string;
}

interface UsageMetrics {
  totalQueries: number;
  averageResponseTime: number;
  successRate: number;
  dailyCost: number;
  costTrend: number;
  queryTrend: number;
  performanceTrend: number;
}

interface ProviderAnalytics {
  provider: string;
  queries: number;
  cost: number;
  averageLatency: number;
  errorRate: number;
  popularCapabilities: string[];
}

export default function MultiAIProviders() {
  const [activeTab, setActiveTab] = useState("overview");
  const queryClient = useQueryClient();
  const { toast } = useToast();

  // Fetch AI agents and their status
  const { data: aiAgents, isLoading: agentsLoading } = useQuery<AIProvider[]>({
    queryKey: ["/api/ai-agents"],
    refetchInterval: 30000, // Refresh every 30 seconds for real-time updates
    staleTime: 15000, // 15 seconds stale time for frequent updates
  });

  // Fetch active sessions for usage tracking
  const { data: activeSessions } = useQuery({
    queryKey: ["/api/ai-agents/sessions"],
    refetchInterval: 10000, // Refresh every 10 seconds
  });

  // Fetch usage analytics
  const { data: usageMetrics } = useQuery<UsageMetrics>({
    queryKey: ["/api/ai-agents/analytics"],
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  // Fetch provider-specific analytics
  const { data: providerAnalytics } = useQuery<ProviderAnalytics[]>({
    queryKey: ["/api/ai-agents/provider-analytics"],
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  // Fetch privacy and security controls
  const { data: privacyControls } = useQuery({
    queryKey: ["/api/ai-agents/privacy-controls"],
    staleTime: 10 * 60 * 1000, // 10 minutes
  });

  // Toggle provider status
  const toggleProviderMutation = useMutation({
    mutationFn: async ({ providerId, status }: { providerId: string; status: string }) => {
      return await apiRequest(`/api/ai-agents/${providerId}/status`, {
        method: "PATCH",
        body: { status }
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/ai-agents"] });
      toast({
        title: "Provider Status Updated",
        description: "AI provider status has been successfully changed.",
      });
    },
    onError: () => {
      toast({
        title: "Update Failed",
        description: "Failed to update provider status. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Test provider connection
  const testConnectionMutation = useMutation({
    mutationFn: async (providerId: string) => {
      return await apiRequest(`/api/ai-agents/${providerId}/test`, {
        method: "POST"
      });
    },
    onSuccess: (data, providerId) => {
      toast({
        title: "Connection Test Successful",
        description: `${providerId} is responding normally.`,
      });
    },
    onError: (error, providerId) => {
      toast({
        title: "Connection Test Failed",
        description: `${providerId} is not responding properly.`,
        variant: "destructive",
      });
    },
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active": return "bg-green-100 text-green-800";
      case "standby": return "bg-yellow-100 text-yellow-800";
      case "error": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "active": return <CheckCircle className="w-4 h-4 text-green-500" />;
      case "error": return <AlertTriangle className="w-4 h-4 text-red-500" />;
      default: return <Clock className="w-4 h-4 text-yellow-500" />;
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
    }).format(amount);
  };

  const formatNumber = (num: number) => {
    return new Intl.NumberFormat('en-US').format(num);
  };

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-4">
          <h1 className="text-4xl font-bold gradient-text">AI Providers & Analytics</h1>
          <p className="text-muted-foreground max-w-3xl mx-auto">
            Comprehensive management dashboard for OpenAI, Anthropic, Gemini providers with real-time usage tracking, cost monitoring, and performance analytics
          </p>
        </div>

        {/* Real-time System Overview */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Activity className="w-5 h-5" />
              Real-time System Performance
            </CardTitle>
            <p className="text-muted-foreground">Live metrics updating every 30 seconds</p>
          </CardHeader>
          <CardContent>
            {usageMetrics ? (
              <div className="grid gap-4 md:grid-cols-4">
                <div className="text-center p-4 bg-blue-50 rounded-lg">
                  <div className="text-3xl font-bold text-blue-600">{formatNumber(usageMetrics.totalQueries)}</div>
                  <div className="text-sm text-muted-foreground">Total Queries Today</div>
                  <div className={`text-xs ${usageMetrics.queryTrend >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                    {usageMetrics.queryTrend >= 0 ? '+' : ''}{usageMetrics.queryTrend}% vs yesterday
                  </div>
                </div>
                <div className="text-center p-4 bg-green-50 rounded-lg">
                  <div className="text-3xl font-bold text-green-600">{usageMetrics.averageResponseTime.toFixed(1)}s</div>
                  <div className="text-sm text-muted-foreground">Avg Response Time</div>
                  <div className={`text-xs ${usageMetrics.performanceTrend <= 0 ? 'text-green-600' : 'text-red-600'}`}>
                    {usageMetrics.performanceTrend <= 0 ? '' : '+'}{usageMetrics.performanceTrend}% vs yesterday
                  </div>
                </div>
                <div className="text-center p-4 bg-purple-50 rounded-lg">
                  <div className="text-3xl font-bold text-purple-600">{usageMetrics.successRate.toFixed(1)}%</div>
                  <div className="text-sm text-muted-foreground">Success Rate</div>
                  <div className="text-xs text-green-600">99.9% uptime</div>
                </div>
                <div className="text-center p-4 bg-orange-50 rounded-lg">
                  <div className="text-3xl font-bold text-orange-600">{formatCurrency(usageMetrics.dailyCost)}</div>
                  <div className="text-sm text-muted-foreground">Daily Cost</div>
                  <div className={`text-xs ${usageMetrics.costTrend >= 0 ? 'text-red-600' : 'text-green-600'}`}>
                    {usageMetrics.costTrend >= 0 ? '+' : ''}{usageMetrics.costTrend}% vs yesterday
                  </div>
                </div>
              </div>
            ) : (
              <div className="animate-pulse grid gap-4 md:grid-cols-4">
                {[...Array(4)].map((_, i) => (
                  <div key={i} className="h-20 bg-muted rounded-lg"></div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Provider Overview</TabsTrigger>
            <TabsTrigger value="analytics">Usage Analytics</TabsTrigger>
            <TabsTrigger value="costs">Cost Analysis</TabsTrigger>
            <TabsTrigger value="settings">Security & Settings</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            {/* AI Provider Management */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Cpu className="w-5 h-5" />
                  AI Provider Status & Controls
                </CardTitle>
                <p className="text-muted-foreground">Manage OpenAI, Anthropic, and Gemini providers with real-time switching</p>
              </CardHeader>
              <CardContent>
                {agentsLoading ? (
                  <div className="space-y-4">
                    {[...Array(3)].map((_, i) => (
                      <div key={i} className="animate-pulse border rounded-lg p-4">
                        <div className="h-6 bg-muted rounded w-1/3 mb-4"></div>
                        <div className="grid gap-4 md:grid-cols-4">
                          {[...Array(4)].map((_, j) => (
                            <div key={j} className="h-16 bg-muted rounded"></div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                ) : aiAgents ? (
                  <div className="space-y-4">
                    {aiAgents.map((provider) => (
                      <div key={provider.id} className="border rounded-lg p-4">
                        <div className="flex items-center justify-between mb-4">
                          <div className="flex items-center gap-3">
                            {getStatusIcon(provider.status)}
                            <div>
                              <h4 className="font-medium flex items-center gap-2">
                                {provider.name}
                                <Badge variant="outline" className="text-xs">
                                  {provider.modelVersion}
                                </Badge>
                              </h4>
                              <p className="text-sm text-muted-foreground">
                                Cost: {formatCurrency(provider.costPerQuery)}/query • Last used: {provider.lastUsed}
                              </p>
                            </div>
                          </div>
                          <div className="flex items-center gap-3">
                            <Badge className={getStatusColor(provider.status)}>
                              {provider.status}
                            </Badge>
                            <Switch 
                              checked={provider.status === "active"} 
                              onCheckedChange={(checked) => 
                                toggleProviderMutation.mutate({
                                  providerId: provider.id,
                                  status: checked ? "active" : "standby"
                                })
                              }
                              disabled={toggleProviderMutation.isPending}
                              className="data-[state=checked]:bg-green-600"
                            />
                          </div>
                        </div>
                        
                        <div className="grid gap-4 md:grid-cols-5 mb-4">
                          <div>
                            <div className="text-sm text-muted-foreground">Usage Share</div>
                            <div className="text-lg font-bold">{provider.usage}%</div>
                            <Progress value={provider.usage} className="h-2 mt-1" />
                          </div>
                          <div>
                            <div className="text-sm text-muted-foreground">Response Time</div>
                            <div className="text-lg font-bold">{provider.responseTime.toFixed(1)}s</div>
                            <div className={`text-xs ${provider.responseTime < 2 ? 'text-green-600' : 'text-orange-600'}`}>
                              {provider.responseTime < 2 ? 'Excellent' : 'Needs attention'}
                            </div>
                          </div>
                          <div>
                            <div className="text-sm text-muted-foreground">24h Requests</div>
                            <div className="text-lg font-bold">{formatNumber(provider.requests24h)}</div>
                            <div className="text-xs text-muted-foreground">
                              {provider.errors24h} errors
                            </div>
                          </div>
                          <div>
                            <div className="text-sm text-muted-foreground">Accuracy</div>
                            <div className="text-lg font-bold">{provider.accuracy}%</div>
                            <div className={`text-xs ${provider.accuracy >= 95 ? 'text-green-600' : 'text-orange-600'}`}>
                              {provider.accuracy >= 95 ? 'Excellent' : 'Good'}
                            </div>
                          </div>
                          <div>
                            <div className="text-sm text-muted-foreground">Capabilities</div>
                            <div className="flex flex-wrap gap-1 mt-1">
                              {provider.capabilities.slice(0, 2).map((cap) => (
                                <Badge key={cap} variant="outline" className="text-xs">
                                  {cap}
                                </Badge>
                              ))}
                              {provider.capabilities.length > 2 && (
                                <Badge variant="outline" className="text-xs">
                                  +{provider.capabilities.length - 2}
                                </Badge>
                              )}
                            </div>
                          </div>
                        </div>
                        
                        <div className="flex gap-2">
                          <Button 
                            size="sm" 
                            variant="outline"
                            onClick={() => testConnectionMutation.mutate(provider.id)}
                            disabled={testConnectionMutation.isPending}
                          >
                            <RefreshCw className={`w-3 h-3 mr-1 ${testConnectionMutation.isPending ? 'animate-spin' : ''}`} />
                            Test Connection
                          </Button>
                          <Button size="sm" variant="outline">
                            <Wrench className="w-3 h-3 mr-1" />
                            Configure
                          </Button>
                          <Button size="sm" variant="outline">
                            <Eye className="w-3 h-3 mr-1" />
                            View Logs
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <Bot className="w-16 h-16 mx-auto mb-4 text-muted-foreground opacity-50" />
                    <h3 className="text-lg font-medium mb-2">No Providers Configured</h3>
                    <p className="text-muted-foreground mb-4">Set up your AI providers to start using the platform</p>
                    <Button>Configure Providers</Button>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Active Sessions */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Globe className="w-5 h-5" />
                  Active Sessions & Load Distribution
                </CardTitle>
              </CardHeader>
              <CardContent>
                {activeSessions ? (
                  <div className="grid md:grid-cols-3 gap-6">
                    <div className="text-center p-4 bg-muted/30 rounded-lg">
                      <div className="text-2xl font-bold text-primary">{activeSessions.total || 0}</div>
                      <div className="text-sm text-muted-foreground">Active Sessions</div>
                    </div>
                    <div className="text-center p-4 bg-muted/30 rounded-lg">
                      <div className="text-2xl font-bold text-green-600">{activeSessions.queued || 0}</div>
                      <div className="text-sm text-muted-foreground">Queued Requests</div>
                    </div>
                    <div className="text-center p-4 bg-muted/30 rounded-lg">
                      <div className="text-2xl font-bold text-blue-600">{activeSessions.processing || 0}</div>
                      <div className="text-sm text-muted-foreground">Processing</div>
                    </div>
                  </div>
                ) : (
                  <div className="animate-pulse grid md:grid-cols-3 gap-6">
                    {[...Array(3)].map((_, i) => (
                      <div key={i} className="h-20 bg-muted rounded-lg"></div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6">
            {/* Provider Analytics */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="w-5 h-5" />
                  Provider Performance Analytics
                </CardTitle>
                <p className="text-muted-foreground">Detailed usage patterns and performance metrics by provider</p>
              </CardHeader>
              <CardContent>
                {providerAnalytics && providerAnalytics.length > 0 ? (
                  <div className="space-y-6">
                    {providerAnalytics.map((analytics) => (
                      <div key={analytics.provider} className="border rounded-lg p-4">
                        <h3 className="text-lg font-semibold mb-4">{analytics.provider} Analytics</h3>
                        <div className="grid md:grid-cols-4 gap-4">
                          <div className="text-center p-3 bg-blue-50 rounded">
                            <div className="text-2xl font-bold text-blue-600">{formatNumber(analytics.queries)}</div>
                            <div className="text-xs text-muted-foreground">Total Queries</div>
                          </div>
                          <div className="text-center p-3 bg-green-50 rounded">
                            <div className="text-2xl font-bold text-green-600">{formatCurrency(analytics.cost)}</div>
                            <div className="text-xs text-muted-foreground">Total Cost</div>
                          </div>
                          <div className="text-center p-3 bg-purple-50 rounded">
                            <div className="text-2xl font-bold text-purple-600">{analytics.averageLatency.toFixed(1)}s</div>
                            <div className="text-xs text-muted-foreground">Avg Latency</div>
                          </div>
                          <div className="text-center p-3 bg-orange-50 rounded">
                            <div className="text-2xl font-bold text-orange-600">{analytics.errorRate.toFixed(2)}%</div>
                            <div className="text-xs text-muted-foreground">Error Rate</div>
                          </div>
                        </div>
                        <div className="mt-4">
                          <h4 className="font-medium mb-2">Popular Capabilities</h4>
                          <div className="flex flex-wrap gap-2">
                            {analytics.popularCapabilities.map((capability, i) => (
                              <Badge key={i} variant="outline" className="text-xs">
                                {capability}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <LineChart className="w-16 h-16 mx-auto mb-4 text-muted-foreground opacity-50" />
                    <h3 className="text-lg font-medium mb-2">No Analytics Data</h3>
                    <p className="text-muted-foreground">Analytics data will appear after some usage</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="costs" className="space-y-6">
            {/* Cost Analysis */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <DollarSign className="w-5 h-5" />
                  Cost Analysis & Optimization
                </CardTitle>
                <p className="text-muted-foreground">Detailed cost breakdown and optimization opportunities</p>
              </CardHeader>
              <CardContent>
                {providerAnalytics && providerAnalytics.length > 0 ? (
                  <div className="space-y-6">
                    <div className="grid md:grid-cols-3 gap-4">
                      {providerAnalytics.map((analytics) => (
                        <div key={analytics.provider} className="text-center p-4 border rounded-lg">
                          <h4 className="font-medium mb-2">{analytics.provider}</h4>
                          <div className="text-2xl font-bold text-primary mb-1">
                            {formatCurrency(analytics.cost)}
                          </div>
                          <div className="text-sm text-muted-foreground">
                            {formatNumber(analytics.queries)} queries
                          </div>
                          <div className="text-xs text-muted-foreground mt-1">
                            {formatCurrency(analytics.cost / analytics.queries)} per query
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Cost Optimization Recommendations */}
                    <div className="mt-8">
                      <h3 className="text-lg font-semibold mb-4">Cost Optimization Recommendations</h3>
                      <div className="space-y-3">
                        <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                          <h4 className="font-medium text-green-700 mb-1">Potential Savings: $15.40/day</h4>
                          <p className="text-sm text-green-600">
                            Route simple queries to lower-cost providers to reduce overall expenses
                          </p>
                        </div>
                        <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                          <h4 className="font-medium text-blue-700 mb-1">Load Balancing Optimization</h4>
                          <p className="text-sm text-blue-600">
                            Implement intelligent routing based on query complexity and cost
                          </p>
                        </div>
                        <div className="p-4 bg-yellow-50 rounded-lg border border-yellow-200">
                          <h4 className="font-medium text-yellow-700 mb-1">Usage Pattern Alert</h4>
                          <p className="text-sm text-yellow-600">
                            High-cost queries detected during peak hours. Consider scheduling or caching.
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <DollarSign className="w-16 h-16 mx-auto mb-4 text-muted-foreground opacity-50" />
                    <h3 className="text-lg font-medium mb-2">No Cost Data Available</h3>
                    <p className="text-muted-foreground">Cost analysis will appear after some usage</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settings" className="space-y-6">
            {/* Security & Privacy Controls */}
            <div className="grid lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Shield className="w-5 h-5" />
                    Security & Compliance
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Data encryption in transit</span>
                    <Badge className="bg-green-100 text-green-800">Enabled</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Query logging</span>
                    <Switch 
                      checked={privacyControls?.queryLogging || false}
                      className="data-[state=checked]:bg-green-600"
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">PII filtering</span>
                    <Switch 
                      checked={privacyControls?.piiFiltering || false}
                      className="data-[state=checked]:bg-green-600"
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Rate limiting</span>
                    <Switch 
                      checked={privacyControls?.rateLimiting || false}
                      className="data-[state=checked]:bg-green-600"
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Audit logging</span>
                    <Switch 
                      checked={privacyControls?.auditLogging || false}
                      className="data-[state=checked]:bg-green-600"
                    />
                  </div>
                  <Button className="w-full" variant="outline">
                    Configure Advanced Security
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="w-5 h-5" />
                    System Health & Alerts
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-3 bg-green-50 rounded-lg border border-green-200">
                    <div className="flex items-center gap-2 mb-1">
                      <CheckCircle className="w-4 h-4 text-green-500" />
                      <span className="font-medium text-green-700">All Systems Operational</span>
                    </div>
                    <p className="text-sm text-green-600">All AI providers responding normally</p>
                  </div>
                  
                  <div className="space-y-2">
                    <h4 className="font-medium">Alert Thresholds</h4>
                    <div className="text-sm space-y-1">
                      <div className="flex justify-between">
                        <span>Response time &gt;3s</span>
                        <Badge variant="outline">Monitoring</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span>Error rate &gt;5%</span>
                        <Badge variant="outline">Monitoring</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span>Daily cost &gt;$50</span>
                        <Badge variant="outline">Monitoring</Badge>
                      </div>
                    </div>
                  </div>

                  <Button className="w-full" variant="outline">
                    Configure Alert Settings
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}