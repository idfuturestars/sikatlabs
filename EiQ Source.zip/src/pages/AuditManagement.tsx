import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Button } from "@/components/ui/button";
import { 
  Loader2, 
  Shield, 
  AlertTriangle, 
  CheckCircle, 
  XCircle, 
  Clock,
  Search,
  Filter,
  Download,
  Eye,
  User,
  Database,
  Activity,
  AlertCircle
} from "lucide-react";

interface AuditLog {
  id: string;
  userId: string;
  staffId?: string;
  sessionId?: string;
  action: string;
  resourceType: string;
  resourceId?: string;
  resourceName?: string;
  outcome: 'success' | 'failed' | 'partial';
  riskLevel: 'low' | 'medium' | 'high' | 'critical';
  complianceFlags: string[];
  ipAddress?: string;
  reason?: string;
  automatedAction: boolean;
  requiresReview: boolean;
  createdAt: string;
}

interface SystemAuditLog {
  id: string;
  systemComponent: string;
  eventType: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  message: string;
  details: any;
  performanceMetrics?: any;
  affectedUsers: number;
  resolution?: string;
  resolvedBy?: string;
  resolvedAt?: string;
  automatedResolution: boolean;
  alertsSent: boolean;
  createdAt: string;
}

interface ComplianceAudit {
  id: string;
  auditType: string;
  userId?: string;
  dataCategory: string;
  complianceStatus: 'compliant' | 'violation' | 'warning' | 'review_needed';
  violationType?: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  details: any;
  remediation?: string;
  remediatedBy?: string;
  remediatedAt?: string;
  reportRequired: boolean;
  reportedAt?: string;
  followUpRequired: boolean;
  followUpDate?: string;
  createdAt: string;
}

export default function AuditManagement() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState("user-audit");
  const [searchTerm, setSearchTerm] = useState("");
  const [filterAction, setFilterAction] = useState("all");
  const [filterRisk, setFilterRisk] = useState("all");
  const [dateRange, setDateRange] = useState("7d");

  // User audit logs
  const { data: auditLogs = [], isLoading: auditLoading } = useQuery<AuditLog[]>({
    queryKey: ["/api/audit-logs", { searchTerm, filterAction, filterRisk, dateRange }],
    enabled: !!user
  });

  // System audit logs
  const { data: systemLogs = [], isLoading: systemLoading } = useQuery<SystemAuditLog[]>({
    queryKey: ["/api/system-audit-logs", { dateRange }],
    enabled: !!user
  });

  // Compliance audit logs
  const { data: complianceLogs = [], isLoading: complianceLoading } = useQuery<ComplianceAudit[]>({
    queryKey: ["/api/compliance-audit", { dateRange }],
    enabled: !!user
  });

  const getRiskBadgeColor = (risk: string) => {
    switch (risk) {
      case 'critical': return 'destructive';
      case 'high': return 'destructive';
      case 'medium': return 'secondary';
      case 'low': return 'outline';
      default: return 'outline';
    }
  };

  const getOutcomeBadgeColor = (outcome: string) => {
    switch (outcome) {
      case 'success': return 'default';
      case 'failed': return 'destructive';
      case 'partial': return 'secondary';
      default: return 'outline';
    }
  };

  const getComplianceBadgeColor = (status: string) => {
    switch (status) {
      case 'compliant': return 'default';
      case 'violation': return 'destructive';
      case 'warning': return 'secondary';
      case 'review_needed': return 'outline';
      default: return 'outline';
    }
  };

  if (auditLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto p-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Audit & Compliance Dashboard</h1>
        <p className="text-muted-foreground">
          Monitor system activities, user actions, and compliance status across EIQ™.
        </p>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">User Actions</p>
                <p className="text-2xl font-bold">{auditLogs.length}</p>
              </div>
              <User className="w-8 h-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">System Events</p>
                <p className="text-2xl font-bold">{systemLogs.length}</p>
              </div>
              <Database className="w-8 h-8 text-green-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Compliance Issues</p>
                <p className="text-2xl font-bold">
                  {complianceLogs.filter(log => log.complianceStatus !== 'compliant').length}
                </p>
              </div>
              <Shield className="w-8 h-8 text-orange-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">High Risk Events</p>
                <p className="text-2xl font-bold">
                  {auditLogs.filter(log => log.riskLevel === 'high' || log.riskLevel === 'critical').length}
                </p>
              </div>
              <AlertTriangle className="w-8 h-8 text-red-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="user-audit">User Activity</TabsTrigger>
          <TabsTrigger value="system-audit">System Events</TabsTrigger>
          <TabsTrigger value="compliance-audit">Compliance</TabsTrigger>
        </TabsList>

        <TabsContent value="user-audit" className="space-y-6">
          {/* Filters */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Filter className="w-5 h-5" />
                Filter User Activity
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div>
                  <Label htmlFor="search">Search</Label>
                  <div className="relative">
                    <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="search"
                      placeholder="Search actions, resources..."
                      className="pl-8"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                    />
                  </div>
                </div>
                <div>
                  <Label>Action Type</Label>
                  <Select value={filterAction} onValueChange={setFilterAction}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Actions</SelectItem>
                      <SelectItem value="create">Create</SelectItem>
                      <SelectItem value="update">Update</SelectItem>
                      <SelectItem value="delete">Delete</SelectItem>
                      <SelectItem value="view">View</SelectItem>
                      <SelectItem value="login">Login</SelectItem>
                      <SelectItem value="assess">Assessment</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Risk Level</Label>
                  <Select value={filterRisk} onValueChange={setFilterRisk}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Levels</SelectItem>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="critical">Critical</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Date Range</Label>
                  <Select value={dateRange} onValueChange={setDateRange}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1d">Last 24 Hours</SelectItem>
                      <SelectItem value="7d">Last 7 Days</SelectItem>
                      <SelectItem value="30d">Last 30 Days</SelectItem>
                      <SelectItem value="90d">Last 90 Days</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* User Activity Logs */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>User Activity Logs</CardTitle>
                <CardDescription>
                  Detailed log of all user actions and system interactions
                </CardDescription>
              </div>
              <Button variant="outline" size="sm">
                <Download className="w-4 h-4 mr-2" />
                Export
              </Button>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-96">
                <div className="space-y-4">
                  {auditLogs.length > 0 ? auditLogs.map((log) => (
                    <div key={log.id} className="border rounded-lg p-4 space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <Badge variant={getOutcomeBadgeColor(log.outcome)}>
                            {log.outcome === 'success' && <CheckCircle className="w-3 h-3 mr-1" />}
                            {log.outcome === 'failed' && <XCircle className="w-3 h-3 mr-1" />}
                            {log.outcome === 'partial' && <Clock className="w-3 h-3 mr-1" />}
                            {log.outcome}
                          </Badge>
                          <Badge variant={getRiskBadgeColor(log.riskLevel)}>
                            {log.riskLevel} risk
                          </Badge>
                          {log.automatedAction && (
                            <Badge variant="outline">Automated</Badge>
                          )}
                        </div>
                        <div className="text-sm text-muted-foreground">
                          {new Date(log.createdAt).toLocaleString()}
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                        <div>
                          <p className="font-semibold">Action</p>
                          <p>{log.action} on {log.resourceType}</p>
                        </div>
                        <div>
                          <p className="font-semibold">Resource</p>
                          <p>{log.resourceName || log.resourceId || 'N/A'}</p>
                        </div>
                        <div>
                          <p className="font-semibold">IP Address</p>
                          <p>{log.ipAddress || 'N/A'}</p>
                        </div>
                      </div>
                      
                      {log.reason && (
                        <div className="text-sm">
                          <p className="font-semibold">Reason</p>
                          <p>{log.reason}</p>
                        </div>
                      )}
                      
                      {log.complianceFlags.length > 0 && (
                        <div className="flex gap-2">
                          {log.complianceFlags.map((flag) => (
                            <Badge key={flag} variant="outline">{flag}</Badge>
                          ))}
                        </div>
                      )}
                      
                      {log.requiresReview && (
                        <div className="flex items-center gap-2 text-yellow-600">
                          <AlertCircle className="w-4 h-4" />
                          <span className="text-sm font-medium">Requires Review</span>
                        </div>
                      )}
                    </div>
                  )) : (
                    <div className="text-center py-8 text-muted-foreground">
                      <Activity className="w-16 h-16 mx-auto mb-4 opacity-50" />
                      <p>No audit logs found matching your criteria.</p>
                    </div>
                  )}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="system-audit" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>System Health & Events</CardTitle>
              <CardDescription>
                Monitor system performance and critical events
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-96">
                <div className="space-y-4">
                  {systemLogs.length > 0 ? systemLogs.map((log) => (
                    <div key={log.id} className="border rounded-lg p-4 space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <Badge variant={getRiskBadgeColor(log.severity)}>
                            {log.eventType}
                          </Badge>
                          <Badge variant="outline">{log.systemComponent}</Badge>
                          {log.automatedResolution && (
                            <Badge variant="default">Auto-resolved</Badge>
                          )}
                        </div>
                        <div className="text-sm text-muted-foreground">
                          {new Date(log.createdAt).toLocaleString()}
                        </div>
                      </div>
                      
                      <div className="text-sm">
                        <p className="font-semibold mb-1">Message</p>
                        <p>{log.message}</p>
                      </div>
                      
                      {log.affectedUsers > 0 && (
                        <div className="text-sm">
                          <p className="font-semibold">Affected Users</p>
                          <p>{log.affectedUsers} users</p>
                        </div>
                      )}
                      
                      {log.resolution && (
                        <div className="text-sm">
                          <p className="font-semibold">Resolution</p>
                          <p>{log.resolution}</p>
                          {log.resolvedAt && (
                            <p className="text-muted-foreground">
                              Resolved at: {new Date(log.resolvedAt).toLocaleString()}
                            </p>
                          )}
                        </div>
                      )}
                    </div>
                  )) : (
                    <div className="text-center py-8 text-muted-foreground">
                      <Database className="w-16 h-16 mx-auto mb-4 opacity-50" />
                      <p>No system events found for the selected period.</p>
                    </div>
                  )}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="compliance-audit" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Compliance & Data Governance</CardTitle>
              <CardDescription>
                Monitor compliance with GDPR, COPPA, FERPA and other regulations
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-96">
                <div className="space-y-4">
                  {complianceLogs.length > 0 ? complianceLogs.map((log) => (
                    <div key={log.id} className="border rounded-lg p-4 space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <Badge variant={getComplianceBadgeColor(log.complianceStatus)}>
                            {log.complianceStatus === 'compliant' && <CheckCircle className="w-3 h-3 mr-1" />}
                            {log.complianceStatus === 'violation' && <XCircle className="w-3 h-3 mr-1" />}
                            {log.complianceStatus === 'warning' && <AlertTriangle className="w-3 h-3 mr-1" />}
                            {log.complianceStatus === 'review_needed' && <Eye className="w-3 h-3 mr-1" />}
                            {log.complianceStatus}
                          </Badge>
                          <Badge variant="outline">{log.auditType.toUpperCase()}</Badge>
                          <Badge variant={getRiskBadgeColor(log.severity)}>
                            {log.severity} severity
                          </Badge>
                        </div>
                        <div className="text-sm text-muted-foreground">
                          {new Date(log.createdAt).toLocaleString()}
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                        <div>
                          <p className="font-semibold">Data Category</p>
                          <p>{log.dataCategory}</p>
                        </div>
                        {log.violationType && (
                          <div>
                            <p className="font-semibold">Violation Type</p>
                            <p>{log.violationType}</p>
                          </div>
                        )}
                      </div>
                      
                      {log.remediation && (
                        <div className="text-sm">
                          <p className="font-semibold">Remediation</p>
                          <p>{log.remediation}</p>
                          {log.remediatedAt && (
                            <p className="text-muted-foreground">
                              Remediated at: {new Date(log.remediatedAt).toLocaleString()}
                            </p>
                          )}
                        </div>
                      )}
                      
                      <div className="flex gap-2">
                        {log.reportRequired && (
                          <Badge variant="destructive">Report Required</Badge>
                        )}
                        {log.followUpRequired && (
                          <Badge variant="secondary">Follow-up Required</Badge>
                        )}
                        {log.reportedAt && (
                          <Badge variant="default">Reported</Badge>
                        )}
                      </div>
                    </div>
                  )) : (
                    <div className="text-center py-8 text-muted-foreground">
                      <Shield className="w-16 h-16 mx-auto mb-4 opacity-50" />
                      <p>No compliance issues found. System is operating within regulatory requirements.</p>
                    </div>
                  )}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}