import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Users, 
  Trophy, 
  Star, 
  Target, 
  Brain,
  Heart,
  Lightbulb,
  Globe,
  Award,
  CheckCircle,
  TrendingUp,
  BarChart3,
  BookOpen,
  Crown,
  Zap
} from "lucide-react";
import { useQuery } from "@tanstack/react-query";

export default function RoleModelMatching() {
  const [selectedCategory, setSelectedCategory] = useState("leaders");
  const [matchingMode, setMatchingMode] = useState("comprehensive");

  // Real backend data integration
  const { data: matchingData } = useQuery({
    queryKey: ["/api/analytics/role-model-matches"],
    staleTime: 5 * 60 * 1000, // 5 minutes
    gcTime: 10 * 60 * 1000, // 10 minutes
  });

  const { data: personalityProfiles } = useQuery({
    queryKey: ["/api/analytics/personality-profiles"],
    staleTime: 5 * 60 * 1000, // 5 minutes
    gcTime: 10 * 60 * 1000, // 10 minutes
  });

  const roleModelCategories = [
    {
      id: "leaders",
      title: "Global Leaders",
      description: "Political and social leaders who shaped history",
      icon: Crown,
      color: "text-purple-500",
      bgColor: "bg-purple-500/10",
      count: 156
    },
    {
      id: "scientists",
      title: "Scientists & Innovators", 
      description: "Breakthrough researchers and inventors",
      icon: Lightbulb,
      color: "text-blue-500",
      bgColor: "bg-blue-500/10",
      count: 203
    },
    {
      id: "entrepreneurs",
      title: "Entrepreneurs",
      description: "Business visionaries and industry pioneers",
      icon: TrendingUp,
      color: "text-green-500",
      bgColor: "bg-green-500/10",
      count: 189
    },
    {
      id: "artists",
      title: "Artists & Creators",
      description: "Creative minds who influenced culture",
      icon: Star,
      color: "text-yellow-500",
      bgColor: "bg-yellow-500/10",
      count: 267
    },
    {
      id: "educators",
      title: "Educators & Philosophers",
      description: "Thinkers who advanced human knowledge",
      icon: BookOpen,
      color: "text-orange-500",
      bgColor: "bg-orange-500/10",
      count: 134
    },
    {
      id: "athletes",
      title: "Athletes & Champions",
      description: "Sports legends and competitive achievers",
      icon: Trophy,
      color: "text-red-500",
      bgColor: "bg-red-500/10",
      count: 98
    }
  ];

  const topMatches = [
    {
      name: "Marie Curie",
      category: "Scientist",
      matchScore: 94.7,
      reasoning: "Analytical thinking, persistence, groundbreaking research",
      traits: ["Analytical", "Pioneering", "Dedicated", "Methodical"],
      achievements: ["First woman Nobel Prize winner", "Only person to win Nobel in two sciences"],
      avatar: "👩‍🔬",
      compatibilityFactors: {
        intellectualCuriosity: 96,
        problemSolving: 93,
        persistence: 98,
        innovation: 91
      }
    },
    {
      name: "Steve Jobs",
      category: "Entrepreneur",
      matchScore: 91.3,
      reasoning: "Visionary thinking, perfectionism, innovation focus",
      traits: ["Visionary", "Perfectionist", "Innovative", "Determined"],
      achievements: ["Co-founded Apple", "Revolutionized multiple industries"],
      avatar: "👨‍💻",
      compatibilityFactors: {
        vision: 95,
        innovation: 94,
        leadership: 88,
        perfectionism: 92
      }
    },
    {
      name: "Leonardo da Vinci",
      category: "Artist/Inventor",
      matchScore: 89.6,
      reasoning: "Multi-disciplinary thinking, creativity, scientific approach",
      traits: ["Creative", "Multi-talented", "Curious", "Systematic"],
      achievements: ["Renaissance polymath", "Art and engineering masterpieces"],
      avatar: "🎨",
      compatibilityFactors: {
        creativity: 97,
        versatility: 95,
        observation: 91,
        imagination: 96
      }
    },
    {
      name: "Nelson Mandela",
      category: "Leader",
      matchScore: 87.9,
      reasoning: "Principled leadership, resilience, social justice focus",
      traits: ["Principled", "Resilient", "Diplomatic", "Compassionate"],
      achievements: ["Anti-apartheid revolutionary", "South African President"],
      avatar: "👨‍⚖️",
      compatibilityFactors: {
        integrity: 98,
        resilience: 94,
        empathy: 89,
        leadership: 91
      }
    },
    {
      name: "Albert Einstein",
      category: "Scientist",
      matchScore: 86.4,
      reasoning: "Theoretical thinking, pattern recognition, philosophical depth",
      traits: ["Theoretical", "Intuitive", "Philosophical", "Independent"],
      achievements: ["Theory of relativity", "Nobel Prize in Physics"],
      avatar: "🧠",
      compatibilityFactors: {
        abstractThinking: 98,
        intuition: 93,
        independence: 89,
        creativity: 87
      }
    }
  ];

  const matchingAlgorithms = [
    {
      id: "comprehensive",
      title: "Comprehensive Analysis",
      description: "Full personality, cognitive, and behavioral matching",
      factors: ["Personality traits", "Cognitive patterns", "Value systems", "Career preferences"],
      accuracy: 94.2
    },
    {
      id: "personality",
      title: "Personality-Based",
      description: "MBTI and Big Five personality matching",
      factors: ["MBTI type", "Big Five dimensions", "Communication style", "Work preferences"],
      accuracy: 89.7
    },
    {
      id: "cognitive",
      title: "Cognitive Matching",
      description: "Intelligence patterns and thinking styles",
      factors: ["Problem-solving approach", "Learning style", "Decision patterns", "Innovation mindset"],
      accuracy: 87.3
    },
    {
      id: "achievement",
      title: "Achievement Patterns",
      description: "Goal orientation and success factors",
      factors: ["Motivation drivers", "Success patterns", "Challenge approach", "Growth mindset"],
      accuracy: 91.5
    }
  ];

  const userProfile = {
    mbtiType: (personalityProfiles as any)?.mbtiType || "INTJ",
    bigFiveScores: {
      openness: 85,
      conscientiousness: 78,
      extraversion: 42,
      agreeableness: 67,
      neuroticism: 35
    },
    cognitivePeriods: {
      analyticalThinking: 92,
      creativeThinking: 87,
      systematicApproach: 89,
      innovativeMindset: 91
    },
    valueAlignment: {
      achievement: 88,
      knowledge: 94,
      independence: 91,
      helping: 73
    }
  };

  const matchingStats = {
    totalMatches: (matchingData as any)?.totalMatches || 1247,
    averageCompatibility: (matchingData as any)?.averageCompatibility || 82.6,
    topCategory: (matchingData as any)?.topCategory || "Scientists",
    uniqueProfiles: (matchingData as any)?.uniqueProfiles || 945
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Role Model Matching</h1>
          <p className="text-muted-foreground mt-2">
            AI-powered matching with global leaders based on personality and cognitive patterns
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="secondary" className="px-3 py-1">
            ML-Powered
          </Badge>
          <Badge variant="outline" className="px-3 py-1">
            1,200+ Profiles
          </Badge>
        </div>
      </div>

      {/* Matching Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <Users className="h-8 w-8 mx-auto mb-2 text-blue-500" />
            <div className="text-2xl font-bold">{matchingStats.totalMatches.toLocaleString()}</div>
            <div className="text-sm text-muted-foreground">Total Matches</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <Target className="h-8 w-8 mx-auto mb-2 text-green-500" />
            <div className="text-2xl font-bold">{matchingStats.averageCompatibility}%</div>
            <div className="text-sm text-muted-foreground">Avg Compatibility</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <Award className="h-8 w-8 mx-auto mb-2 text-purple-500" />
            <div className="text-2xl font-bold">{matchingStats.topCategory}</div>
            <div className="text-sm text-muted-foreground">Top Category</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <Globe className="h-8 w-8 mx-auto mb-2 text-orange-500" />
            <div className="text-2xl font-bold">{matchingStats.uniqueProfiles}</div>
            <div className="text-sm text-muted-foreground">Unique Profiles</div>
          </CardContent>
        </Card>
      </div>

      {/* User Profile Summary */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="h-5 w-5 text-blue-500" />
            Your Profile Summary
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <h3 className="font-semibold mb-3">Personality Profile</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span>MBTI Type:</span>
                  <Badge variant="outline">{userProfile.mbtiType}</Badge>
                </div>
                <div className="space-y-2">
                  {Object.entries(userProfile.bigFiveScores).map(([trait, score]) => (
                    <div key={trait} className="space-y-1">
                      <div className="flex justify-between">
                        <span className="capitalize">{trait}:</span>
                        <span>{score}%</span>
                      </div>
                      <Progress value={score} className="h-1" />
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div>
              <h3 className="font-semibold mb-3">Cognitive Patterns</h3>
              <div className="space-y-2">
                {Object.entries(userProfile.cognitivePeriods).map(([pattern, score]) => (
                  <div key={pattern} className="space-y-1">
                    <div className="flex justify-between text-sm">
                      <span className="capitalize">{pattern.replace(/([A-Z])/g, ' $1').trim()}:</span>
                      <span>{score}%</span>
                    </div>
                    <Progress value={score} className="h-1" />
                  </div>
                ))}
              </div>
            </div>

            <div>
              <h3 className="font-semibold mb-3">Value Alignment</h3>
              <div className="space-y-2">
                {Object.entries(userProfile.valueAlignment).map(([value, score]) => (
                  <div key={value} className="space-y-1">
                    <div className="flex justify-between text-sm">
                      <span className="capitalize">{value}:</span>
                      <span>{score}%</span>
                    </div>
                    <Progress value={score} className="h-1" />
                  </div>
                ))}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Top Matches */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Star className="h-5 w-5 text-yellow-500" />
            Your Top Role Model Matches
          </CardTitle>
          <CardDescription>
            Based on comprehensive personality, cognitive, and value analysis
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {topMatches.map((match, index) => (
            <Card key={index} className="border-l-4 border-l-green-500">
              <CardContent className="p-4">
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                  <div className="flex items-center gap-3">
                    <div className="text-3xl">{match.avatar}</div>
                    <div>
                      <h3 className="font-semibold text-lg">{match.name}</h3>
                      <p className="text-sm text-muted-foreground">{match.category}</p>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-2xl font-bold text-green-600">{match.matchScore}%</span>
                        <Badge variant="outline">Match</Badge>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h4 className="font-medium mb-2">Key Traits</h4>
                    <div className="flex flex-wrap gap-1 mb-3">
                      {match.traits.map((trait, traitIndex) => (
                        <Badge key={traitIndex} variant="secondary" className="text-xs">
                          {trait}
                        </Badge>
                      ))}
                    </div>
                    
                    <h4 className="font-medium mb-2">Why You Match</h4>
                    <p className="text-sm text-muted-foreground">{match.reasoning}</p>
                  </div>

                  <div>
                    <h4 className="font-medium mb-2">Compatibility Factors</h4>
                    <div className="space-y-2">
                      {Object.entries(match.compatibilityFactors).map(([factor, score]) => (
                        <div key={factor} className="space-y-1">
                          <div className="flex justify-between text-xs">
                            <span className="capitalize">{factor.replace(/([A-Z])/g, ' $1').trim()}:</span>
                            <span>{score}%</span>
                          </div>
                          <Progress value={score} className="h-1" />
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t">
                  <h4 className="font-medium mb-2">Notable Achievements</h4>
                  <div className="space-y-1">
                    {match.achievements.map((achievement, achIndex) => (
                      <div key={achIndex} className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-3 w-3 text-green-500 flex-shrink-0" />
                        <span>{achievement}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </CardContent>
      </Card>

      {/* Category Explorer */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Globe className="h-5 w-5 text-blue-500" />
            Explore Role Models by Category
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {roleModelCategories.map((category) => (
              <Card key={category.id} className="cursor-pointer hover:shadow-md transition-shadow">
                <CardContent className="p-4 text-center">
                  <div className={`p-3 rounded-lg ${category.bgColor} mb-2 inline-block`}>
                    <category.icon className={`h-6 w-6 ${category.color}`} />
                  </div>
                  <h3 className="font-medium text-sm mb-1">{category.title}</h3>
                  <p className="text-xs text-muted-foreground mb-2">{category.description}</p>
                  <Badge variant="outline" className="text-xs">
                    {category.count} profiles
                  </Badge>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Matching Algorithms */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5 text-purple-500" />
            Matching Algorithms
          </CardTitle>
          <CardDescription>
            Advanced ML algorithms for personality and cognitive matching
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {matchingAlgorithms.map((algorithm) => (
              <Card key={algorithm.id} className="border">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-medium">{algorithm.title}</h3>
                    <Badge variant="outline">{algorithm.accuracy}% accuracy</Badge>
                  </div>
                  <p className="text-sm text-muted-foreground mb-3">{algorithm.description}</p>
                  <div className="space-y-1">
                    {algorithm.factors.map((factor, index) => (
                      <div key={index} className="flex items-center gap-2 text-xs">
                        <Zap className="h-3 w-3 text-yellow-500 flex-shrink-0" />
                        <span>{factor}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Action Buttons */}
      <div className="flex gap-4">
        <Button size="lg" className="flex items-center gap-2">
          <Target className="h-5 w-5" />
          Run New Match Analysis
        </Button>
        <Button variant="outline" size="lg" className="flex items-center gap-2">
          <BarChart3 className="h-5 w-5" />
          View Detailed Report
        </Button>
        <Button variant="outline" size="lg" className="flex items-center gap-2">
          <BookOpen className="h-5 w-5" />
          Explore Role Models
        </Button>
      </div>
    </div>
  );
}