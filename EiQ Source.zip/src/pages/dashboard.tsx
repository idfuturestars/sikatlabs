// Modern dashboard with Monica.ai inspired design
import ModernDashboard from "./ModernDashboard";

export default function Dashboard() {
  return <ModernDashboard />;
}