import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Loader2, User, Palette, Star, Sparkles, Upload, Check, Edit2, Trash2, Shield } from "lucide-react";

interface Avatar {
  id: string;
  userId: string;
  avatarType: 'uploaded' | 'generated' | 'preset';
  avatarUrl: string | null;
  avatarData: any;
  isActive: boolean;
  isDefault: boolean;
  style: string;
  colors: any;
  accessories: any;
  mood: string;
  privacyLevel: 'public' | 'cohort' | 'private';
  createdAt: string;
  updatedAt: string;
}

interface AvatarPreset {
  id: string;
  name: string;
  description: string;
  category: string;
  presetData: any;
  previewUrl: string;
  popularity: number;
  ageAppropriate: string;
}

export default function AvatarManagement() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState("current");
  const [selectedPreset, setSelectedPreset] = useState<string | null>(null);
  const [customizing, setCustomizing] = useState(false);

  // Fetch user's avatars
  const { data: avatars = [], isLoading: avatarsLoading } = useQuery<Avatar[]>({
    queryKey: ["/api/avatars"],
    enabled: !!user
  });

  // Fetch available presets
  const { data: presets = [], isLoading: presetsLoading } = useQuery<AvatarPreset[]>({
    queryKey: ["/api/avatar-presets"],
    enabled: !!user
  });

  // Create avatar mutation
  const createAvatarMutation = useMutation({
    mutationFn: async (avatarData: any) => {
      const response = await apiRequest("POST", "/api/avatars", avatarData);
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/avatars"] });
      toast({
        title: "Avatar Created",
        description: "Your new avatar has been created successfully!"
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    }
  });

  // Update avatar mutation
  const updateAvatarMutation = useMutation({
    mutationFn: async ({ id, ...data }: any) => {
      const response = await apiRequest("PUT", `/api/avatars/${id}`, data);
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/avatars"] });
      toast({
        title: "Avatar Updated",
        description: "Your avatar has been updated successfully!"
      });
    }
  });

  // Set default avatar mutation
  const setDefaultMutation = useMutation({
    mutationFn: async (avatarId: string) => {
      const response = await apiRequest("POST", `/api/avatars/${avatarId}/set-default`);
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/avatars"] });
      toast({
        title: "Default Avatar Set",
        description: "This avatar is now your default!"
      });
    }
  });

  // Delete avatar mutation
  const deleteAvatarMutation = useMutation({
    mutationFn: async (avatarId: string) => {
      const response = await apiRequest("DELETE", `/api/avatars/${avatarId}`);
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/avatars"] });
      toast({
        title: "Avatar Deleted",
        description: "Avatar has been removed successfully."
      });
    }
  });

  const handleCreateFromPreset = (preset: AvatarPreset) => {
    createAvatarMutation.mutate({
      avatarType: "preset",
      style: preset.category,
      avatarData: preset.presetData,
      mood: "neutral",
      privacyLevel: "public"
    });
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // In a real implementation, you would upload the file to a storage service
    // For now, we'll create a data URL
    const reader = new FileReader();
    reader.onload = (e) => {
      createAvatarMutation.mutate({
        avatarType: "uploaded",
        avatarUrl: e.target?.result as string,
        style: "uploaded",
        privacyLevel: "public"
      });
    };
    reader.readAsDataURL(file);
  };

  const currentAvatar = avatars.find(a => a.isDefault) || avatars[0];

  if (avatarsLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto p-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Avatar Management</h1>
        <p className="text-muted-foreground">
          Customize your profile avatar and manage your visual identity across EIQ™.
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="current">Current Avatar</TabsTrigger>
          <TabsTrigger value="presets">Preset Gallery</TabsTrigger>
          <TabsTrigger value="upload">Upload Custom</TabsTrigger>
          <TabsTrigger value="customize">Customize</TabsTrigger>
        </TabsList>

        <TabsContent value="current" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Your Current Avatar</CardTitle>
              <CardDescription>
                This is how you appear to other users in the EIQ™ platform.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {currentAvatar ? (
                <div className="flex items-center space-x-6">
                  <Avatar className="w-32 h-32">
                    {currentAvatar.avatarUrl ? (
                      <AvatarImage src={currentAvatar.avatarUrl} />
                    ) : (
                      <AvatarFallback className="text-2xl">
                        {user?.firstName?.[0] || user?.email?.[0] || "U"}
                      </AvatarFallback>
                    )}
                  </Avatar>
                  <div className="space-y-4">
                    <div>
                      <h3 className="text-lg font-semibold">
                        {user?.firstName} {user?.lastName}
                      </h3>
                      <p className="text-muted-foreground">
                        Style: {currentAvatar.style} • Privacy: {currentAvatar.privacyLevel}
                      </p>
                    </div>
                    <div className="flex space-x-2">
                      <Badge variant={currentAvatar.isDefault ? "default" : "secondary"}>
                        {currentAvatar.isDefault ? "Default" : "Alternative"}
                      </Badge>
                      <Badge variant="outline">
                        <Shield className="w-3 h-3 mr-1" />
                        {currentAvatar.privacyLevel}
                      </Badge>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <User className="w-16 h-16 mx-auto mb-4 opacity-50" />
                  <p>No avatar set. Choose from presets or upload your own!</p>
                </div>
              )}

              {/* All user avatars */}
              {avatars.length > 0 && (
                <div className="space-y-4">
                  <h4 className="font-semibold">All Your Avatars</h4>
                  <ScrollArea className="h-48">
                    <div className="grid grid-cols-4 gap-4">
                      {avatars.map((avatar) => (
                        <Card key={avatar.id} className="p-4">
                          <div className="text-center space-y-3">
                            <Avatar className="w-16 h-16 mx-auto">
                              {avatar.avatarUrl ? (
                                <AvatarImage src={avatar.avatarUrl} />
                              ) : (
                                <AvatarFallback>
                                  {user?.firstName?.[0] || "U"}
                                </AvatarFallback>
                              )}
                            </Avatar>
                            <div className="space-y-1">
                              <p className="text-xs font-medium">{avatar.style}</p>
                              <div className="flex justify-center space-x-1">
                                {avatar.isDefault && (
                                  <Badge variant="default" className="text-xs">
                                    Default
                                  </Badge>
                                )}
                              </div>
                            </div>
                            <div className="flex space-x-1">
                              {!avatar.isDefault && (
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => setDefaultMutation.mutate(avatar.id)}
                                  disabled={setDefaultMutation.isPending}
                                >
                                  <Check className="w-3 h-3" />
                                </Button>
                              )}
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => setCustomizing(!customizing)}
                              >
                                <Edit2 className="w-3 h-3" />
                              </Button>
                              <Button
                                size="sm"
                                variant="destructive"
                                onClick={() => deleteAvatarMutation.mutate(avatar.id)}
                                disabled={avatar.isDefault || deleteAvatarMutation.isPending}
                              >
                                <Trash2 className="w-3 h-3" />
                              </Button>
                            </div>
                          </div>
                        </Card>
                      ))}
                    </div>
                  </ScrollArea>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="presets" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Avatar Preset Gallery</CardTitle>
              <CardDescription>
                Choose from professionally designed avatar styles.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
                {presets.length > 0 ? presets.map((preset) => (
                  <Card 
                    key={preset.id} 
                    className={`cursor-pointer transition-all hover:scale-105 ${
                      selectedPreset === preset.id ? 'ring-2 ring-primary' : ''
                    }`}
                    onClick={() => setSelectedPreset(preset.id)}
                  >
                    <CardContent className="p-4 text-center space-y-3">
                      <div className="w-16 h-16 mx-auto bg-gradient-to-br from-purple-400 to-blue-500 rounded-full flex items-center justify-center">
                        <Sparkles className="w-8 h-8 text-white" />
                      </div>
                      <div>
                        <p className="text-sm font-medium">{preset.name}</p>
                        <p className="text-xs text-muted-foreground">{preset.category}</p>
                      </div>
                      <div className="flex justify-center">
                        <Badge variant="secondary" className="text-xs">
                          <Star className="w-3 h-3 mr-1" />
                          {preset.popularity}
                        </Badge>
                      </div>
                      <Button 
                        size="sm" 
                        className="w-full"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleCreateFromPreset(preset);
                        }}
                        disabled={createAvatarMutation.isPending}
                      >
                        Use This
                      </Button>
                    </CardContent>
                  </Card>
                )) : (
                  // Mock presets when none are available
                  Array.from({ length: 12 }, (_, i) => (
                    <Card key={i} className="cursor-pointer transition-all hover:scale-105">
                      <CardContent className="p-4 text-center space-y-3">
                        <div className={`w-16 h-16 mx-auto rounded-full flex items-center justify-center ${
                          [
                            'bg-gradient-to-br from-purple-400 to-blue-500',
                            'bg-gradient-to-br from-green-400 to-blue-500',
                            'bg-gradient-to-br from-yellow-400 to-orange-500',
                            'bg-gradient-to-br from-pink-400 to-red-500',
                            'bg-gradient-to-br from-indigo-400 to-purple-500',
                            'bg-gradient-to-br from-blue-400 to-cyan-500'
                          ][i % 6]
                        }`}>
                          <Sparkles className="w-8 h-8 text-white" />
                        </div>
                        <div>
                          <p className="text-sm font-medium">
                            {['Professional', 'Creative', 'Academic', 'Casual', 'Artistic', 'Modern'][i % 6]} {Math.floor(i / 6) + 1}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {['professional', 'creative', 'academic', 'casual', 'artistic', 'modern'][i % 6]}
                          </p>
                        </div>
                        <div className="flex justify-center">
                          <Badge variant="secondary" className="text-xs">
                            <Star className="w-3 h-3 mr-1" />
                            {Math.floor(Math.random() * 100)}
                          </Badge>
                        </div>
                        <Button 
                          size="sm" 
                          className="w-full"
                          onClick={() => {
                            createAvatarMutation.mutate({
                              avatarType: "preset",
                              style: ['professional', 'creative', 'academic', 'casual', 'artistic', 'modern'][i % 6],
                              mood: "neutral",
                              privacyLevel: "public"
                            });
                          }}
                          disabled={createAvatarMutation.isPending}
                        >
                          Use This
                        </Button>
                      </CardContent>
                    </Card>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="upload" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Upload Custom Avatar</CardTitle>
              <CardDescription>
                Upload your own image to use as your avatar. Recommended size: 256x256px.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                <Upload className="w-12 h-12 mx-auto text-gray-400 mb-4" />
                <p className="text-lg font-medium mb-2">Upload Your Avatar</p>
                <p className="text-sm text-muted-foreground mb-4">
                  Choose a clear, high-quality image. Faces work best!
                </p>
                <Input
                  type="file"
                  accept="image/*"
                  onChange={handleFileUpload}
                  className="max-w-xs"
                  disabled={createAvatarMutation.isPending}
                />
              </div>
              
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                <h4 className="font-semibold mb-2">Guidelines for Best Results:</h4>
                <ul className="text-sm space-y-1 text-gray-600">
                  <li>• Use a clear, well-lit photo</li>
                  <li>• Square images work best (1:1 ratio)</li>
                  <li>• Keep file size under 5MB</li>
                  <li>• Supported formats: JPG, PNG, WEBP</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="customize" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Customize Avatar</CardTitle>
              <CardDescription>
                Fine-tune your avatar's appearance and privacy settings.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="style">Avatar Style</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Choose a style" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="professional">Professional</SelectItem>
                        <SelectItem value="casual">Casual</SelectItem>
                        <SelectItem value="artistic">Artistic</SelectItem>
                        <SelectItem value="minimalist">Minimalist</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="mood">Mood</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Choose mood" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="happy">Happy</SelectItem>
                        <SelectItem value="neutral">Neutral</SelectItem>
                        <SelectItem value="focused">Focused</SelectItem>
                        <SelectItem value="confident">Confident</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="privacy">Privacy Level</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Choose privacy level" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="public">Public</SelectItem>
                        <SelectItem value="cohort">Cohort Only</SelectItem>
                        <SelectItem value="private">Private</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-4">
                  <h4 className="font-semibold">Preview</h4>
                  <div className="flex flex-col items-center space-y-4 p-6 border rounded-lg">
                    <Avatar className="w-24 h-24">
                      <AvatarFallback className="text-lg">
                        {user?.firstName?.[0] || "U"}
                      </AvatarFallback>
                    </Avatar>
                    <div className="text-center">
                      <p className="font-medium">Preview Avatar</p>
                      <p className="text-sm text-muted-foreground">Professional • Public</p>
                    </div>
                  </div>
                </div>
              </div>

              <Separator />

              <div className="flex justify-end space-x-3">
                <Button variant="outline" onClick={() => setActiveTab("current")}>
                  Cancel
                </Button>
                <Button disabled={createAvatarMutation.isPending}>
                  {createAvatarMutation.isPending && (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  )}
                  Save Changes
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}