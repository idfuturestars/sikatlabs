import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Brain, Loader2 } from "lucide-react";
import { useQuery } from "@tanstack/react-query";

export default function TestAIImmersion() {
  const [selectedSection, setSelectedSection] = useState<string | null>(null);
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>("adaptive");

  // Query to test AI Immersion endpoint
  const { data: questions, isLoading, error, refetch } = useQuery({
    queryKey: ['/api/assessment/ai-immersion', selectedSection, selectedDifficulty],
    enabled: !!selectedSection,
    queryFn: async () => {
      const response = await fetch(`/api/assessment/ai-immersion/${selectedSection}?difficulty=${selectedDifficulty}`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
          'Content-Type': 'application/json'
        }
      });
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
      
      return response.json();
    }
  });

  const sections = [
    { id: 'core_math', name: 'Core Math', description: 'Foundation mathematics' },
    { id: 'applied_reasoning', name: 'Applied Reasoning', description: 'Real-world problem solving' },
    { id: 'ai_conceptual', name: 'AI Conceptual', description: 'AI thinking & decision making' }
  ];

  const difficulties = [
    { id: 'beginner', name: 'Beginner' },
    { id: 'intermediate', name: 'Intermediate' },
    { id: 'advanced', name: 'Advanced' },
    { id: 'adaptive', name: 'Adaptive' }
  ];

  return (
    <div className="container mx-auto p-6 space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="h-6 w-6 text-blue-500" />
            AI Immersion Assessment Test
          </CardTitle>
          <p className="text-sm text-muted-foreground">
            Test the AI Immersion question generation to capture logs for debugging repetition issues
          </p>
        </CardHeader>
        <CardContent className="space-y-6">
          
          {/* Section Selection */}
          <div>
            <h3 className="text-sm font-medium mb-3">Select Assessment Section:</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {sections.map((section) => (
                <Button
                  key={section.id}
                  variant={selectedSection === section.id ? "default" : "outline"}
                  className="h-auto p-4 flex flex-col items-start"
                  onClick={() => setSelectedSection(section.id)}
                >
                  <div className="font-medium">{section.name}</div>
                  <div className="text-xs text-muted-foreground">{section.description}</div>
                </Button>
              ))}
            </div>
          </div>

          {/* Difficulty Selection */}
          <div>
            <h3 className="text-sm font-medium mb-3">Select Difficulty:</h3>
            <div className="flex flex-wrap gap-2">
              {difficulties.map((difficulty) => (
                <Button
                  key={difficulty.id}
                  variant={selectedDifficulty === difficulty.id ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedDifficulty(difficulty.id)}
                >
                  {difficulty.name}
                </Button>
              ))}
            </div>
          </div>

          {/* Generate Button */}
          <div className="flex gap-3">
            <Button 
              onClick={() => refetch()} 
              disabled={!selectedSection || isLoading}
              className="flex items-center gap-2"
            >
              {isLoading && <Loader2 className="h-4 w-4 animate-spin" />}
              Generate Questions & Capture Logs
            </Button>
            
            {selectedSection && (
              <Badge variant="secondary">
                Testing: {selectedSection} ({selectedDifficulty})
              </Badge>
            )}
          </div>

          {/* Results Display */}
          {error && (
            <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
              <h4 className="font-medium text-red-800 mb-2">Error:</h4>
              <p className="text-sm text-red-700">{error.message}</p>
            </div>
          )}

          {questions && (
            <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
              <h4 className="font-medium text-green-800 mb-2">Success!</h4>
              <div className="text-sm text-green-700 space-y-1">
                <p>Generated {questions.totalQuestions} questions</p>
                <p>Section: {questions.section}</p>
                <p>Difficulty: {questions.difficulty}</p>
                <p>User History Count: {questions.userHistoryCount}</p>
                <p className="font-medium">Check console logs for detailed generation process!</p>
              </div>
            </div>
          )}

          {questions?.questions && (
            <div className="space-y-3">
              <h4 className="font-medium">Generated Questions Preview:</h4>
              {questions.questions.slice(0, 3).map((q: any, idx: number) => (
                <div key={idx} className="p-3 bg-gray-50 rounded border text-sm">
                  <div className="font-medium">Question {idx + 1}:</div>
                  <div className="text-gray-600 mt-1">{q.question?.substring(0, 200)}...</div>
                  {q.questionHash && (
                    <div className="text-xs text-gray-500 mt-1">Hash: {q.questionHash}</div>
                  )}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}