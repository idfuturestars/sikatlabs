import { useState } from "react";
import { useLocation } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  PieChart, 
  BarChart3, 
  TrendingUp, 
  TrendingDown,
  Users, 
  Brain, 
  Target, 
  Clock, 
  Award, 
  AlertTriangle,
  CheckCircle2,
  Eye,
  Activity,
  Zap,
  BookOpen,
  Star,
  Settings,
  Download,
  RefreshCw,
  Filter,
  Calendar,
  MapPin
} from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import ModernLayout from "@/components/layout/ModernLayout";
import { useCallback } from "react";

interface TeacherInsights {
  classPerformance: {
    averageScore: number;
    improvementRate: number;
    engagementLevel: number;
    completionRate: number;
  };
  studentAnalytics: {
    topPerformers: any[];
    atRiskStudents: any[];
    learningPatterns: any[];
  };
  predictiveAlerts: {
    urgentAlerts: any[];
    recommendations: any[];
  };
}

interface StudentAnalytics {
  personalMetrics: {
    overallProgress: number;
    strengths: string[];
    weaknesses: string[];
    studyHabits: any;
  };
  learningPatterns: {
    peakHours: string[];
    preferredSubjects: string[];
    difficultyProgression: any[];
  };
  goalTracking: {
    currentGoals: any[];
    achievements: any[];
    recommendations: string[];
  };
}

interface AdminMetrics {
  platformUsage: {
    totalUsers: number;
    activeUsers: number;
    sessionDuration: number;
    featureAdoption: any;
  };
  performanceMetrics: {
    systemHealth: number;
    responseTime: number;
    errorRate: number;
    uptime: number;
  };
  growthAnalytics: {
    userGrowth: any[];
    engagementTrends: any[];
    retentionRates: any;
  };
}

export default function AdvancedAnalyticsDashboard() {
  const [, setLocation] = useLocation();
  
  const handleSectionChange = useCallback((section: string) => {
    if (section === "dashboard") {
      setLocation("/");
    } else {
      const route = section.includes("-") ? `/${section}` : `/${section.replace("_", "-")}`;
      setLocation(route);
    }
  }, [setLocation]);

  const [selectedTimeframe, setSelectedTimeframe] = useState('30d');
  const [viewType, setViewType] = useState<'teacher' | 'student' | 'admin'>('student');

  // Teacher Insights
  const { data: teacherInsights } = useQuery<TeacherInsights>({
    queryKey: ["/api/analytics/teacher-insights", selectedTimeframe],
    enabled: viewType === 'teacher',
    staleTime: 5 * 60 * 1000,
  });

  // Student Analytics  
  const { data: studentAnalytics } = useQuery<StudentAnalytics>({
    queryKey: ["/api/analytics/student-analytics", selectedTimeframe],
    enabled: viewType === 'student',
    staleTime: 5 * 60 * 1000,
  });

  // Admin Metrics
  const { data: adminMetrics } = useQuery<AdminMetrics>({
    queryKey: ["/api/analytics/admin-metrics", selectedTimeframe],
    enabled: viewType === 'admin',
    staleTime: 2 * 60 * 1000,
  });

  // Mock data for demonstration
  const mockTeacherInsights: TeacherInsights = {
    classPerformance: {
      averageScore: 78.5,
      improvementRate: 12.3,
      engagementLevel: 84.2,
      completionRate: 91.7
    },
    studentAnalytics: {
      topPerformers: [
        { name: "Emma Chen", score: 94.2, improvement: "+8%" },
        { name: "Marcus Johnson", score: 91.8, improvement: "+15%" },
        { name: "Aria Patel", score: 89.6, improvement: "+6%" }
      ],
      atRiskStudents: [
        { name: "Jordan Smith", score: 62.4, trend: "declining", risk: "high" },
        { name: "Taylor Brown", score: 68.9, trend: "stagnant", risk: "medium" }
      ],
      learningPatterns: [
        { pattern: "Visual Learning Preference", students: 18, percentage: 60 },
        { pattern: "Collaborative Learning", students: 12, percentage: 40 },
        { pattern: "Independent Study", students: 15, percentage: 50 }
      ]
    },
    predictiveAlerts: {
      urgentAlerts: [
        { type: "performance_drop", student: "Jordan Smith", message: "15% score decrease this week" },
        { type: "engagement_low", student: "Alex Rivera", message: "No activity for 3 days" }
      ],
      recommendations: [
        "Consider additional support for struggling students in algebra",
        "Increase interactive elements in Week 4 curriculum",
        "Schedule one-on-one sessions with at-risk students"
      ]
    }
  };

  const mockStudentAnalytics: StudentAnalytics = {
    personalMetrics: {
      overallProgress: 76.3,
      strengths: ["Logical Reasoning", "Mathematical Concepts", "Problem Solving"],
      weaknesses: ["Time Management", "Complex Word Problems", "Statistical Analysis"],
      studyHabits: {
        dailyAverage: 45,
        preferredTime: "Evening",
        consistency: 82
      }
    },
    learningPatterns: {
      peakHours: ["7:00 PM - 9:00 PM", "10:00 AM - 12:00 PM"],
      preferredSubjects: ["Mathematics", "Science", "Logic Puzzles"],
      difficultyProgression: [
        { week: 1, level: 5.2 },
        { week: 2, level: 5.8 },
        { week: 3, level: 6.1 },
        { week: 4, level: 6.7 }
      ]
    },
    goalTracking: {
      currentGoals: [
        { goal: "Master Calculus Basics", progress: 68, target: "End of Month" },
        { goal: "Improve Speed Accuracy", progress: 45, target: "Next Week" }
      ],
      achievements: [
        { title: "Logic Master", date: "2 days ago", type: "skill" },
        { title: "Consistency Champion", date: "1 week ago", type: "habit" }
      ],
      recommendations: [
        "Focus 20 minutes daily on statistical concepts",
        "Try collaborative study sessions for complex problems",
        "Use visual learning tools for abstract mathematics"
      ]
    }
  };

  const mockAdminMetrics: AdminMetrics = {
    platformUsage: {
      totalUsers: 12847,
      activeUsers: 8926,
      sessionDuration: 34.5,
      featureAdoption: {
        assessments: 94.2,
        studyGroups: 67.8,
        aiTutor: 89.1,
        analytics: 76.4
      }
    },
    performanceMetrics: {
      systemHealth: 98.7,
      responseTime: 245,
      errorRate: 0.23,
      uptime: 99.94
    },
    growthAnalytics: {
      userGrowth: [
        { month: "Jan", users: 8500 },
        { month: "Feb", users: 9200 },
        { month: "Mar", users: 10100 },
        { month: "Apr", users: 11300 },
        { month: "May", users: 12847 }
      ],
      engagementTrends: [
        { metric: "Daily Active Users", value: 69.5, trend: "up" },
        { metric: "Session Length", value: 34.5, trend: "up" },
        { metric: "Feature Usage", value: 81.7, trend: "stable" }
      ],
      retentionRates: {
        weekly: 87.3,
        monthly: 74.1,
        quarterly: 61.8
      }
    }
  };

  const renderTeacherDashboard = () => (
    <div className="space-y-6">
      {/* Class Performance Overview */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Average Score</CardTitle>
            <Target className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{mockTeacherInsights.classPerformance.averageScore}%</div>
            <p className="text-xs text-muted-foreground">
              +{mockTeacherInsights.classPerformance.improvementRate}% from last month
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Engagement</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{mockTeacherInsights.classPerformance.engagementLevel}%</div>
            <Progress value={mockTeacherInsights.classPerformance.engagementLevel} className="mt-2" />
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Completion Rate</CardTitle>
            <CheckCircle2 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{mockTeacherInsights.classPerformance.completionRate}%</div>
            <p className="text-xs text-green-600">Excellent completion</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">At-Risk Students</CardTitle>
            <AlertTriangle className="h-4 w-4 text-orange-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-500">{mockTeacherInsights.studentAnalytics.atRiskStudents.length}</div>
            <p className="text-xs text-muted-foreground">Require attention</p>
          </CardContent>
        </Card>
      </div>

      {/* Student Performance Analysis */}
      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Star className="w-5 h-5 text-yellow-500" />
              Top Performers
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {mockTeacherInsights.studentAnalytics.topPerformers.map((student, idx) => (
                <div key={idx} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                  <div>
                    <div className="font-medium">{student.name}</div>
                    <div className="text-sm text-muted-foreground">Score: {student.score}%</div>
                  </div>
                  <Badge variant="secondary" className="text-green-600">
                    {student.improvement}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-orange-500" />
              Students Needing Support
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {mockTeacherInsights.studentAnalytics.atRiskStudents.map((student, idx) => (
                <div key={idx} className="flex items-center justify-between p-3 bg-orange-50 dark:bg-orange-950/20 rounded-lg">
                  <div>
                    <div className="font-medium">{student.name}</div>
                    <div className="text-sm text-muted-foreground">Score: {student.score}%</div>
                  </div>
                  <Badge variant="outline" className="text-orange-600">
                    {student.risk} risk
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Predictive Alerts */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="w-5 h-5 text-primary" />
            AI Recommendations
          </CardTitle>
          <CardDescription>
            Predictive insights to improve class performance
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <h4 className="font-medium text-red-600 mb-2">Urgent Alerts</h4>
              <div className="space-y-2">
                {mockTeacherInsights.predictiveAlerts.urgentAlerts.map((alert, idx) => (
                  <div key={idx} className="flex items-start gap-3 p-3 bg-red-50 dark:bg-red-950/20 rounded-lg">
                    <AlertTriangle className="w-4 h-4 text-red-500 mt-0.5" />
                    <div>
                      <div className="font-medium text-red-700 dark:text-red-300">{alert.student}</div>
                      <div className="text-sm text-red-600 dark:text-red-400">{alert.message}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            <div>
              <h4 className="font-medium text-blue-600 mb-2">Recommendations</h4>
              <ul className="space-y-2">
                {mockTeacherInsights.predictiveAlerts.recommendations.map((rec, idx) => (
                  <li key={idx} className="flex items-start gap-2 text-sm">
                    <CheckCircle2 className="w-3 h-3 text-blue-500 mt-0.5" />
                    <span>{rec}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );

  const renderStudentDashboard = () => (
    <div className="space-y-6">
      {/* Personal Metrics */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Overall Progress</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{mockStudentAnalytics.personalMetrics.overallProgress}%</div>
            <Progress value={mockStudentAnalytics.personalMetrics.overallProgress} className="mt-2" />
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Study Streak</CardTitle>
            <Zap className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">7 days</div>
            <p className="text-xs text-green-600">Keep it up!</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Daily Average</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{mockStudentAnalytics.personalMetrics.studyHabits.dailyAverage}min</div>
            <p className="text-xs text-muted-foreground">Study time</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Consistency</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{mockStudentAnalytics.personalMetrics.studyHabits.consistency}%</div>
            <Progress value={mockStudentAnalytics.personalMetrics.studyHabits.consistency} className="mt-2" />
          </CardContent>
        </Card>
      </div>

      {/* Learning Insights */}
      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Star className="w-5 h-5 text-green-500" />
              Your Strengths
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {mockStudentAnalytics.personalMetrics.strengths.map((strength, idx) => (
                <div key={idx} className="flex items-center gap-2 p-2 bg-green-50 dark:bg-green-950/20 rounded-lg">
                  <CheckCircle2 className="w-4 h-4 text-green-500" />
                  <span className="text-sm">{strength}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Target className="w-5 h-5 text-orange-500" />
              Growth Areas
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {mockStudentAnalytics.personalMetrics.weaknesses.map((weakness, idx) => (
                <div key={idx} className="flex items-center gap-2 p-2 bg-orange-50 dark:bg-orange-950/20 rounded-lg">
                  <Target className="w-4 h-4 text-orange-500" />
                  <span className="text-sm">{weakness}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Goals and Achievements */}
      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Target className="w-5 h-5 text-primary" />
              Current Goals
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {mockStudentAnalytics.goalTracking.currentGoals.map((goal, idx) => (
                <div key={idx} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-medium text-sm">{goal.goal}</span>
                    <Badge variant="outline">{goal.target}</Badge>
                  </div>
                  <Progress value={goal.progress} className="h-2" />
                  <div className="text-xs text-muted-foreground">{goal.progress}% complete</div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Award className="w-5 h-5 text-yellow-500" />
              Recent Achievements
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {mockStudentAnalytics.goalTracking.achievements.map((achievement, idx) => (
                <div key={idx} className="flex items-center gap-3 p-3 bg-yellow-50 dark:bg-yellow-950/20 rounded-lg">
                  <Award className="w-5 h-5 text-yellow-500" />
                  <div>
                    <div className="font-medium">{achievement.title}</div>
                    <div className="text-xs text-muted-foreground">{achievement.date}</div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* AI Recommendations */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="w-5 h-5 text-primary" />
            Personalized AI Recommendations
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-3">
            {mockStudentAnalytics.goalTracking.recommendations.map((rec, idx) => (
              <li key={idx} className="flex items-start gap-2 p-3 bg-primary/5 rounded-lg">
                <Brain className="w-4 h-4 text-primary mt-0.5" />
                <span className="text-sm">{rec}</span>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>
    </div>
  );

  const renderAdminDashboard = () => (
    <div className="space-y-6">
      {/* Platform Overview */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Users</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{mockAdminMetrics.platformUsage.totalUsers.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">
              {mockAdminMetrics.platformUsage.activeUsers.toLocaleString()} active
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">System Health</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{mockAdminMetrics.performanceMetrics.systemHealth}%</div>
            <Progress value={mockAdminMetrics.performanceMetrics.systemHealth} className="mt-2" />
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Response Time</CardTitle>
            <Zap className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{mockAdminMetrics.performanceMetrics.responseTime}ms</div>
            <p className="text-xs text-green-600">Excellent</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Uptime</CardTitle>
            <CheckCircle2 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{mockAdminMetrics.performanceMetrics.uptime}%</div>
            <p className="text-xs text-muted-foreground">This month</p>
          </CardContent>
        </Card>
      </div>

      {/* Feature Adoption */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-primary" />
            Feature Adoption Rates
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {Object.entries(mockAdminMetrics.platformUsage.featureAdoption).map(([feature, rate]) => (
              <div key={feature} className="flex items-center justify-between">
                <span className="capitalize">{feature.replace(/([A-Z])/g, ' $1').trim()}</span>
                <div className="flex items-center gap-2">
                  <Progress value={rate as number} className="w-20" />
                  <span className="text-sm w-12">{rate as number}%</span>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Growth Analytics */}
      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-primary" />
              User Growth
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {mockAdminMetrics.growthAnalytics.userGrowth.slice(-5).map((data, idx) => (
                <div key={idx} className="flex items-center justify-between">
                  <span>{data.month}</span>
                  <span className="font-medium">{data.users.toLocaleString()}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="w-5 h-5 text-primary" />
              Retention Rates
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span>Weekly Retention</span>
                <div className="flex items-center gap-2">
                  <Progress value={mockAdminMetrics.growthAnalytics.retentionRates.weekly} className="w-16" />
                  <span className="text-sm">{mockAdminMetrics.growthAnalytics.retentionRates.weekly}%</span>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <span>Monthly Retention</span>
                <div className="flex items-center gap-2">
                  <Progress value={mockAdminMetrics.growthAnalytics.retentionRates.monthly} className="w-16" />
                  <span className="text-sm">{mockAdminMetrics.growthAnalytics.retentionRates.monthly}%</span>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <span>Quarterly Retention</span>
                <div className="flex items-center gap-2">
                  <Progress value={mockAdminMetrics.growthAnalytics.retentionRates.quarterly} className="w-16" />
                  <span className="text-sm">{mockAdminMetrics.growthAnalytics.retentionRates.quarterly}%</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );

  const renderContent = () => (
    <div className="container mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-3">
            <PieChart className="w-8 h-8 text-primary" />
            Advanced Analytics Dashboard
          </h1>
          <p className="text-muted-foreground mt-2">
            Comprehensive insights with predictive analytics and performance tracking
          </p>
        </div>

        <div className="flex gap-2">
          <Button variant="outline" size="sm">
            <Filter className="w-4 h-4 mr-2" />
            Filter
          </Button>
          <Button variant="outline" size="sm">
            <RefreshCw className="w-4 h-4 mr-2" />
            Refresh
          </Button>
          <Button variant="outline" size="sm">
            <Download className="w-4 h-4 mr-2" />
            Export
          </Button>
        </div>
      </div>

      <Tabs value={viewType} onValueChange={(value) => setViewType(value as any)} className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="student">Student Analytics</TabsTrigger>
          <TabsTrigger value="teacher">Teacher Insights</TabsTrigger>
          <TabsTrigger value="admin">Admin Metrics</TabsTrigger>
        </TabsList>

        <TabsContent value="teacher" className="space-y-6">
          {renderTeacherDashboard()}
        </TabsContent>

        <TabsContent value="student" className="space-y-6">
          {renderStudentDashboard()}
        </TabsContent>

        <TabsContent value="admin" className="space-y-6">
          {renderAdminDashboard()}
        </TabsContent>
      </Tabs>
    </div>
  );

  return (
    <ModernLayout 
      activeSection="advanced-analytics"
      onSectionChange={handleSectionChange}
    >
      {renderContent()}
    </ModernLayout>
  );
}