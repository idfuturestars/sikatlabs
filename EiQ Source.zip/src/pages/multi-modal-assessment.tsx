import { useState, useEffect, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Slider } from "@/components/ui/slider";
import { 
  Eye, 
  Ear, 
  Brain, 
  Image as ImageIcon, 
  Volume2, 
  Mic,
  PlayCircle,
  PauseCircle,
  RotateCcw,
  Zap,
  Timer,
  Target,
  Lightbulb
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { motion, AnimatePresence } from "framer-motion";

interface MultiModalQuestion {
  id: string;
  type: 'text' | 'visual' | 'audio' | 'interactive' | 'spatial' | 'memory';
  category: string;
  content: {
    text?: string;
    imageData?: string;
    audioUrl?: string;
    interactiveElements?: any[];
    spatialPattern?: string[][];
    memorySequence?: string[];
  };
  options: string[];
  correctAnswer: number;
  difficulty: number; // IRT theta parameter
  discrimination: number; // IRT a parameter  
  guessing: number; // IRT c parameter
  timeLimit: number;
  adaptiveWeight: number;
}

const MULTI_MODAL_QUESTIONS: MultiModalQuestion[] = [
  {
    id: "mm_text_1",
    type: "text",
    category: "Verbal Reasoning",
    content: {
      text: "In a study of urban bird populations, researchers found that cities with more green spaces had 40% higher bird diversity. If City A has 25% green space and 120 bird species, what would you expect for City B with 35% green space?"
    },
    options: ["144 species", "168 species", "156 species", "132 species"],
    correctAnswer: 1,
    difficulty: 0.5,
    discrimination: 1.2,
    guessing: 0.25,
    timeLimit: 45000,
    adaptiveWeight: 1.0
  },
  {
    id: "mm_visual_1", 
    type: "visual",
    category: "Spatial Intelligence",
    content: {
      text: "Analyze the geometric pattern below. Which shape completes the sequence?",
      imageData: "data:image/svg+xml;base64," + btoa(`
        <svg width="400" height="200" xmlns="http://www.w3.org/2000/svg">
          <rect x="20" y="20" width="40" height="40" fill="#3B82F6" rx="5"/>
          <circle cx="120" cy="40" r="20" fill="#EF4444"/>
          <polygon points="200,20 240,20 220,60" fill="#10B981"/>
          <rect x="280" y="20" width="40" height="40" fill="#3B82F6" rx="10"/>
          <text x="360" y="40" font-family="Arial" font-size="24" fill="#666">?</text>
        </svg>
      `)
    },
    options: [
      "Circle (red)",
      "Triangle (green)", 
      "Square (blue, more rounded)",
      "Hexagon (purple)"
    ],
    correctAnswer: 2,
    difficulty: 0.7,
    discrimination: 1.4,
    guessing: 0.25,
    timeLimit: 60000,
    adaptiveWeight: 1.2
  },
  {
    id: "mm_audio_1",
    type: "audio",
    category: "Auditory Processing",
    content: {
      text: "Listen to the sequence of tones. Which pattern comes next?",
      audioUrl: "data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmQdBjiI0fXTgC4GJS6B5qBDGgdZpuXyvmIcBjqP0vHMeSgGIi6C3idJOAoYcsny3I4nBSJ9yvfFhYOCgYSEg4SGhYOEgIeGhoeGhoCGgoSFhv"
    },
    options: [
      "High-Low-High tone sequence",
      "Low-High-Low tone sequence", 
      "Constant high tone",
      "Rising pitch sequence"
    ],
    correctAnswer: 0,
    difficulty: 0.6,
    discrimination: 1.1,
    guessing: 0.25,
    timeLimit: 30000,
    adaptiveWeight: 1.3
  },
  {
    id: "mm_interactive_1",
    type: "interactive", 
    category: "Logical Operations",
    content: {
      text: "Adjust the sliders to make all circles the same size. What's the optimal strategy?",
      interactiveElements: [
        { id: "circle1", size: 10, maxSize: 50 },
        { id: "circle2", size: 30, maxSize: 50 },
        { id: "circle3", size: 45, maxSize: 50 }
      ]
    },
    options: [
      "Make all circles maximum size",
      "Find the average size and adjust all to that",
      "Make all circles minimum size", 
      "Use golden ratio proportions"
    ],
    correctAnswer: 1,
    difficulty: 0.4,
    discrimination: 1.3,
    guessing: 0.25,
    timeLimit: 90000,
    adaptiveWeight: 1.4
  },
  {
    id: "mm_spatial_1",
    type: "spatial",
    category: "3D Spatial Reasoning", 
    content: {
      text: "If you rotate this 3D shape 90° clockwise around the Y-axis, which view would you see from the front?",
      spatialPattern: [
        ["⬜", "⬛", "⬜"],
        ["⬛", "⬛", "⬛"], 
        ["⬜", "⬛", "⬜"]
      ]
    },
    options: [
      "⬜⬛⬜ / ⬛⬛⬛ / ⬜⬛⬜",
      "⬛⬜⬛ / ⬛⬛⬛ / ⬛⬜⬛",
      "⬜⬛⬜ / ⬜⬛⬜ / ⬜⬛⬜",
      "⬛⬛⬛ / ⬜⬛⬜ / ⬛⬛⬛"
    ],
    correctAnswer: 1,
    difficulty: 0.8,
    discrimination: 1.5,
    guessing: 0.25,
    timeLimit: 75000,
    adaptiveWeight: 1.6
  },
  {
    id: "mm_memory_1",
    type: "memory",
    category: "Working Memory",
    content: {
      text: "Study this sequence for 5 seconds, then recall the order:",
      memorySequence: ["🔴", "🔵", "🟡", "🟢", "🟣", "🟠", "⚫"]
    },
    options: [
      "🔴🔵🟡🟢🟣🟠⚫",
      "🔵🔴🟡🟢🟣🟠⚫", 
      "🔴🔵🟢🟡🟣🟠⚫",
      "🔴🔵🟡🟣🟢🟠⚫"
    ],
    correctAnswer: 0,
    difficulty: 0.3,
    discrimination: 1.0,
    guessing: 0.25,
    timeLimit: 20000,
    adaptiveWeight: 1.1
  }
];

export default function MultiModalAssessment() {
  const { toast } = useToast();
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [responses, setResponses] = useState<number[]>([]);
  const [timeRemaining, setTimeRemaining] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [memoryPhase, setMemoryPhase] = useState<'study' | 'recall'>('study');
  const [interactiveValues, setInteractiveValues] = useState<number[]>([10, 30, 45]);
  const [assessmentStarted, setAssessmentStarted] = useState(false);
  const [currentTheta, setCurrentTheta] = useState(0); // IRT ability estimate
  const [adaptiveHistory, setAdaptiveHistory] = useState<any[]>([]);
  
  const timerRef = useRef<NodeJS.Timeout>();
  const audioRef = useRef<HTMLAudioElement>(null);

  const question = MULTI_MODAL_QUESTIONS[currentQuestion];

  useEffect(() => {
    if (assessmentStarted && question) {
      setTimeRemaining(question.timeLimit);
      
      // Handle memory question study phase
      if (question.type === 'memory') {
        setMemoryPhase('study');
        setTimeout(() => {
          setMemoryPhase('recall');
        }, 5000);
      }

      // Start countdown timer
      timerRef.current = setInterval(() => {
        setTimeRemaining(prev => {
          if (prev <= 1000) {
            handleTimeout();
            return 0;
          }
          return prev - 1000;
        });
      }, 1000);
    }

    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, [currentQuestion, assessmentStarted]);

  const startAssessment = () => {
    setAssessmentStarted(true);
    toast({
      title: "Multi-Modal Assessment Started",
      description: "Adaptive difficulty will adjust based on your performance."
    });
  };

  const handleAnswer = (answerIndex: number) => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
    }

    const isCorrect = answerIndex === question.correctAnswer;
    const timeSpent = question.timeLimit - timeRemaining;
    
    // IRT-based ability estimation
    const newTheta = updateIRTEstimate(currentTheta, question, isCorrect);
    setCurrentTheta(newTheta);
    
    const responseData = {
      questionId: question.id,
      response: answerIndex,
      correct: isCorrect,
      timeSpent,
      theta: newTheta,
      difficulty: question.difficulty
    };
    
    setResponses(prev => [...prev, answerIndex]);
    setAdaptiveHistory(prev => [...prev, responseData]);

    toast({
      title: isCorrect ? "Correct!" : "Incorrect",
      description: `Your cognitive ability estimate: ${newTheta.toFixed(2)}`,
      variant: isCorrect ? "default" : "destructive"
    });

    // Move to next question or complete
    setTimeout(() => {
      if (currentQuestion + 1 < MULTI_MODAL_QUESTIONS.length) {
        setCurrentQuestion(prev => prev + 1);
      } else {
        completeAssessment();
      }
    }, 2000);
  };

  const handleTimeout = () => {
    handleAnswer(-1); // Timeout treated as incorrect
  };

  const updateIRTEstimate = (currentTheta: number, question: MultiModalQuestion, correct: boolean): number => {
    const { difficulty, discrimination, guessing } = question;
    
    // 3-parameter logistic model probability
    const probability = guessing + (1 - guessing) / (1 + Math.exp(-discrimination * (currentTheta - difficulty)));
    
    // Bayesian update (simplified)
    const adjustment = correct 
      ? 0.3 * (1 - probability)  
      : -0.3 * probability;
      
    return currentTheta + adjustment;
  };

  const completeAssessment = () => {
    const finalScore = Math.round(350 + (currentTheta + 2) * 125); // Convert to 300-850 scale
    const correctCount = adaptiveHistory.filter(h => h.correct).length;
    const accuracy = Math.round((correctCount / adaptiveHistory.length) * 100);

    toast({
      title: "Assessment Complete!",
      description: `Final EIQ Score: ${finalScore} (Accuracy: ${accuracy}%)`
    });
  };

  const playAudio = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause();
      } else {
        audioRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const renderQuestionContent = () => {
    switch (question.type) {
      case 'text':
        return (
          <div className="space-y-6">
            <div className="flex items-start space-x-3">
              <Brain className="w-6 h-6 text-blue-500 mt-1 flex-shrink-0" />
              <p className="text-lg leading-relaxed">{question.content.text}</p>
            </div>
          </div>
        );

      case 'visual':
        return (
          <div className="space-y-6">
            <div className="flex items-start space-x-3">
              <Eye className="w-6 h-6 text-purple-500 mt-1 flex-shrink-0" />
              <p className="text-lg">{question.content.text}</p>
            </div>
            {question.content.imageData && (
              <div className="flex justify-center bg-slate-50 dark:bg-slate-800 rounded-lg p-6">
                <img 
                  src={question.content.imageData}
                  alt="Visual reasoning pattern"
                  className="max-w-full h-auto"
                />
              </div>
            )}
          </div>
        );

      case 'audio':
        return (
          <div className="space-y-6">
            <div className="flex items-start space-x-3">
              <Ear className="w-6 h-6 text-green-500 mt-1 flex-shrink-0" />
              <p className="text-lg">{question.content.text}</p>
            </div>
            <div className="flex justify-center">
              <Button
                onClick={playAudio}
                size="lg"
                className="bg-green-500 hover:bg-green-600"
              >
                {isPlaying ? (
                  <>
                    <PauseCircle className="w-6 h-6 mr-2" />
                    Pause Audio
                  </>
                ) : (
                  <>
                    <PlayCircle className="w-6 h-6 mr-2" />
                    Play Audio Sequence
                  </>
                )}
              </Button>
            </div>
            <audio
              ref={audioRef}
              src={question.content.audioUrl}
              onEnded={() => setIsPlaying(false)}
            />
          </div>
        );

      case 'interactive':
        return (
          <div className="space-y-6">
            <div className="flex items-start space-x-3">
              <Target className="w-6 h-6 text-orange-500 mt-1 flex-shrink-0" />
              <p className="text-lg">{question.content.text}</p>
            </div>
            <div className="space-y-4 bg-slate-50 dark:bg-slate-800 rounded-lg p-6">
              {question.content.interactiveElements?.map((element, index) => (
                <div key={element.id} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span>Circle {index + 1}</span>
                    <span className="text-sm text-muted-foreground">
                      Size: {interactiveValues[index]}
                    </span>
                  </div>
                  <div className="flex items-center space-x-4">
                    <div 
                      className="bg-blue-500 rounded-full flex-shrink-0"
                      style={{
                        width: `${interactiveValues[index]}px`,
                        height: `${interactiveValues[index]}px`
                      }}
                    />
                    <Slider
                      value={[interactiveValues[index]]}
                      onValueChange={(value) => {
                        const newValues = [...interactiveValues];
                        newValues[index] = value[0];
                        setInteractiveValues(newValues);
                      }}
                      max={element.maxSize}
                      min={5}
                      step={1}
                      className="flex-1"
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        );

      case 'spatial':
        return (
          <div className="space-y-6">
            <div className="flex items-start space-x-3">
              <RotateCcw className="w-6 h-6 text-cyan-500 mt-1 flex-shrink-0" />
              <p className="text-lg">{question.content.text}</p>
            </div>
            <div className="flex justify-center">
              <div className="grid grid-cols-3 gap-2 p-4 bg-slate-100 dark:bg-slate-700 rounded-lg">
                {question.content.spatialPattern?.map((row, rowIndex) => 
                  row.map((cell, colIndex) => (
                    <div
                      key={`${rowIndex}-${colIndex}`}
                      className={`w-8 h-8 rounded ${
                        cell === "⬛" 
                          ? "bg-slate-900 dark:bg-white" 
                          : "bg-slate-300 dark:bg-slate-600"
                      }`}
                    />
                  ))
                )}
              </div>
            </div>
          </div>
        );

      case 'memory':
        return (
          <div className="space-y-6">
            <div className="flex items-start space-x-3">
              <Brain className="w-6 h-6 text-red-500 mt-1 flex-shrink-0" />
              <p className="text-lg">{question.content.text}</p>
            </div>
            {memoryPhase === 'study' ? (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex justify-center"
              >
                <div className="flex space-x-3 p-6 bg-slate-100 dark:bg-slate-700 rounded-lg">
                  {question.content.memorySequence?.map((symbol, index) => (
                    <motion.div
                      key={index}
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ delay: index * 0.2 }}
                      className="text-3xl"
                    >
                      {symbol}
                    </motion.div>
                  ))}
                </div>
              </motion.div>
            ) : (
              <div className="text-center p-6 bg-slate-50 dark:bg-slate-800 rounded-lg">
                <p className="text-muted-foreground">Now recall the sequence...</p>
              </div>
            )}
          </div>
        );

      default:
        return null;
    }
  };

  if (!assessmentStarted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-slate-900 dark:to-slate-800 p-6">
        <div className="max-w-4xl mx-auto">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center space-y-8"
          >
            <div className="space-y-4">
              <h1 className="text-4xl font-bold text-slate-900 dark:text-white">
                Multi-Modal Adaptive Assessment
              </h1>
              <p className="text-xl text-slate-600 dark:text-slate-300 max-w-3xl mx-auto">
                Experience next-generation cognitive assessment using text, visual, audio, 
                interactive, spatial, and memory challenges. Difficulty adapts in real-time 
                using Item Response Theory.
              </p>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
              <Card className="text-center">
                <CardContent className="pt-6">
                  <Brain className="w-8 h-8 text-blue-500 mx-auto mb-2" />
                  <h3 className="font-semibold">Text Reasoning</h3>
                  <p className="text-sm text-muted-foreground">Verbal & logical analysis</p>
                </CardContent>
              </Card>
              <Card className="text-center">
                <CardContent className="pt-6">
                  <Eye className="w-8 h-8 text-purple-500 mx-auto mb-2" />
                  <h3 className="font-semibold">Visual Processing</h3>
                  <p className="text-sm text-muted-foreground">Pattern recognition</p>
                </CardContent>
              </Card>
              <Card className="text-center">
                <CardContent className="pt-6">
                  <Ear className="w-8 h-8 text-green-500 mx-auto mb-2" />
                  <h3 className="font-semibold">Auditory Analysis</h3>
                  <p className="text-sm text-muted-foreground">Sound pattern matching</p>
                </CardContent>
              </Card>
              <Card className="text-center">
                <CardContent className="pt-6">
                  <Target className="w-8 h-8 text-orange-500 mx-auto mb-2" />
                  <h3 className="font-semibold">Interactive Logic</h3>
                  <p className="text-sm text-muted-foreground">Dynamic problem solving</p>
                </CardContent>
              </Card>
              <Card className="text-center">
                <CardContent className="pt-6">
                  <RotateCcw className="w-8 h-8 text-cyan-500 mx-auto mb-2" />
                  <h3 className="font-semibold">Spatial Reasoning</h3>
                  <p className="text-sm text-muted-foreground">3D mental rotation</p>
                </CardContent>
              </Card>
              <Card className="text-center">
                <CardContent className="pt-6">
                  <Brain className="w-8 h-8 text-red-500 mx-auto mb-2" />
                  <h3 className="font-semibold">Working Memory</h3>
                  <p className="text-sm text-muted-foreground">Sequence recall</p>
                </CardContent>
              </Card>
            </div>

            <div className="space-y-4">
              <Button 
                onClick={startAssessment}
                size="lg"
                className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white font-bold py-4 px-8 text-xl"
              >
                <Zap className="w-6 h-6 mr-2" />
                Start Multi-Modal Assessment
              </Button>
              <div className="flex justify-center space-x-4 text-sm text-muted-foreground">
                <div className="flex items-center space-x-1">
                  <Timer className="w-4 h-4" />
                  <span>Adaptive timing</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Lightbulb className="w-4 h-4" />
                  <span>IRT-based scoring</span>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    );
  }

  const progress = ((currentQuestion + 1) / MULTI_MODAL_QUESTIONS.length) * 100;
  const timeProgress = question ? (timeRemaining / question.timeLimit) * 100 : 0;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-slate-900 dark:to-slate-800 p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Progress Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Badge variant="outline">
              Question {currentQuestion + 1}/{MULTI_MODAL_QUESTIONS.length}
            </Badge>
            <Badge variant="outline">
              {question.category}
            </Badge>
            <Badge variant="outline">
              Ability: θ={currentTheta.toFixed(2)}
            </Badge>
          </div>
          <div className="text-right">
            <div className="text-sm text-muted-foreground">Time Remaining</div>
            <div className="text-lg font-bold">{Math.ceil(timeRemaining / 1000)}s</div>
          </div>
        </div>

        <div className="space-y-2">
          <Progress value={progress} className="h-2" />
          <Progress value={timeProgress} className="h-1" />
        </div>

        {/* Question Card */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center space-x-2">
                <Badge className="capitalize">{question.type}</Badge>
                <span>Multi-Modal Challenge</span>
              </CardTitle>
              <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                <span>Difficulty: {question.difficulty.toFixed(1)}</span>
                <span>•</span>
                <span>Discrimination: {question.discrimination.toFixed(1)}</span>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            {renderQuestionContent()}

            {/* Answer Options */}
            {(question.type !== 'memory' || memoryPhase === 'recall') && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {question.options.map((option, index) => (
                  <Button
                    key={index}
                    onClick={() => handleAnswer(index)}
                    variant="outline"
                    className="h-auto p-4 text-left justify-start whitespace-normal"
                  >
                    <span className="font-semibold mr-2">{String.fromCharCode(65 + index)}.</span>
                    <span>{option}</span>
                  </Button>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}