import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { 
  Bot, 
  Brain, 
  Zap, 
  Target, 
  Clock, 
  Award,
  CheckCircle,
  AlertTriangle,
  PlayCircle,
  RefreshCw,
  Users,
  Lightbulb,
  BarChart3,
  Shield,
  Eye,
  Mic,
  Image,
  FileText,
  Code,
  MessageSquare,
  TrendingUp,
  LineChart,
  Globe,
  Star,
  BookOpen,
  Headphones
} from "lucide-react";

interface TuringQuestion {
  id: string;
  type: 'text' | 'image' | 'audio' | 'code' | 'multimodal';
  content: string;
  options: string[];
  correctAnswer: string;
  difficulty: 'easy' | 'medium' | 'hard';
  category: string;
  metadata: {
    aiGenerated: boolean;
    model?: string;
    timeLimit: number;
  };
}

interface TuringTestResult {
  sessionId: string;
  score: number;
  accuracy: number;
  averageResponseTime: number;
  categoryBreakdown: Record<string, number>;
  aiDetectionAccuracy: number;
  skillLevel: 'novice' | 'intermediate' | 'advanced' | 'expert';
  insights: string[];
  recommendations: string[];
  timestamp: string;
}

interface TuringSession {
  id: string;
  mode: string;
  startTime: string;
  endTime: string;
  score: number;
  questionsTotal: number;
  questionsCorrect: number;
  categories: string[];
  result: TuringTestResult;
}

export default function TuringTest() {
  const [activeTab, setActiveTab] = useState("overview");
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [timeRemaining, setTimeRemaining] = useState(300); // 5 minutes
  const [testStarted, setTestStarted] = useState(false);
  const [testCompleted, setTestCompleted] = useState(false);
  const [userResponses, setUserResponses] = useState<string[]>([]);
  const [selectedMode, setSelectedMode] = useState("adaptive");
  const [currentResponse, setCurrentResponse] = useState("");
  const [sessionId, setSessionId] = useState<string | null>(null);
  
  const queryClient = useQueryClient();
  const { toast } = useToast();

  // Fetch Turing test questions
  const { data: turingQuestions } = useQuery<TuringQuestion[]>({
    queryKey: ["/api/turing-test/questions", selectedMode],
    enabled: testStarted,
    staleTime: 30 * 60 * 1000, // 30 minutes
  });

  // Fetch test results
  const { data: turingResults } = useQuery<TuringTestResult[]>({
    queryKey: ["/api/turing-test/results"],
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  // Fetch session history
  const { data: turingSessions } = useQuery<TuringSession[]>({
    queryKey: ["/api/turing-test/sessions"],
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  // Fetch AI literacy metrics
  const { data: aiLiteracyData } = useQuery({
    queryKey: ["/api/analytics/ai-literacy"],
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  // Start Turing test session
  const startTestMutation = useMutation({
    mutationFn: async (mode: string) => {
      return await apiRequest("/api/turing-test/start", {
        method: "POST",
        body: { mode, estimatedDuration: getTestDuration(mode) }
      });
    },
    onSuccess: (data) => {
      setSessionId(data.sessionId);
      setTestStarted(true);
      setCurrentQuestion(0);
      setUserResponses([]);
      setTimeRemaining(getTestDuration(selectedMode));
      toast({
        title: "Test Started",
        description: "Your Turing test session has begun. Good luck!",
      });
    },
    onError: () => {
      toast({
        title: "Start Failed",
        description: "Failed to start the test. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Submit response
  const submitResponseMutation = useMutation({
    mutationFn: async (response: string) => {
      return await apiRequest("/api/turing-test/submit", {
        method: "POST",
        body: { 
          sessionId,
          questionId: turingQuestions?.[currentQuestion]?.id,
          response,
          questionIndex: currentQuestion,
          timeRemaining,
          responseTime: getTestDuration(selectedMode) - timeRemaining
        }
      });
    },
    onSuccess: () => {
      const newResponses = [...userResponses];
      newResponses[currentQuestion] = currentResponse;
      setUserResponses(newResponses);
      setCurrentResponse("");
      
      if (currentQuestion < (turingQuestions?.length || 0) - 1) {
        setCurrentQuestion(prev => prev + 1);
      } else {
        completeTest();
      }
    },
    onError: () => {
      toast({
        title: "Submission Failed",
        description: "Failed to submit your response. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Complete test
  const completeTestMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest(`/api/turing-test/complete/${sessionId}`, {
        method: "POST",
      });
    },
    onSuccess: () => {
      setTestCompleted(true);
      setTestStarted(false);
      queryClient.invalidateQueries({ queryKey: ["/api/turing-test/results"] });
      queryClient.invalidateQueries({ queryKey: ["/api/turing-test/sessions"] });
      toast({
        title: "Test Completed",
        description: "Your results are being analyzed. Check the results tab for detailed feedback.",
      });
    },
  });

  const completeTest = () => {
    completeTestMutation.mutate();
  };

  const submitCurrentResponse = () => {
    if (currentResponse.trim()) {
      submitResponseMutation.mutate(currentResponse.trim());
    } else {
      toast({
        title: "Response Required",
        description: "Please provide a response before continuing.",
        variant: "destructive",
      });
    }
  };

  const getTestDuration = (mode: string) => {
    switch (mode) {
      case "rapid": return 300; // 5 minutes
      case "adaptive": return 600; // 10 minutes
      case "comprehensive": return 1200; // 20 minutes
      default: return 600;
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const getQuestionTypeIcon = (type: string) => {
    switch (type) {
      case 'text': return <FileText className="w-4 h-4" />;
      case 'image': return <Image className="w-4 h-4" />;
      case 'audio': return <Headphones className="w-4 h-4" />;
      case 'code': return <Code className="w-4 h-4" />;
      case 'multimodal': return <Globe className="w-4 h-4" />;
      default: return <MessageSquare className="w-4 h-4" />;
    }
  };

  const getScoreColor = (score: number) => {
    if (score >= 90) return "text-green-600";
    if (score >= 80) return "text-blue-600";
    if (score >= 70) return "text-orange-600";
    return "text-red-600";
  };

  const getSkillLevelBadge = (level: string) => {
    const colors = {
      novice: "bg-red-100 text-red-800",
      intermediate: "bg-yellow-100 text-yellow-800",
      advanced: "bg-blue-100 text-blue-800",
      expert: "bg-green-100 text-green-800"
    };
    return colors[level as keyof typeof colors] || colors.novice;
  };

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (testStarted && timeRemaining > 0 && !testCompleted) {
      timer = setTimeout(() => {
        setTimeRemaining(time => time - 1);
      }, 1000);
    } else if (testStarted && timeRemaining === 0) {
      completeTest();
    }
    return () => clearTimeout(timer);
  }, [testStarted, timeRemaining, testCompleted]);

  const turingTestModes = [
    {
      id: "adaptive",
      title: "Adaptive AI Literacy Test",
      description: "Dynamic AI identification with adaptive difficulty",
      icon: Brain,
      color: "text-blue-500",
      bgColor: "bg-blue-500/10",
      borderColor: "border-blue-500/20",
      questions: 10,
      timeLimit: 600, // 10 minutes
      features: [
        "AI-generated vs human-created content detection",
        "Adaptive difficulty based on performance",
        "Multi-modal content analysis",
        "Real-time accuracy feedback"
      ]
    },
    {
      id: "comprehensive",
      title: "Comprehensive Turing Assessment",
      description: "Full spectrum AI literacy evaluation",
      icon: Target,
      color: "text-green-500",
      bgColor: "bg-green-500/10",
      borderColor: "border-green-500/20",
      questions: 25,
      timeLimit: 1200, // 20 minutes
      features: [
        "Text, image, and audio AI detection",
        "Deep learning model identification",
        "Bias detection in AI outputs",
        "AI ethics and safety awareness"
      ]
    },
    {
      id: "rapid",
      title: "Rapid AI Detection Challenge",
      description: "Fast-paced AI identification skills test",
      icon: Zap,
      color: "text-orange-500",
      bgColor: "bg-orange-500/10",
      borderColor: "border-orange-500/20",
      questions: 15,
      timeLimit: 300, // 5 minutes
      features: [
        "Speed-based AI content detection",
        "Quick pattern recognition",
        "Instant feedback loops",
        "Competitive scoring system"
      ]
    }
  ];

  const currentMode = turingTestModes.find(mode => mode.id === selectedMode);
  const progress = turingQuestions ? ((currentQuestion + 1) / turingQuestions.length) * 100 : 0;

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-4">
          <h1 className="text-4xl font-bold gradient-text">Advanced Turing Test & AI Literacy Assessment</h1>
          <p className="text-muted-foreground max-w-3xl mx-auto">
            Comprehensive AI detection and literacy evaluation with multi-modal content analysis and educational feedback
          </p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Test Overview</TabsTrigger>
            <TabsTrigger value="assessment">Active Assessment</TabsTrigger>
            <TabsTrigger value="results">Results Analysis</TabsTrigger>
            <TabsTrigger value="history">Test History</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            {/* Test Mode Selection */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Bot className="w-5 h-5" />
                  Turing Test Mode Selection
                </CardTitle>
                <p className="text-muted-foreground">Choose your assessment type based on time and complexity preferences</p>
              </CardHeader>
              <CardContent>
                <div className="grid gap-6 md:grid-cols-3">
                  {turingTestModes.map((mode) => (
                    <div
                      key={mode.id}
                      className={`border rounded-lg p-6 cursor-pointer transition-all ${
                        selectedMode === mode.id 
                          ? `${mode.borderColor} ${mode.bgColor} border-2` 
                          : 'border-border hover:border-primary/50'
                      }`}
                      onClick={() => setSelectedMode(mode.id)}
                    >
                      <div className="text-center mb-4">
                        <div className={`w-16 h-16 rounded-full ${mode.bgColor} flex items-center justify-center mx-auto mb-3`}>
                          <mode.icon className={`w-8 h-8 ${mode.color}`} />
                        </div>
                        <h3 className="text-lg font-semibold mb-2">{mode.title}</h3>
                        <p className="text-sm text-muted-foreground mb-3">{mode.description}</p>
                      </div>

                      <div className="space-y-2 mb-4">
                        <div className="flex justify-between text-sm">
                          <span>Questions:</span>
                          <span className="font-medium">{mode.questions}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span>Time Limit:</span>
                          <span className="font-medium">{formatTime(mode.timeLimit)}</span>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <h4 className="text-sm font-medium">Features:</h4>
                        {mode.features.slice(0, 2).map((feature, i) => (
                          <div key={i} className="flex items-center gap-2 text-xs text-muted-foreground">
                            <CheckCircle className="w-3 h-3" />
                            <span>{feature}</span>
                          </div>
                        ))}
                        {mode.features.length > 2 && (
                          <div className="text-xs text-muted-foreground">
                            +{mode.features.length - 2} more features
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>

                <div className="mt-8 text-center">
                  <Button
                    onClick={() => startTestMutation.mutate(selectedMode)}
                    disabled={startTestMutation.isPending || testStarted}
                    size="lg"
                    className="px-8"
                  >
                    {startTestMutation.isPending ? (
                      <>
                        <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                        Starting...
                      </>
                    ) : (
                      <>
                        <PlayCircle className="w-4 h-4 mr-2" />
                        Start {currentMode?.title}
                      </>
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* AI Literacy Overview */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="w-5 h-5" />
                  AI Literacy Framework
                </CardTitle>
                <p className="text-muted-foreground">Understanding AI-generated content across different modalities</p>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <h4 className="font-medium">Detection Categories</h4>
                    <div className="space-y-3">
                      <div className="flex items-center gap-3">
                        <FileText className="w-5 h-5 text-blue-500" />
                        <div>
                          <div className="font-medium text-sm">Text Analysis</div>
                          <div className="text-xs text-muted-foreground">GPT, Claude, Gemini content detection</div>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <Image className="w-5 h-5 text-green-500" />
                        <div>
                          <div className="font-medium text-sm">Image Recognition</div>
                          <div className="text-xs text-muted-foreground">DALL-E, Midjourney, Stable Diffusion</div>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <Headphones className="w-5 h-5 text-purple-500" />
                        <div>
                          <div className="font-medium text-sm">Audio Analysis</div>
                          <div className="text-xs text-muted-foreground">Voice synthesis and music generation</div>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <Code className="w-5 h-5 text-orange-500" />
                        <div>
                          <div className="font-medium text-sm">Code Detection</div>
                          <div className="text-xs text-muted-foreground">GitHub Copilot, CodeT5, other AI coding</div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h4 className="font-medium">Skills Assessment</h4>
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Pattern Recognition</span>
                        <Badge variant="outline">{aiLiteracyData?.patternRecognition || 75}%</Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Bias Detection</span>
                        <Badge variant="outline">{aiLiteracyData?.biasDetection || 68}%</Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Model Identification</span>
                        <Badge variant="outline">{aiLiteracyData?.modelIdentification || 82}%</Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Ethical Awareness</span>
                        <Badge variant="outline">{aiLiteracyData?.ethicalAwareness || 90}%</Badge>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="assessment" className="space-y-6">
            {testStarted && turingQuestions ? (
              <>
                {/* Test Progress */}
                <Card>
                  <CardHeader>
                    <div className="flex justify-between items-center">
                      <CardTitle className="flex items-center gap-2">
                        <Clock className="w-5 h-5" />
                        Question {currentQuestion + 1} of {turingQuestions.length}
                      </CardTitle>
                      <div className="text-right">
                        <div className="text-2xl font-mono font-bold">{formatTime(timeRemaining)}</div>
                        <div className="text-sm text-muted-foreground">Time Remaining</div>
                      </div>
                    </div>
                    <Progress value={progress} className="h-2" />
                  </CardHeader>
                </Card>

                {/* Current Question */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      {getQuestionTypeIcon(turingQuestions[currentQuestion]?.type)}
                      {turingQuestions[currentQuestion]?.category} Assessment
                      <Badge variant="outline" className="ml-auto">
                        {turingQuestions[currentQuestion]?.difficulty}
                      </Badge>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="p-4 bg-muted/30 rounded-lg">
                      <p className="text-lg leading-relaxed">{turingQuestions[currentQuestion]?.content}</p>
                    </div>

                    {turingQuestions[currentQuestion]?.options?.length > 0 ? (
                      <RadioGroup value={currentResponse} onValueChange={setCurrentResponse}>
                        <div className="space-y-3">
                          {turingQuestions[currentQuestion].options.map((option, index) => (
                            <div key={index} className="flex items-center space-x-2 p-3 border rounded-lg hover:bg-muted/50">
                              <RadioGroupItem value={option} id={`option-${index}`} />
                              <Label htmlFor={`option-${index}`} className="flex-1 cursor-pointer">
                                {option}
                              </Label>
                            </div>
                          ))}
                        </div>
                      </RadioGroup>
                    ) : (
                      <div>
                        <Label htmlFor="response" className="text-sm font-medium">
                          Your Response
                        </Label>
                        <Textarea
                          id="response"
                          value={currentResponse}
                          onChange={(e) => setCurrentResponse(e.target.value)}
                          placeholder="Explain your reasoning for whether this content was created by AI or humans..."
                          className="min-h-[120px] mt-2"
                        />
                      </div>
                    )}

                    <div className="flex justify-between items-center pt-4">
                      <div className="text-sm text-muted-foreground">
                        {turingQuestions[currentQuestion]?.metadata?.timeLimit && (
                          <span>Recommended time: {turingQuestions[currentQuestion].metadata.timeLimit} seconds</span>
                        )}
                      </div>
                      <Button
                        onClick={submitCurrentResponse}
                        disabled={!currentResponse.trim() || submitResponseMutation.isPending}
                      >
                        {submitResponseMutation.isPending ? (
                          <>
                            <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                            Submitting...
                          </>
                        ) : currentQuestion === turingQuestions.length - 1 ? (
                          "Complete Test"
                        ) : (
                          "Next Question"
                        )}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </>
            ) : (
              <Card>
                <CardContent className="text-center py-12">
                  <Bot className="w-16 h-16 mx-auto mb-4 text-muted-foreground opacity-50" />
                  <h3 className="text-lg font-medium mb-2">No Active Assessment</h3>
                  <p className="text-muted-foreground mb-4">Start a Turing test to begin your AI literacy assessment</p>
                  <Button onClick={() => setActiveTab("overview")}>
                    Choose Test Mode
                  </Button>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="results" className="space-y-6">
            {/* Latest Results */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="w-5 h-5" />
                  Test Results & Analysis
                </CardTitle>
                <p className="text-muted-foreground">Comprehensive feedback on your AI detection skills</p>
              </CardHeader>
              <CardContent>
                {turingResults && turingResults.length > 0 ? (
                  <div className="space-y-6">
                    {turingResults.slice(0, 3).map((result) => (
                      <div key={result.sessionId} className="border rounded-lg p-6">
                        <div className="flex justify-between items-start mb-4">
                          <div>
                            <h3 className="text-lg font-semibold mb-1">Turing Test Results</h3>
                            <p className="text-sm text-muted-foreground">
                              Completed: {new Date(result.timestamp).toLocaleDateString()} • 
                              Avg Response Time: {result.averageResponseTime.toFixed(1)}s
                            </p>
                          </div>
                          <Badge className={getSkillLevelBadge(result.skillLevel)}>
                            {result.skillLevel}
                          </Badge>
                        </div>

                        {/* Score Dashboard */}
                        <div className="grid md:grid-cols-4 gap-4 mb-6">
                          <div className="text-center p-4 bg-muted/30 rounded-lg">
                            <div className={`text-3xl font-bold ${getScoreColor(result.score)}`}>
                              {result.score}
                            </div>
                            <div className="text-sm text-muted-foreground">Overall Score</div>
                          </div>
                          <div className="text-center p-4 bg-blue-50 rounded-lg">
                            <div className="text-2xl font-bold text-blue-600">{Math.round(result.accuracy)}%</div>
                            <div className="text-sm text-muted-foreground">Accuracy Rate</div>
                          </div>
                          <div className="text-center p-4 bg-green-50 rounded-lg">
                            <div className="text-2xl font-bold text-green-600">{Math.round(result.aiDetectionAccuracy)}%</div>
                            <div className="text-sm text-muted-foreground">AI Detection</div>
                          </div>
                          <div className="text-center p-4 bg-purple-50 rounded-lg">
                            <div className="text-2xl font-bold text-purple-600">{result.averageResponseTime.toFixed(1)}s</div>
                            <div className="text-sm text-muted-foreground">Avg Time</div>
                          </div>
                        </div>

                        {/* Category Breakdown */}
                        <div className="mb-6">
                          <h4 className="font-medium mb-3">Performance by Category</h4>
                          <div className="grid md:grid-cols-2 gap-4">
                            {Object.entries(result.categoryBreakdown).map(([category, score]) => (
                              <div key={category} className="flex justify-between items-center p-3 bg-muted/30 rounded">
                                <span className="text-sm capitalize">{category.replace('_', ' ')}</span>
                                <Badge className={`${getScoreColor(score)} bg-transparent border-0`}>
                                  {Math.round(score)}%
                                </Badge>
                              </div>
                            ))}
                          </div>
                        </div>

                        {/* AI Insights */}
                        {result.insights.length > 0 && (
                          <div className="mb-4">
                            <h4 className="font-medium mb-2 flex items-center gap-2">
                              <Brain className="w-4 h-4" />
                              AI Literacy Insights
                            </h4>
                            <ul className="space-y-1 text-sm">
                              {result.insights.map((insight, i) => (
                                <li key={i} className="flex items-start gap-2">
                                  <Eye className="w-3 h-3 mt-1 text-blue-500 flex-shrink-0" />
                                  <span>{insight}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}

                        {/* Educational Recommendations */}
                        {result.recommendations.length > 0 && (
                          <div className="p-4 bg-blue-50 rounded-lg">
                            <h4 className="font-medium mb-2 flex items-center gap-2">
                              <Lightbulb className="w-4 h-4" />
                              Learning Recommendations
                            </h4>
                            <ul className="space-y-1 text-sm">
                              {result.recommendations.map((rec, i) => (
                                <li key={i} className="flex items-start gap-2">
                                  <Target className="w-3 h-3 mt-1 text-blue-500 flex-shrink-0" />
                                  <span>{rec}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <Award className="w-16 h-16 mx-auto mb-4 text-muted-foreground opacity-50" />
                    <h3 className="text-lg font-medium mb-2">No Results Available</h3>
                    <p className="text-muted-foreground mb-4">Complete a Turing test to see detailed analysis and feedback</p>
                    <Button onClick={() => setActiveTab("overview")}>
                      Start Assessment
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="history" className="space-y-6">
            {/* Test History */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="w-5 h-5" />
                  Assessment History & Progress
                </CardTitle>
                <p className="text-muted-foreground">Track your AI literacy development over time</p>
              </CardHeader>
              <CardContent>
                {turingSessions && turingSessions.length > 0 ? (
                  <div className="space-y-4">
                    {turingSessions.map((session) => (
                      <div key={session.id} className="border rounded-lg p-4">
                        <div className="flex justify-between items-start mb-3">
                          <div>
                            <h4 className="font-medium capitalize">{session.mode.replace('-', ' ')} Test</h4>
                            <p className="text-sm text-muted-foreground">
                              {new Date(session.startTime).toLocaleDateString()} • 
                              Duration: {Math.round((new Date(session.endTime).getTime() - new Date(session.startTime).getTime()) / 60000)} minutes
                            </p>
                            <div className="flex gap-2 mt-2">
                              {session.categories.map((category) => (
                                <Badge key={category} variant="outline" className="text-xs">
                                  {category}
                                </Badge>
                              ))}
                            </div>
                          </div>
                          <div className="text-right">
                            <div className={`text-xl font-bold ${getScoreColor(session.score)}`}>
                              {session.score}
                            </div>
                            <div className="text-xs text-muted-foreground">
                              {session.questionsCorrect}/{session.questionsTotal} correct
                            </div>
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <Button size="sm" variant="outline">
                            View Details
                          </Button>
                          <Button size="sm" variant="outline">
                            Download Report
                          </Button>
                          <Button size="sm" variant="outline">
                            Retake Test
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <BookOpen className="w-16 h-16 mx-auto mb-4 text-muted-foreground opacity-50" />
                    <h3 className="text-lg font-medium mb-2">No Test History</h3>
                    <p className="text-muted-foreground mb-4">Your completed assessments will appear here</p>
                    <Button onClick={() => setActiveTab("overview")}>
                      Take First Test
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}