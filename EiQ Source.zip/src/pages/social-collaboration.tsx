import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Users, 
  MessageSquare, 
  Trophy,
  Crown,
  Star,
  Heart,
  Brain,
  Zap,
  Target,
  Globe,
  UserPlus,
  Search,
  Filter,
  Video,
  Mic,
  Share2
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { motion } from "framer-motion";

interface CohortMember {
  id: string;
  username: string;
  avatar: string;
  eiqScore: number;
  level: number;
  streak: number;
  location: string;
  specialties: string[];
  status: 'online' | 'busy' | 'offline';
  lastActive: string;
  mutualConnections: number;
  collaborations: number;
}

interface StudyRoom {
  id: string;
  name: string;
  topic: string;
  members: CohortMember[];
  maxMembers: number;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  type: 'Study Group' | 'Challenge' | 'Practice';
  status: 'active' | 'waiting';
  startTime: string;
  estimatedDuration: number;
  tags: string[];
}

interface Challenge {
  id: string;
  title: string;
  description: string;
  type: 'individual' | 'team' | 'global';
  participants: number;
  reward: string;
  timeLeft: string;
  difficulty: number;
  category: string;
}

const COHORT_MEMBERS: CohortMember[] = [
  {
    id: "1",
    username: "CognitiveAce",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=CognitiveAce",
    eiqScore: 795,
    level: 12,
    streak: 28,
    location: "San Francisco, CA",
    specialties: ["Mathematical Logic", "Pattern Recognition"],
    status: "online",
    lastActive: "Just now",
    mutualConnections: 15,
    collaborations: 23
  },
  {
    id: "2", 
    username: "BrainStorm",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=BrainStorm",
    eiqScore: 742,
    level: 9,
    streak: 15,
    location: "London, UK",
    specialties: ["Verbal Reasoning", "Memory Techniques"],
    status: "busy",
    lastActive: "5 minutes ago",
    mutualConnections: 8,
    collaborations: 17
  },
  {
    id: "3",
    username: "LogicLord",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=LogicLord",
    eiqScore: 688,
    level: 7,
    streak: 12,
    location: "Tokyo, Japan",
    specialties: ["Spatial Intelligence", "Abstract Reasoning"],
    status: "online",
    lastActive: "2 minutes ago", 
    mutualConnections: 12,
    collaborations: 31
  },
  {
    id: "4",
    username: "MindMaster",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=MindMaster",
    eiqScore: 756,
    level: 10,
    streak: 22,
    location: "Berlin, Germany",
    specialties: ["Working Memory", "Processing Speed"],
    status: "offline",
    lastActive: "1 hour ago",
    mutualConnections: 6,
    collaborations: 19
  }
];

const STUDY_ROOMS: StudyRoom[] = [
  {
    id: "room_1",
    name: "Advanced Pattern Recognition",
    topic: "Visual-Spatial Intelligence",
    members: COHORT_MEMBERS.slice(0, 3),
    maxMembers: 6,
    difficulty: "Advanced",
    type: "Study Group",
    status: "active",
    startTime: "10 minutes ago",
    estimatedDuration: 45,
    tags: ["patterns", "visual", "advanced"]
  },
  {
    id: "room_2",
    name: "Memory Palace Builders",
    topic: "Memory Enhancement Techniques", 
    members: COHORT_MEMBERS.slice(1, 3),
    maxMembers: 4,
    difficulty: "Intermediate",
    type: "Practice",
    status: "waiting",
    startTime: "Starting soon",
    estimatedDuration: 30,
    tags: ["memory", "techniques", "practice"]
  },
  {
    id: "room_3",
    name: "Logic Puzzle Challenge",
    topic: "Competitive Problem Solving",
    members: COHORT_MEMBERS.slice(0, 4),
    maxMembers: 8,
    difficulty: "Advanced",
    type: "Challenge", 
    status: "active",
    startTime: "5 minutes ago",
    estimatedDuration: 60,
    tags: ["logic", "competitive", "puzzles"]
  }
];

const CHALLENGES: Challenge[] = [
  {
    id: "c1",
    title: "Global Pattern Masters",
    description: "Compete with users worldwide in pattern recognition challenges",
    type: "global",
    participants: 2847,
    reward: "Exclusive Pattern Master Badge",
    timeLeft: "2 days 14 hours",
    difficulty: 8,
    category: "Visual Intelligence"
  },
  {
    id: "c2", 
    title: "Team Logic Sprint",
    description: "Form a team of 4 and solve complex logical sequences together",
    type: "team",
    participants: 156,
    reward: "Team Synergy Achievement",
    timeLeft: "6 hours 23 minutes", 
    difficulty: 7,
    category: "Logical Reasoning"
  },
  {
    id: "c3",
    title: "Memory Marathon",
    description: "Test your working memory limits in this solo endurance challenge",
    type: "individual", 
    participants: 892,
    reward: "Memory Athlete Title",
    timeLeft: "1 day 8 hours",
    difficulty: 6,
    category: "Memory & Recall"
  }
];

export default function SocialCollaboration() {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("cohorts");
  const [searchQuery, setSearchQuery] = useState("");
  const [filterSpecialty, setFilterSpecialty] = useState("all");
  const [selectedMember, setSelectedMember] = useState<CohortMember | null>(null);

  const filteredMembers = COHORT_MEMBERS.filter(member => {
    const matchesSearch = member.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         member.location.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesSpecialty = filterSpecialty === "all" || 
                            member.specialties.some(spec => 
                              spec.toLowerCase().includes(filterSpecialty.toLowerCase())
                            );
    return matchesSearch && matchesSpecialty;
  });

  const sendFriendRequest = (member: CohortMember) => {
    toast({
      title: "Friend Request Sent!",
      description: `Sent friend request to ${member.username}`
    });
  };

  const joinRoom = (room: StudyRoom) => {
    if (room.members.length >= room.maxMembers) {
      toast({
        title: "Room Full",
        description: "This study room has reached its maximum capacity.",
        variant: "destructive"
      });
      return;
    }

    toast({
      title: "Joined Study Room!",
      description: `You've joined "${room.name}" - connecting you now...`
    });
  };

  const joinChallenge = (challenge: Challenge) => {
    toast({
      title: "Challenge Accepted!",
      description: `You've joined "${challenge.title}" - prepare to compete!`
    });
  };

  const getStatusColor = (status: CohortMember['status']) => {
    switch (status) {
      case 'online': return 'bg-green-500';
      case 'busy': return 'bg-yellow-500'; 
      case 'offline': return 'bg-gray-400';
      default: return 'bg-gray-400';
    }
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Beginner': return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
      case 'Intermediate': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200';
      case 'Advanced': return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 to-purple-100 dark:from-slate-900 dark:to-slate-800 p-6">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="text-center space-y-4">
          <h1 className="text-4xl font-bold text-slate-900 dark:text-white flex items-center justify-center space-x-3">
            <Users className="w-8 h-8 text-purple-500" />
            <span>Social EiQ Cohorts</span>
          </h1>
          <p className="text-xl text-slate-600 dark:text-slate-300 max-w-3xl mx-auto">
            Connect with learners worldwide, join study groups, compete in challenges, 
            and grow together through collaborative intelligence development.
          </p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="cohorts" className="flex items-center space-x-2">
              <Users className="w-4 h-4" />
              <span>My Cohorts</span>
            </TabsTrigger>
            <TabsTrigger value="study-rooms" className="flex items-center space-x-2">
              <MessageSquare className="w-4 h-4" />
              <span>Study Rooms</span>
            </TabsTrigger>
            <TabsTrigger value="challenges" className="flex items-center space-x-2">
              <Trophy className="w-4 h-4" />
              <span>Challenges</span>
            </TabsTrigger>
            <TabsTrigger value="discovery" className="flex items-center space-x-2">
              <Globe className="w-4 h-4" />
              <span>Discovery</span>
            </TabsTrigger>
          </TabsList>

          {/* My Cohorts Tab */}
          <TabsContent value="cohorts" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center space-x-2">
                    <Users className="w-5 h-5 text-purple-500" />
                    <span>Connected Learners</span>
                  </CardTitle>
                  <div className="flex items-center space-x-2">
                    <Input
                      placeholder="Search cohort members..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="w-64"
                    />
                    <Button variant="outline" size="sm">
                      <Search className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredMembers.map((member) => (
                    <motion.div
                      key={member.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      whileHover={{ scale: 1.02 }}
                    >
                      <Card className="h-full">
                        <CardContent className="pt-6">
                          <div className="flex items-start space-x-3">
                            <div className="relative">
                              <Avatar className="w-12 h-12">
                                <AvatarImage src={member.avatar} />
                                <AvatarFallback>{member.username.slice(0, 2)}</AvatarFallback>
                              </Avatar>
                              <div className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-white ${getStatusColor(member.status)}`} />
                            </div>
                            <div className="flex-1 min-w-0">
                              <h3 className="font-semibold text-lg">{member.username}</h3>
                              <div className="flex items-center space-x-2 mt-1">
                                <Badge variant="secondary">{member.eiqScore} EIQ</Badge>
                                <Badge variant="outline">Level {member.level}</Badge>
                              </div>
                              <div className="mt-2 space-y-1 text-sm text-muted-foreground">
                                <div className="flex items-center space-x-1">
                                  <Crown className="w-3 h-3 text-yellow-500" />
                                  <span>{member.streak} day streak</span>
                                </div>
                                <div className="flex items-center space-x-1">
                                  <Globe className="w-3 h-3 text-blue-500" />
                                  <span>{member.location}</span>
                                </div>
                                <div className="flex items-center space-x-1">
                                  <Heart className="w-3 h-3 text-red-500" />
                                  <span>{member.collaborations} collaborations</span>
                                </div>
                              </div>
                              <div className="mt-3 flex flex-wrap gap-1">
                                {member.specialties.slice(0, 2).map((specialty) => (
                                  <Badge key={specialty} variant="outline" className="text-xs">
                                    {specialty}
                                  </Badge>
                                ))}
                              </div>
                            </div>
                          </div>
                          <div className="mt-4 flex space-x-2">
                            <Button 
                              size="sm" 
                              className="flex-1"
                              onClick={() => sendFriendRequest(member)}
                            >
                              <UserPlus className="w-3 h-3 mr-1" />
                              Connect
                            </Button>
                            <Button size="sm" variant="outline">
                              <MessageSquare className="w-3 h-3 mr-1" />
                              Chat
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    </motion.div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Study Rooms Tab */}
          <TabsContent value="study-rooms" className="space-y-6">
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {STUDY_ROOMS.map((room) => (
                <Card key={room.id} className="h-full">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="text-lg">{room.name}</CardTitle>
                        <p className="text-sm text-muted-foreground mt-1">{room.topic}</p>
                      </div>
                      <Badge className={getDifficultyColor(room.difficulty)}>
                        {room.difficulty}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between text-sm">
                      <div className="flex items-center space-x-2">
                        <Users className="w-4 h-4 text-muted-foreground" />
                        <span>{room.members.length}/{room.maxMembers} members</span>
                      </div>
                      <Badge variant="outline">{room.type}</Badge>
                    </div>

                    <div className="flex -space-x-2">
                      {room.members.slice(0, 4).map((member) => (
                        <Avatar key={member.id} className="w-8 h-8 border-2 border-background">
                          <AvatarImage src={member.avatar} />
                          <AvatarFallback className="text-xs">{member.username.slice(0, 2)}</AvatarFallback>
                        </Avatar>
                      ))}
                      {room.members.length > 4 && (
                        <div className="w-8 h-8 rounded-full bg-muted border-2 border-background flex items-center justify-center text-xs font-medium">
                          +{room.members.length - 4}
                        </div>
                      )}
                    </div>

                    <div className="flex flex-wrap gap-1">
                      {room.tags.map((tag) => (
                        <Badge key={tag} variant="secondary" className="text-xs">
                          #{tag}
                        </Badge>
                      ))}
                    </div>

                    <div className="flex items-center justify-between text-xs text-muted-foreground">
                      <span>{room.startTime}</span>
                      <span>~{room.estimatedDuration} min</span>
                    </div>

                    <Button 
                      onClick={() => joinRoom(room)}
                      className="w-full"
                      disabled={room.members.length >= room.maxMembers}
                    >
                      {room.status === 'active' ? 'Join Now' : 'Join Room'}
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Video className="w-5 h-5 text-green-500" />
                  <span>Create Study Room</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Input placeholder="Room name" />
                  <Input placeholder="Topic" />
                  <Button>
                    <Zap className="w-4 h-4 mr-2" />
                    Create Room
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Challenges Tab */}
          <TabsContent value="challenges" className="space-y-6">
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {CHALLENGES.map((challenge) => (
                <Card key={challenge.id} className="h-full">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="text-lg">{challenge.title}</CardTitle>
                        <p className="text-sm text-muted-foreground mt-1">{challenge.category}</p>
                      </div>
                      <Badge variant={challenge.type === 'global' ? 'default' : 'secondary'}>
                        {challenge.type}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-sm">{challenge.description}</p>

                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <div className="flex items-center space-x-2">
                          <Users className="w-4 h-4 text-muted-foreground" />
                          <span>{challenge.participants.toLocaleString()} participants</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Star className="w-4 h-4 text-yellow-500" />
                          <span>Level {challenge.difficulty}</span>
                        </div>
                      </div>

                      <div className="flex items-center space-x-2 text-sm">
                        <Trophy className="w-4 h-4 text-gold" />
                        <span className="font-medium">{challenge.reward}</span>
                      </div>

                      <div className="flex items-center space-x-2 text-sm text-red-600 dark:text-red-400">
                        <Target className="w-4 h-4" />
                        <span>{challenge.timeLeft} remaining</span>
                      </div>
                    </div>

                    <Button 
                      onClick={() => joinChallenge(challenge)}
                      className="w-full"
                    >
                      Join Challenge
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Discovery Tab */}
          <TabsContent value="discovery" className="space-y-6">
            <div className="grid gap-6 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Globe className="w-5 h-5 text-blue-500" />
                    <span>Global Learning Map</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-64 bg-slate-100 dark:bg-slate-800 rounded-lg flex items-center justify-center">
                    <div className="text-center space-y-2">
                      <Globe className="w-12 h-12 text-muted-foreground mx-auto" />
                      <p className="text-muted-foreground">Interactive world map showing active learners</p>
                      <Badge variant="outline">2,847 users online now</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Brain className="w-5 h-5 text-purple-500" />
                    <span>Suggested Connections</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {COHORT_MEMBERS.slice(0, 3).map((member) => (
                      <div key={member.id} className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <Avatar className="w-8 h-8">
                            <AvatarImage src={member.avatar} />
                            <AvatarFallback>{member.username.slice(0, 2)}</AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="font-medium text-sm">{member.username}</p>
                            <p className="text-xs text-muted-foreground">
                              {member.mutualConnections} mutual connections
                            </p>
                          </div>
                        </div>
                        <Button size="sm" variant="outline">
                          <UserPlus className="w-3 h-3 mr-1" />
                          Connect
                        </Button>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}