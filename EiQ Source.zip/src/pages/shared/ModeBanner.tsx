import { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { RefreshCw, Settings, Brain, Calculator } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface ModeBannerProps {
  currentMode?: 'ml' | 'rules';
  onRerun?: () => void;
  showRerunButton?: boolean;
}

export function ModeBanner({ currentMode = 'ml', onRerun, showRerunButton = true }: ModeBannerProps) {
  const [mode, setMode] = useState<'ml' | 'rules'>(currentMode);
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    setMode(currentMode);
  }, [currentMode]);

  const handleModeToggle = async () => {
    setLoading(true);
    try {
      const newMode = mode === 'ml' ? 'rules' : 'ml';
      
      const response = await fetch('/api/admin/match-config', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ algorithm: newMode }),
      });

      if (response.ok) {
        setMode(newMode);
        toast({
          title: "Algorithm Updated",
          description: `Switched to ${newMode === 'ml' ? 'Machine Learning' : 'Rules-based'} matching`,
        });
        
        // Auto-rerun if callback provided
        if (onRerun) {
          setTimeout(onRerun, 500);
        }
      } else {
        throw new Error('Failed to update algorithm');
      }
    } catch (error) {
      console.error('Error updating algorithm:', error);
      toast({
        title: "Update Failed",
        description: "Could not change matching algorithm",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleRerun = () => {
    if (onRerun) {
      onRerun();
    }
  };

  const getModeIcon = (algorithmMode: 'ml' | 'rules') => {
    return algorithmMode === 'ml' ? <Brain className="h-4 w-4" /> : <Calculator className="h-4 w-4" />;
  };

  const getModeColor = (algorithmMode: 'ml' | 'rules') => {
    return algorithmMode === 'ml' ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200' : 
                                   'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
  };

  const getModeDescription = (algorithmMode: 'ml' | 'rules') => {
    return algorithmMode === 'ml' 
      ? 'AI-powered matching using neural embeddings and semantic similarity'
      : 'Mathematical matching based on cognitive profile alignment';
  };

  return (
    <Card className="mb-6 border-l-4 border-l-primary bg-gradient-to-r from-background to-muted/20">
      <CardContent className="pt-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <Settings className="h-5 w-5 text-muted-foreground" />
              <span className="font-medium">Matching Algorithm:</span>
            </div>
            
            <Badge 
              variant="secondary" 
              className={`flex items-center gap-2 px-3 py-1 ${getModeColor(mode)}`}
            >
              {getModeIcon(mode)}
              {mode === 'ml' ? 'Machine Learning' : 'Rules-based'}
            </Badge>
            
            <Button
              variant="outline"
              size="sm"
              onClick={handleModeToggle}
              disabled={loading}
              className="h-8"
            >
              {loading ? (
                <RefreshCw className="h-4 w-4 animate-spin" />
              ) : (
                <>
                  {getModeIcon(mode === 'ml' ? 'rules' : 'ml')}
                  Switch to {mode === 'ml' ? 'Rules' : 'ML'}
                </>
              )}
            </Button>
          </div>

          {showRerunButton && (
            <Button
              variant="default"
              size="sm"
              onClick={handleRerun}
              className="flex items-center gap-2"
            >
              <RefreshCw className="h-4 w-4" />
              Rerun Matching
            </Button>
          )}
        </div>
        
        <div className="mt-3 text-sm text-muted-foreground">
          {getModeDescription(mode)}
        </div>
      </CardContent>
    </Card>
  );
}