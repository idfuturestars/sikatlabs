import { useState, useEffect, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { 
  Timer, 
  Zap, 
  Trophy, 
  Share2, 
  Brain, 
  Target,
  Users,
  Sparkles,
  Medal,
  Crown,
  Flame
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { motion, AnimatePresence } from "framer-motion";

interface Question {
  id: string;
  type: 'visual' | 'logical' | 'memory' | 'pattern' | 'verbal';
  question: string;
  options: string[];
  correctAnswer: number;
  difficulty: 'easy' | 'medium' | 'hard';
  timeLimit: number;
  points: number;
}

interface LeaderboardEntry {
  rank: number;
  username: string;
  score: number;
  timeCompleted: number;
  streak: number;
  badge: string;
}

const VIRAL_QUESTIONS: Question[] = [
  {
    id: "vq_1",
    type: "pattern",
    question: "What comes next in the sequence: 🔵 🔴 🔵 🔴 🔵 ?",
    options: ["🔵", "🔴", "🟡", "🟢"],
    correctAnswer: 1,
    difficulty: "easy",
    timeLimit: 3000,
    points: 10
  },
  {
    id: "vq_2", 
    type: "logical",
    question: "If all Bloops are Razzies and all Razzies are Lazzies, then all Bloops are:",
    options: ["Lazzies", "Not Lazzies", "Sometimes Lazzies", "Cannot determine"],
    correctAnswer: 0,
    difficulty: "medium",
    timeLimit: 4000,
    points: 15
  },
  {
    id: "vq_3",
    type: "memory",
    question: "Remember this sequence: 7, 3, 9, 1, 5. What was the 3rd number?",
    options: ["7", "3", "9", "1"],
    correctAnswer: 2,
    difficulty: "medium", 
    timeLimit: 3500,
    points: 20
  },
  {
    id: "vq_4",
    type: "visual",
    question: "How many triangles can you see in this figure: ▲▲▲ arranged in a pyramid?",
    options: ["3", "6", "9", "10"],
    correctAnswer: 2,
    difficulty: "hard",
    timeLimit: 5000,
    points: 25
  },
  {
    id: "vq_5",
    type: "verbal",
    question: "OCEAN is to WATER as DESERT is to:",
    options: ["Sand", "Hot", "Dry", "Cactus"],
    correctAnswer: 0,
    difficulty: "medium",
    timeLimit: 4000,
    points: 15
  }
];

const LEADERBOARD_DATA: LeaderboardEntry[] = [
  { rank: 1, username: "CognitiveAce", score: 95, timeCompleted: 12.3, streak: 15, badge: "🏆" },
  { rank: 2, username: "BrainStorm", score: 92, timeCompleted: 13.1, streak: 12, badge: "🥈" },
  { rank: 3, username: "MindMaster", score: 89, timeCompleted: 14.2, streak: 8, badge: "🥉" },
  { rank: 4, username: "LogicLord", score: 87, timeCompleted: 14.8, streak: 6, badge: "🎖️" },
  { rank: 5, username: "PatternPro", score: 85, timeCompleted: 15.2, streak: 4, badge: "⭐" }
];

export default function EnhancedViralChallenge() {
  const { toast } = useToast();
  const [gameState, setGameState] = useState<'waiting' | 'playing' | 'completed'>('waiting');
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [score, setScore] = useState(0);
  const [timeRemaining, setTimeRemaining] = useState(15000);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);
  const [streak, setStreak] = useState(0);
  const [totalTime, setTotalTime] = useState(0);
  const [showLeaderboard, setShowLeaderboard] = useState(false);
  const timerRef = useRef<NodeJS.Timeout>();
  const questionTimerRef = useRef<NodeJS.Timeout>();
  const startTimeRef = useRef<number>();

  useEffect(() => {
    if (gameState === 'playing' && currentQuestion < VIRAL_QUESTIONS.length) {
      const question = VIRAL_QUESTIONS[currentQuestion];
      setTimeRemaining(question.timeLimit);
      setSelectedAnswer(null);
      setIsCorrect(null);
      
      // Question timer
      questionTimerRef.current = setInterval(() => {
        setTimeRemaining(prev => {
          if (prev <= 100) {
            handleTimeout();
            return 0;
          }
          return prev - 100;
        });
      }, 100);
    }

    return () => {
      if (questionTimerRef.current) {
        clearInterval(questionTimerRef.current);
      }
    };
  }, [currentQuestion, gameState]);

  const startChallenge = () => {
    setGameState('playing');
    setCurrentQuestion(0);
    setScore(0);
    setStreak(0);
    startTimeRef.current = Date.now();
    toast({
      title: "🧠 Challenge Started!",
      description: "15 seconds of pure cognitive power. Let's go!"
    });
  };

  const handleAnswer = (answerIndex: number) => {
    if (selectedAnswer !== null || gameState !== 'playing') return;
    
    setSelectedAnswer(answerIndex);
    const question = VIRAL_QUESTIONS[currentQuestion];
    const correct = answerIndex === question.correctAnswer;
    setIsCorrect(correct);
    
    if (questionTimerRef.current) {
      clearInterval(questionTimerRef.current);
    }

    if (correct) {
      const timeBonus = Math.floor(timeRemaining / 100);
      const streakBonus = streak * 2;
      const points = question.points + timeBonus + streakBonus;
      setScore(prev => prev + points);
      setStreak(prev => prev + 1);
      toast({
        title: "🎉 Correct!",
        description: `+${points} points (${question.points} base + ${timeBonus} speed + ${streakBonus} streak)`
      });
    } else {
      setStreak(0);
      toast({
        title: "❌ Incorrect",
        description: "Keep going! Every mistake is learning.",
        variant: "destructive"
      });
    }

    // Move to next question after brief delay
    setTimeout(() => {
      if (currentQuestion + 1 < VIRAL_QUESTIONS.length) {
        setCurrentQuestion(prev => prev + 1);
      } else {
        completeChallenge();
      }
    }, 1500);
  };

  const handleTimeout = () => {
    setIsCorrect(false);
    setStreak(0);
    toast({
      title: "⏰ Time's up!",
      description: "Speed matters in viral challenges!"
    });

    setTimeout(() => {
      if (currentQuestion + 1 < VIRAL_QUESTIONS.length) {
        setCurrentQuestion(prev => prev + 1);
      } else {
        completeChallenge();
      }
    }, 1000);
  };

  const completeChallenge = () => {
    setGameState('completed');
    setTotalTime((Date.now() - (startTimeRef.current || Date.now())) / 1000);
    
    // Calculate final metrics
    const accuracy = Math.round((score / (VIRAL_QUESTIONS.reduce((acc, q) => acc + q.points, 0))) * 100);
    const rank = calculateRank(score);
    
    toast({
      title: "🏆 Challenge Complete!",
      description: `Score: ${score} | Accuracy: ${accuracy}% | Rank: #${rank}`
    });
  };

  const calculateRank = (finalScore: number): number => {
    const betterScores = LEADERBOARD_DATA.filter(entry => entry.score > finalScore).length;
    return betterScores + 1;
  };

  const shareResults = async () => {
    const shareText = `I just scored ${score} points in the EIQ™ Viral 15-Second Challenge! 🧠✨ Can you beat my score?`;
    
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'EIQ™ Viral Challenge Results',
          text: shareText,
          url: window.location.href
        });
      } catch (error) {
        copyToClipboard(shareText);
      }
    } else {
      copyToClipboard(shareText);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied to clipboard!",
      description: "Share your score with friends and challenge them!"
    });
  };

  const getBadgeForScore = (score: number): string => {
    if (score >= 90) return "🏆";
    if (score >= 80) return "🥇";
    if (score >= 70) return "🥈";
    if (score >= 60) return "🥉";
    return "🎯";
  };

  if (gameState === 'waiting') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 p-6">
        <div className="max-w-4xl mx-auto">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center space-y-8"
          >
            <div className="space-y-4">
              <div className="flex items-center justify-center space-x-3">
                <Sparkles className="w-8 h-8 text-yellow-400" />
                <h1 className="text-5xl font-bold text-white">Viral 15-Second Challenge</h1>
                <Flame className="w-8 h-8 text-red-400" />
              </div>
              <p className="text-xl text-purple-200 max-w-2xl mx-auto">
                Test your cognitive reflexes with our lightning-fast micro-assessment. 
                5 questions, 15 seconds total, infinite possibilities.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-3xl mx-auto">
              <Card className="bg-white/10 border-white/20 backdrop-blur-sm">
                <CardContent className="pt-6 text-center">
                  <Timer className="w-8 h-8 text-cyan-400 mx-auto mb-2" />
                  <h3 className="font-bold text-white">Lightning Fast</h3>
                  <p className="text-purple-200 text-sm">3-5 seconds per question</p>
                </CardContent>
              </Card>
              <Card className="bg-white/10 border-white/20 backdrop-blur-sm">
                <CardContent className="pt-6 text-center">
                  <Brain className="w-8 h-8 text-pink-400 mx-auto mb-2" />
                  <h3 className="font-bold text-white">Multi-Modal</h3>
                  <p className="text-purple-200 text-sm">Pattern, logic, memory, visual</p>
                </CardContent>
              </Card>
              <Card className="bg-white/10 border-white/20 backdrop-blur-sm">
                <CardContent className="pt-6 text-center">
                  <Trophy className="w-8 h-8 text-yellow-400 mx-auto mb-2" />
                  <h3 className="font-bold text-white">Competitive</h3>
                  <p className="text-purple-200 text-sm">Real-time leaderboard</p>
                </CardContent>
              </Card>
            </div>

            <div className="space-y-4">
              <Button 
                onClick={startChallenge}
                size="lg"
                className="bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white font-bold py-4 px-8 text-xl rounded-full shadow-lg hover:shadow-xl transform hover:scale-105 transition-all"
              >
                <Zap className="w-6 h-6 mr-2" />
                Start 15-Second Challenge
              </Button>
              <div className="flex justify-center space-x-4">
                <Button 
                  variant="outline" 
                  onClick={() => setShowLeaderboard(!showLeaderboard)}
                  className="border-white/30 text-white hover:bg-white/10"
                >
                  <Users className="w-4 h-4 mr-2" />
                  Leaderboard
                </Button>
              </div>
            </div>

            <AnimatePresence>
              {showLeaderboard && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                >
                  <Card className="bg-white/10 border-white/20 backdrop-blur-sm">
                    <CardHeader>
                      <CardTitle className="text-white flex items-center">
                        <Trophy className="w-5 h-5 mr-2 text-yellow-400" />
                        Global Leaderboard
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        {LEADERBOARD_DATA.slice(0, 5).map((entry) => (
                          <div key={entry.rank} className="flex items-center justify-between bg-white/5 rounded-lg p-3">
                            <div className="flex items-center space-x-3">
                              <span className="text-2xl">{entry.badge}</span>
                              <div>
                                <div className="text-white font-medium">{entry.username}</div>
                                <div className="text-purple-300 text-sm">{entry.timeCompleted}s • {entry.streak} streak</div>
                              </div>
                            </div>
                            <div className="text-right">
                              <div className="text-xl font-bold text-white">{entry.score}</div>
                              <div className="text-purple-300 text-sm">#{entry.rank}</div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        </div>
      </div>
    );
  }

  if (gameState === 'playing') {
    const question = VIRAL_QUESTIONS[currentQuestion];
    const progress = ((currentQuestion + 1) / VIRAL_QUESTIONS.length) * 100;
    const timeProgress = (timeRemaining / question.timeLimit) * 100;

    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 p-6">
        <div className="max-w-3xl mx-auto">
          <motion.div 
            key={currentQuestion}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-6"
          >
            {/* Progress & Stats */}
            <div className="flex items-center justify-between text-white">
              <div className="flex items-center space-x-4">
                <Badge variant="outline" className="border-white/30 text-white">
                  Question {currentQuestion + 1}/{VIRAL_QUESTIONS.length}
                </Badge>
                <Badge variant="outline" className="border-yellow-400/30 text-yellow-400">
                  Score: {score}
                </Badge>
                <Badge variant="outline" className="border-green-400/30 text-green-400">
                  Streak: {streak}
                </Badge>
              </div>
              <div className="text-right">
                <div className="text-sm text-purple-200">Time Remaining</div>
                <div className="text-2xl font-bold">{(timeRemaining / 1000).toFixed(1)}s</div>
              </div>
            </div>

            <Progress value={progress} className="h-2" />
            <Progress value={timeProgress} className="h-1 bg-red-900/50" />

            {/* Question Card */}
            <Card className="bg-white/10 border-white/20 backdrop-blur-sm">
              <CardHeader>
                <div className="flex items-center space-x-2">
                  <Target className="w-5 h-5 text-cyan-400" />
                  <Badge variant="outline" className="border-cyan-400/30 text-cyan-400 capitalize">
                    {question.type}
                  </Badge>
                  <Badge variant="outline" className="border-purple-400/30 text-purple-400 capitalize">
                    {question.difficulty}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                <h2 className="text-2xl font-bold text-white leading-relaxed">
                  {question.question}
                </h2>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {question.options.map((option, index) => (
                    <motion.button
                      key={index}
                      onClick={() => handleAnswer(index)}
                      disabled={selectedAnswer !== null}
                      className={`
                        p-4 rounded-lg text-left font-medium transition-all transform hover:scale-105
                        ${selectedAnswer === null 
                          ? 'bg-white/10 hover:bg-white/20 text-white border border-white/20' 
                          : selectedAnswer === index
                            ? isCorrect 
                              ? 'bg-green-500/20 border-green-400 text-green-100'
                              : 'bg-red-500/20 border-red-400 text-red-100'
                            : index === question.correctAnswer && !isCorrect
                              ? 'bg-green-500/20 border-green-400 text-green-100'
                              : 'bg-white/5 text-white/60 border-white/10'
                        }
                      `}
                      whileHover={{ scale: selectedAnswer === null ? 1.02 : 1 }}
                      whileTap={{ scale: selectedAnswer === null ? 0.98 : 1 }}
                    >
                      <span className="text-lg">{option}</span>
                    </motion.button>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    );
  }

  // Completed state
  const accuracy = Math.round((score / (VIRAL_QUESTIONS.reduce((acc, q) => acc + q.points, 0))) * 100);
  const rank = calculateRank(score);
  const badge = getBadgeForScore(score);

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 p-6">
      <div className="max-w-4xl mx-auto">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center space-y-8"
        >
          <div className="space-y-4">
            <div className="text-6xl mb-4">{badge}</div>
            <h1 className="text-4xl font-bold text-white">Challenge Complete!</h1>
            <p className="text-xl text-purple-200">Your cognitive reflexes have been measured.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <Card className="bg-white/10 border-white/20 backdrop-blur-sm">
              <CardContent className="pt-6 text-center">
                <div className="text-3xl font-bold text-white">{score}</div>
                <div className="text-purple-200">Final Score</div>
              </CardContent>
            </Card>
            <Card className="bg-white/10 border-white/20 backdrop-blur-sm">
              <CardContent className="pt-6 text-center">
                <div className="text-3xl font-bold text-white">{accuracy}%</div>
                <div className="text-purple-200">Accuracy</div>
              </CardContent>
            </Card>
            <Card className="bg-white/10 border-white/20 backdrop-blur-sm">
              <CardContent className="pt-6 text-center">
                <div className="text-3xl font-bold text-white">#{rank}</div>
                <div className="text-purple-200">Global Rank</div>
              </CardContent>
            </Card>
            <Card className="bg-white/10 border-white/20 backdrop-blur-sm">
              <CardContent className="pt-6 text-center">
                <div className="text-3xl font-bold text-white">{totalTime.toFixed(1)}s</div>
                <div className="text-purple-200">Total Time</div>
              </CardContent>
            </Card>
          </div>

          <div className="flex justify-center space-x-4">
            <Button 
              onClick={shareResults}
              size="lg"
              className="bg-gradient-to-r from-green-500 to-teal-600 hover:from-green-600 hover:to-teal-700"
            >
              <Share2 className="w-5 h-5 mr-2" />
              Share Results
            </Button>
            <Button 
              onClick={startChallenge}
              size="lg"
              variant="outline"
              className="border-white/30 text-white hover:bg-white/10"
            >
              Try Again
            </Button>
          </div>
        </motion.div>
      </div>
    </div>
  );
}