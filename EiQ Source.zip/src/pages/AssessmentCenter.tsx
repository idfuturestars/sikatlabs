import { useState, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  Target, 
  Brain, 
  Calculator, 
  Mic, 
  Users, 
  Zap, 
  BookOpen, 
  Clock, 
  Trophy,
  CheckCircle,
  PlayCircle,
  BarChart3
} from "lucide-react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import ModernLayout from "@/components/layout/ModernLayout";
import BrandingFooter from "@/components/common/BrandingFooter";


export default function AssessmentCenter() {
  const [, setLocation] = useLocation();

  const handleSectionChange = useCallback((section: string) => {
    if (section === "dashboard") {
      setLocation("/");
    } else {
      const route = section.includes("-") ? `/${section}` : `/${section.replace("_", "-")}`;
      setLocation(route);
    }
  }, [setLocation]);

  // Real backend data integration
  const { data: dashboardMetrics } = useQuery({
    queryKey: ["/api/analytics/dashboard-metrics"],
    staleTime: 2 * 60 * 1000, // 2 minutes
    gcTime: 5 * 60 * 1000, // 5 minutes
  });

  const { data: systemMetrics } = useQuery({
    queryKey: ["/api/analytics/system-metrics"],
    staleTime: 1 * 60 * 1000, // 1 minute
    gcTime: 5 * 60 * 1000, // 5 minutes
  });

  const assessmentCategories = [
    {
      id: "ai-immersion",
      title: "AI Immersion Assessment",
      description: "3-section adaptive assessment with zero question repetition",
      icon: Brain,
      color: "text-blue-500",
      bgColor: "bg-blue-500/10",
      borderColor: "border-blue-500/20",
      sections: [
        { name: "Core Math", weight: 25, completed: false },
        { name: "Applied Reasoning", weight: 40, completed: false },
        { name: "AI Conceptual", weight: 35, completed: false }
      ],
      features: ["IRT-based adaptive difficulty", "Real-time hint system", "ML-powered personalization"],
      route: "/test-ai-immersion"
    },
    {
      id: "standardized-tests",
      title: "Standardized Test Prep", 
      description: "SAT/ACT practice tests with adaptive scoring",
      icon: Calculator,
      color: "text-green-500",
      bgColor: "bg-green-500/10",
      borderColor: "border-green-500/20",
      sections: [
        { name: "SAT Math", weight: 50, completed: false },
        { name: "SAT Verbal", weight: 50, completed: false },
        { name: "ACT Composite", weight: 100, completed: false }
      ],
      features: ["Official question formats", "Score prediction", "Weakness analysis"],
      route: "/standardized-tests"
    },
    {
      id: "personality-assessment",
      title: "Personality & Cognitive Assessment",
      description: "Myers Briggs, DISC, OCEAN Big Five, and DSM integration",
      icon: Users,
      color: "text-purple-500",
      bgColor: "bg-purple-500/10",
      borderColor: "border-purple-500/20",
      sections: [
        { name: "Myers Briggs", weight: 30, completed: false },
        { name: "DISC Assessment", weight: 25, completed: false },
        { name: "Big Five", weight: 25, completed: false },
        { name: "DSM Integration", weight: 20, completed: false }
      ],
      features: ["Comprehensive personality profiling", "Cognitive evaluation", "Career alignment"],
      route: "/personality-assessment"
    },
    {
      id: "voice-multimodal",
      title: "Voice & Multi-Modal Assessment",
      description: "Voice-to-text analysis with AI evaluation",
      icon: Mic,
      color: "text-orange-500",
      bgColor: "bg-orange-500/10",
      borderColor: "border-orange-500/20",
      sections: [
        { name: "Voice Analysis", weight: 40, completed: false },
        { name: "Visual Assessment", weight: 30, completed: false },
        { name: "Interactive Tasks", weight: 30, completed: false }
      ],
      features: ["Real-time voice processing", "Multi-language support", "AI comprehension analysis"],
      route: "/voice-assessment"
    },
    {
      id: "turing-test",
      title: "AI Literacy & Turing Test",
      description: "Assess ability to distinguish AI vs human content",
      icon: Zap,
      color: "text-cyan-500",
      bgColor: "bg-cyan-500/10",
      borderColor: "border-cyan-500/20",
      sections: [
        { name: "Content Detection", weight: 40, completed: false },
        { name: "AI Generation", weight: 35, completed: false },
        { name: "Analysis Tasks", weight: 25, completed: false }
      ],
      features: ["AI content detection", "Response evaluation", "Digital literacy scoring"],
      route: "/turing-test"
    },
    {
      id: "comprehensive-eiq",
      title: "Comprehensive EiQ★ Evaluation",
      description: "Full 260-question assessment with FICO-like scoring",
      icon: Trophy,
      color: "text-gold-500",
      bgColor: "bg-yellow-500/10",
      borderColor: "border-yellow-500/20",
      sections: [
        { name: "Baseline (60Q)", weight: 23, completed: false },
        { name: "Comprehensive (260Q)", weight: 77, completed: false }
      ],
      features: ["300-850 EiQ★ scoring", "Domain breakdowns", "Predictive analytics"],
      route: "/idfs-assessment"
    }
  ];

  const quickActions = [
    {
      id: "viral-challenge",
      title: "15-Second Challenge",
      description: "Quick viral assessment",
      icon: Clock,
      route: "/challenge"
    },
    {
      id: "adaptive-practice",
      title: "Adaptive Practice",
      description: "Personalized question sets",
      icon: Target,
      route: "/assessment"
    },
    {
      id: "progress-review",
      title: "Progress Review",
      description: "View assessment history",
      icon: BarChart3,
      route: "/eiq-analytics"
    }
  ];

  const handleStartAssessment = (route: string) => {
    setLocation(route);
  };

  const renderContent = () => (
    <div className="container mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Assessment Center</h1>
          <p className="text-muted-foreground mt-2">
            Comprehensive AI-driven assessments with adaptive difficulty and zero question repetition
          </p>
        </div>
        <Badge variant="secondary" className="px-3 py-1">
          Production Ready
        </Badge>
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Zap className="h-5 w-5 text-blue-500" />
            Quick Start
          </CardTitle>
          <CardDescription>
            Jump into assessments or review your progress
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {quickActions.map((action) => (
              <Button
                key={action.id}
                variant="outline"
                className="h-auto p-4 flex flex-col items-start"
                onClick={() => handleStartAssessment(action.route)}
              >
                <div className="flex items-center gap-2 mb-2">
                  <action.icon className="h-5 w-5" />
                  <span className="font-medium">{action.title}</span>
                </div>
                <span className="text-sm text-muted-foreground">{action.description}</span>
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Assessment Categories */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {assessmentCategories.map((category) => (
          <Card key={category.id} className={`${category.borderColor} border-2`}>
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg ${category.bgColor}`}>
                    <category.icon className={`h-6 w-6 ${category.color}`} />
                  </div>
                  <div>
                    <CardTitle className="text-xl">{category.title}</CardTitle>
                    <CardDescription className="mt-1">
                      {category.description}
                    </CardDescription>
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Assessment Sections */}
              <div>
                <h4 className="font-medium mb-2">Assessment Sections:</h4>
                <div className="space-y-2">
                  {category.sections.map((section, idx) => (
                    <div key={idx} className="flex items-center justify-between text-sm">
                      <div className="flex items-center gap-2">
                        {section.completed ? (
                          <CheckCircle className="h-4 w-4 text-green-500" />
                        ) : (
                          <PlayCircle className="h-4 w-4 text-muted-foreground" />
                        )}
                        <span>{section.name}</span>
                      </div>
                      <Badge variant="outline" className="text-xs">
                        {section.weight}%
                      </Badge>
                    </div>
                  ))}
                </div>
              </div>

              {/* Key Features */}
              <div>
                <h4 className="font-medium mb-2">Key Features:</h4>
                <ul className="text-sm text-muted-foreground space-y-1">
                  {category.features.map((feature, idx) => (
                    <li key={idx} className="flex items-center gap-2">
                      <CheckCircle className="h-3 w-3 text-green-500" />
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>

              {/* Progress */}
              <div>
                <div className="flex items-center justify-between text-sm mb-2">
                  <span>Overall Progress</span>
                  <span>0%</span>
                </div>
                <Progress value={0} className="h-2" />
              </div>

              {/* Action Button */}
              <Button 
                className="w-full mt-4"
                onClick={() => handleStartAssessment(category.route)}
              >
                Start Assessment
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Assessment Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <Target className="h-8 w-8 mx-auto mb-2 text-blue-500" />
            <div className="text-2xl font-bold">{((dashboardMetrics as any)?.assessmentCompletions || 0).toLocaleString()}</div>
            <div className="text-sm text-muted-foreground">Assessments Completed</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <Brain className="h-8 w-8 mx-auto mb-2 text-green-500" />
            <div className="text-2xl font-bold">{(dashboardMetrics as any)?.averageEiqScore || '--'}</div>
            <div className="text-sm text-muted-foreground">Current EiQ™ Score</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <Trophy className="h-8 w-8 mx-auto mb-2 text-yellow-500" />
            <div className="text-2xl font-bold">
              {(dashboardMetrics as any)?.averageEiqScore ? 
                Math.round((((dashboardMetrics as any).averageEiqScore - 300) / 550) * 100) : '--'}
              {(dashboardMetrics as any)?.averageEiqScore ? '%' : ''}
            </div>
            <div className="text-sm text-muted-foreground">Percentile Rank</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <Clock className="h-8 w-8 mx-auto mb-2 text-purple-500" />
            <div className="text-2xl font-bold">
              {(systemMetrics as any)?.performanceMetrics?.averageSessionDuration ? 
                Math.round((systemMetrics as any).performanceMetrics.averageSessionDuration) : 0}
            </div>
            <div className="text-sm text-muted-foreground">Hours Practiced</div>
          </CardContent>
        </Card>
      </div>
      
      {/* Branding Footer */}
      <div className="mt-8 pt-8 border-t">
        <BrandingFooter variant="full" />
      </div>
    </div>
  );

  return (
    <ModernLayout 
      activeSection="assessment-center"
      onSectionChange={handleSectionChange}
      className="p-8"
    >
      {renderContent()}
    </ModernLayout>
  );
}