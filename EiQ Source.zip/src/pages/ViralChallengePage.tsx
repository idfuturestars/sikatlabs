import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Brain, Zap, Trophy, Users, Clock, Play } from "lucide-react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface Challenge {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
  category: string;
  timeEstimate: number;
}

interface ChallengeSession {
  sessionId: string;
  challengeType: string;
  timeLimit: number;
  questions: Challenge[];
  startTime: number;
}

export default function ViralChallengePage() {
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [score, setScore] = useState(0);
  const [timeRemaining, setTimeRemaining] = useState(15);
  const [isActive, setIsActive] = useState(false);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showResults, setShowResults] = useState(false);

  // Start challenge mutation
  const startChallengeMutation = useMutation({
    mutationFn: async (challengeType: string) => {
      const response = await apiRequest("POST", "/api/viral-challenge/start", {
        challengeType,
        difficulty: "medium"
      });
      return response.json();
    },
    onSuccess: (data: ChallengeSession) => {
      setSessionId(data.sessionId);
      setTimeRemaining(data.timeLimit);
      setIsActive(true);
      setCurrentQuestion(0);
      setScore(0);
      setShowResults(false);
    }
  });

  // Get session data
  const { data: session } = useQuery<ChallengeSession>({
    queryKey: ["/api/viral-challenge/session", sessionId],
    enabled: !!sessionId,
    refetchInterval: 1000, // Real-time updates
  });

  // Timer effect
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    
    if (isActive && timeRemaining > 0) {
      interval = setInterval(() => {
        setTimeRemaining((time) => {
          if (time <= 1) {
            handleTimeOut();
            return 0;
          }
          return time - 1;
        });
      }, 1000);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isActive, timeRemaining]);

  const handleTimeOut = () => {
    setIsActive(false);
    if (session?.questions && currentQuestion < session.questions.length - 1) {
      // Auto-advance to next question
      setTimeout(() => {
        setCurrentQuestion(prev => prev + 1);
        setTimeRemaining(15);
        setIsActive(true);
        setSelectedAnswer(null);
      }, 1000);
    } else {
      // Challenge complete
      setShowResults(true);
    }
  };

  const handleAnswer = (answerIndex: number) => {
    if (!isActive || !session?.questions) return;
    
    setSelectedAnswer(answerIndex);
    setIsActive(false);

    // Check if correct
    const currentQ = session.questions[currentQuestion];
    const isCorrect = answerIndex === currentQ.correctAnswer;
    
    if (isCorrect) {
      setScore(prev => prev + Math.max(1, Math.floor(timeRemaining / 2)));
    }

    // Auto-advance after showing result
    setTimeout(() => {
      if (currentQuestion < session.questions.length - 1) {
        setCurrentQuestion(prev => prev + 1);
        setTimeRemaining(15);
        setIsActive(true);
        setSelectedAnswer(null);
      } else {
        setShowResults(true);
      }
    }, 1500);
  };

  const resetChallenge = () => {
    setSessionId(null);
    setCurrentQuestion(0);
    setScore(0);
    setTimeRemaining(15);
    setIsActive(false);
    setSelectedAnswer(null);
    setShowResults(false);
  };

  return (
    <div className="min-h-screen bg-background p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Brain className="w-8 h-8 text-primary" />
            <h1 className="text-3xl font-bold">EiQ★ Viral Challenge</h1>
          </div>
          <p className="text-muted-foreground">Test your intelligence with our adaptive challenges</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Card>
            <CardContent className="flex items-center gap-3 p-4">
              <Zap className="w-8 h-8 text-yellow-500" />
              <div>
                <p className="text-sm text-muted-foreground">Current Score</p>
                <p className="text-2xl font-bold">{score}</p>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="flex items-center gap-3 p-4">
              <Trophy className="w-8 h-8 text-orange-500" />
              <div>
                <p className="text-sm text-muted-foreground">Best Score</p>
                <p className="text-2xl font-bold">180</p>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="flex items-center gap-3 p-4">
              <Users className="w-8 h-8 text-blue-500" />
              <div>
                <p className="text-sm text-muted-foreground">Participants</p>
                <p className="text-2xl font-bold">12.4K</p>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="flex items-center gap-3 p-4">
              <Brain className="w-8 h-8 text-green-500" />
              <div>
                <p className="text-sm text-muted-foreground">Progress</p>
                <p className="text-2xl font-bold">{currentQuestion + 1}/{session?.questions?.length || 3}</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Start Challenge Section */}
        {!sessionId && (
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Play className="w-5 h-5" />
                Start Your Challenge
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-muted-foreground">
                Choose your challenge duration and test your intelligence with our adaptive questions!
              </p>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Button 
                  onClick={() => startChallengeMutation.mutate('15_second')}
                  disabled={startChallengeMutation.isPending}
                  className="bg-red-600 hover:bg-red-700"
                >
                  <Zap className="w-4 h-4 mr-2" />
                  15-Second Lightning
                </Button>
                <Button 
                  onClick={() => startChallengeMutation.mutate('30_second')}
                  disabled={startChallengeMutation.isPending}
                  className="bg-orange-600 hover:bg-orange-700"
                >
                  <Clock className="w-4 h-4 mr-2" />
                  30-Second Sprint
                </Button>
                <Button 
                  onClick={() => startChallengeMutation.mutate('60_second')}
                  disabled={startChallengeMutation.isPending}
                  className="bg-green-600 hover:bg-green-700"
                >
                  <Brain className="w-4 h-4 mr-2" />
                  60-Second Marathon
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Active Challenge */}
        {sessionId && session?.questions && !showResults && (
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Brain className="w-5 h-5" />
                  Question {currentQuestion + 1} of {session.questions.length}
                </div>
                <div className={`flex items-center gap-2 px-3 py-1 rounded-full ${
                  timeRemaining <= 5 ? 'bg-red-100 text-red-800' : 
                  timeRemaining <= 10 ? 'bg-orange-100 text-orange-800' : 
                  'bg-green-100 text-green-800'
                }`}>
                  <Clock className="w-4 h-4" />
                  {timeRemaining}s
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <h3 className="text-lg font-medium mb-4">
                  {session.questions[currentQuestion]?.question}
                </h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {session.questions[currentQuestion]?.options.map((option, index) => (
                  <Button
                    key={index}
                    variant={selectedAnswer === index ? 
                      (selectedAnswer === session.questions[currentQuestion]?.correctAnswer ? "default" : "destructive") 
                      : "outline"
                    }
                    className={`p-4 h-auto text-left justify-start ${
                      selectedAnswer !== null && index === session.questions[currentQuestion]?.correctAnswer 
                        ? 'bg-green-100 border-green-500 text-green-800' : ''
                    }`}
                    onClick={() => handleAnswer(index)}
                    disabled={!isActive}
                  >
                    {String.fromCharCode(65 + index)}. {option}
                  </Button>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
        )}

        {/* Results Section */}
        {showResults && (
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Trophy className="w-5 h-5" />
                Challenge Complete!
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6 text-center">
              <div>
                <h3 className="text-3xl font-bold text-primary mb-2">Final Score: {score}</h3>
                <p className="text-muted-foreground">
                  You answered {session?.questions?.length || 0} questions
                </p>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Button onClick={resetChallenge} className="bg-primary">
                  <Play className="w-4 h-4 mr-2" />
                  Try Again
                </Button>
                <Button variant="outline" onClick={() => {
                  // Share functionality
                  if (navigator.share) {
                    navigator.share({
                      title: 'EiQ★ Viral Challenge',
                      text: `I just scored ${score} points on the EiQ★ Viral Challenge! Can you beat my score?`,
                      url: window.location.href
                    });
                  }
                }}>
                  <Users className="w-4 h-4 mr-2" />
                  Share Result
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}