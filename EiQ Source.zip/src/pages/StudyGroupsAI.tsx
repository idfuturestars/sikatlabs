import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { 
  Users, 
  Brain, 
  Target, 
  BookOpen, 
  Clock, 
  Award, 
  TrendingUp, 
  MessageSquare,
  Play,
  Plus,
  Settings,
  Star,
  ChevronRight,
  Bot,
  Sparkles,
  BarChart3,
  Calendar,
  CheckCircle2,
  AlertCircle,
  Lightbulb,
  PieChart
} from "lucide-react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import ModernLayout from "@/components/layout/ModernLayout";
import { useCallback } from "react";

interface StudyGroup {
  id: string;
  name: string;
  description: string;
  subject: string;
  maxMembers: number;
  currentMembers: number;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  isPrivate: boolean;
  aiFeatures: {
    welcomeMessage: string;
    studyPlan: string[];
    recommendedResources: string[];
    progressTracking: boolean;
    aiModerator: boolean;
  };
  createdBy: string;
  createdAt: string;
  memberProfiles: any[];
  studySchedule: any[];
  performanceMetrics: {
    averageEngagement: number;
    completionRate: number;
    knowledgeGains: number;
  };
}

interface AIStudyRecommendations {
  studyPlan: string[];
  resources: string[];
  schedule: any[];
  personalizedTips: string[];
  difficultyAdjustments: string[];
}

export default function StudyGroupsAI() {
  const [, setLocation] = useLocation();
  
  const handleSectionChange = useCallback((section: string) => {
    if (section === "dashboard") {
      setLocation("/");
    } else {
      const route = section.includes("-") ? `/${section}` : `/${section.replace("_", "-")}`;
      setLocation(route);
    }
  }, [setLocation]);

  const [selectedGroup, setSelectedGroup] = useState<StudyGroup | null>(null);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newGroupData, setNewGroupData] = useState({
    name: "",
    description: "",
    subject: "",
    maxMembers: 8,
    difficulty: 'intermediate' as const,
    isPrivate: false
  });
  const { toast } = useToast();

  // Fetch Study Groups with AI Analytics
  const { data: studyGroups, refetch: refetchGroups } = useQuery<StudyGroup[]>({
    queryKey: ["/api/study-groups/ai-enhanced"],
    staleTime: 30 * 1000, // 30 seconds
  });

  // AI-Generated Study Recommendations
  const { data: aiRecommendations } = useQuery<AIStudyRecommendations>({
    queryKey: ["/api/study-groups/ai-recommendations"],
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  // User's Study Group Analytics
  const { data: userAnalytics } = useQuery({
    queryKey: ["/api/study-groups/user-analytics"],
    staleTime: 2 * 60 * 1000, // 2 minutes
  });

  // Type-safe analytics data with proper fallbacks
  const analytics = (userAnalytics as any) || {};

  // Create AI-Enhanced Study Group
  const createGroupMutation = useMutation({
    mutationFn: async (groupData: any) => {
      return apiRequest("POST", "/api/study-groups/create", {
        ...groupData,
        aiEnhanced: true,
        generateWelcomeMessage: true,
        createStudyPlan: true,
        enableProgressTracking: true
      });
    },
    onSuccess: (group) => {
      setSelectedGroup(group);
      setShowCreateModal(false);
      refetchGroups();
      toast({
        title: "AI Study Group Created",
        description: `${group.name} created with AI-powered features and study plan`,
      });
    }
  });

  // Join Study Group with AI Analysis
  const joinGroupMutation = useMutation({
    mutationFn: async (groupId: string) => {
      return apiRequest("POST", `/api/study-groups/${groupId}/join`);
    },
    onSuccess: (data) => {
      refetchGroups();
      toast({
        title: "Joined Study Group",
        description: data.aiWelcomeMessage || "Welcome to the group! AI recommendations coming soon.",
      });
    }
  });

  // Generate AI Study Plan
  const generatePlanMutation = useMutation({
    mutationFn: async ({ groupId, preferences }: { groupId: string; preferences: any }) => {
      return apiRequest("POST", `/api/study-groups/${groupId}/generate-plan`, preferences);
    },
    onSuccess: (plan) => {
      toast({
        title: "AI Study Plan Generated",
        description: `Custom study plan created with ${plan.modules.length} learning modules`,
      });
    }
  });

  const aiEnhancedGroups = [
    {
      id: "ai-math-mastery",
      name: "AI Math Mastery Collective",
      description: "Advanced mathematics study group with AI-powered problem generation and personalized learning paths",
      subject: "Mathematics",
      maxMembers: 12,
      currentMembers: 8,
      difficulty: 'advanced' as const,
      isPrivate: false,
      aiFeatures: {
        welcomeMessage: "Welcome! Our AI has analyzed your math profile and prepared a customized learning journey. You'll excel in algebra and should focus on calculus foundations.",
        studyPlan: [
          "Week 1-2: Algebraic Foundations Review",
          "Week 3-4: Advanced Calculus Concepts",
          "Week 5-6: Real-world Applications",
          "Week 7-8: Collaborative Problem Solving"
        ],
        recommendedResources: [
          "Khan Academy Calculus Series",
          "MIT OpenCourseWare Mathematics",
          "AI-Generated Practice Problems",
          "Peer Study Sessions"
        ],
        progressTracking: true,
        aiModerator: true
      },
      createdBy: "Dr. Sarah Chen",
      createdAt: "2025-08-15",
      memberProfiles: [
        { name: "Alex", strengths: ["Algebra"], improvement: ["Calculus"], level: 7.2 },
        { name: "Maya", strengths: ["Geometry"], improvement: ["Statistics"], level: 8.1 },
        { name: "Jordan", strengths: ["Logic"], improvement: ["Applied Math"], level: 7.8 }
      ],
      studySchedule: [
        { day: "Monday", time: "7:00 PM", topic: "Calculus Problem Sets", duration: "90 min" },
        { day: "Wednesday", time: "6:30 PM", topic: "Group Discussion", duration: "60 min" },
        { day: "Friday", time: "7:00 PM", topic: "AI Challenge Problems", duration: "75 min" }
      ],
      performanceMetrics: {
        averageEngagement: 87.4,
        completionRate: 92.1,
        knowledgeGains: 78.5
      }
    },
    {
      id: "science-explorers-ai",
      name: "Science Explorers AI Lab",
      description: "Multi-disciplinary science study group with AI experiment suggestions and research guidance",
      subject: "Science",
      maxMembers: 10,
      currentMembers: 6,
      difficulty: 'intermediate' as const,
      isPrivate: false,
      aiFeatures: {
        welcomeMessage: "Hello! Based on your science assessment, you show exceptional potential in biology and physics. Our AI has curated experiments and discussions tailored to your learning style.",
        studyPlan: [
          "Week 1-2: Scientific Method & AI Research Tools",
          "Week 3-4: Biology Lab Simulations",
          "Week 5-6: Physics Experiments & Analysis",
          "Week 7-8: Cross-disciplinary Projects"
        ],
        recommendedResources: [
          "Virtual Science Labs",
          "AI Research Assistant",
          "Scientific Journal Access",
          "Expert Guest Speakers"
        ],
        progressTracking: true,
        aiModerator: true
      },
      createdBy: "Prof. Maria Rodriguez",
      createdAt: "2025-08-12",
      memberProfiles: [
        { name: "Emma", strengths: ["Biology"], improvement: ["Chemistry"], level: 6.9 },
        { name: "Liam", strengths: ["Physics"], improvement: ["Biology"], level: 7.4 },
        { name: "Zoe", strengths: ["Chemistry"], improvement: ["Physics"], level: 6.7 }
      ],
      studySchedule: [
        { day: "Tuesday", time: "6:00 PM", topic: "Lab Experiment Review", duration: "120 min" },
        { day: "Thursday", time: "7:00 PM", topic: "AI Research Session", duration: "90 min" },
        { day: "Saturday", time: "2:00 PM", topic: "Group Project Work", duration: "180 min" }
      ],
      performanceMetrics: {
        averageEngagement: 82.3,
        completionRate: 89.6,
        knowledgeGains: 74.2
      }
    }
  ];

  const renderGroupCard = (group: StudyGroup) => (
    <Card key={group.id} className="border-border hover:border-primary/50 transition-all duration-200">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-lg flex items-center gap-2">
              <Brain className="w-5 h-5 text-primary" />
              {group.name}
            </CardTitle>
            <CardDescription className="text-sm">
              {group.description}
            </CardDescription>
          </div>
          <Badge variant="outline" className="text-xs">
            {group.subject}
          </Badge>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        <div className="flex items-center justify-between text-sm">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1">
              <Users className="w-4 h-4 text-muted-foreground" />
              <span>{group.currentMembers}/{group.maxMembers}</span>
            </div>
            <div className="flex items-center gap-1">
              <Target className="w-4 h-4 text-muted-foreground" />
              <span className="capitalize">{group.difficulty}</span>
            </div>
          </div>
          <div className="text-xs text-muted-foreground">
            Created by {group.createdBy}
          </div>
        </div>

        {/* AI Features Highlight */}
        <div className="bg-primary/5 rounded-lg p-3 space-y-2">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-primary" />
            <span className="text-sm font-medium text-primary">AI-Enhanced Features</span>
          </div>
          <div className="text-xs space-y-1">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-3 h-3 text-green-500" />
              <span>Personalized Welcome & Study Plan</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-3 h-3 text-green-500" />
              <span>AI Progress Tracking & Analytics</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-3 h-3 text-green-500" />
              <span>Intelligent Resource Recommendations</span>
            </div>
          </div>
        </div>

        {/* Performance Metrics */}
        <div className="grid grid-cols-3 gap-2 text-xs">
          <div className="text-center">
            <div className="font-medium text-primary">{group.performanceMetrics.averageEngagement}%</div>
            <div className="text-muted-foreground">Engagement</div>
          </div>
          <div className="text-center">
            <div className="font-medium text-primary">{group.performanceMetrics.completionRate}%</div>
            <div className="text-muted-foreground">Completion</div>
          </div>
          <div className="text-center">
            <div className="font-medium text-primary">{group.performanceMetrics.knowledgeGains}%</div>
            <div className="text-muted-foreground">Knowledge</div>
          </div>
        </div>

        {/* Study Schedule Preview */}
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <Calendar className="w-4 h-4 text-primary" />
            <span className="text-sm font-medium">Weekly Schedule</span>
          </div>
          <div className="space-y-1">
            {group.studySchedule.slice(0, 2).map((session, idx) => (
              <div key={idx} className="text-xs flex items-center justify-between bg-muted/50 rounded px-2 py-1">
                <span>{session.day} {session.time}</span>
                <span className="text-muted-foreground">{session.duration}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="flex gap-2">
          <Button 
            onClick={() => joinGroupMutation.mutate(group.id)}
            disabled={joinGroupMutation.isPending || group.currentMembers >= group.maxMembers}
            className="flex-1"
            size="sm"
          >
            Join Group
          </Button>
          <Button variant="outline" size="sm" onClick={() => setSelectedGroup(group)}>
            <BarChart3 className="w-4 h-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );

  const renderContent = () => (
    <div className="container mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-3">
            <Brain className="w-8 h-8 text-primary" />
            AI Study Groups
          </h1>
          <p className="text-muted-foreground mt-2">
            Intelligent collaborative learning with AI-powered study plans and progress tracking
          </p>
        </div>

        <div className="flex gap-2">
          <Button 
            onClick={() => generatePlanMutation.mutate({ 
              groupId: "current", 
              preferences: { focus: "weak_areas", style: "collaborative" } 
            })}
            variant="outline"
          >
            <Lightbulb className="w-4 h-4 mr-2" />
            AI Study Plan
          </Button>
          <Button onClick={() => setShowCreateModal(true)}>
            <Plus className="w-4 h-4 mr-2" />
            Create Group
          </Button>
        </div>
      </div>

      <Tabs defaultValue="groups" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="groups">Study Groups</TabsTrigger>
          <TabsTrigger value="my-groups">My Groups</TabsTrigger>
          <TabsTrigger value="ai-insights">AI Insights</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>

        <TabsContent value="groups" className="space-y-6">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {aiEnhancedGroups.map(renderGroupCard)}
            {studyGroups?.map(renderGroupCard)}
          </div>
        </TabsContent>

        <TabsContent value="my-groups" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5 text-primary" />
                Your Study Groups
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-12">
                <Brain className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-medium mb-2">Join Your First AI Study Group</h3>
                <p className="text-muted-foreground mb-4">
                  Get personalized study plans and collaborative learning experiences
                </p>
                <Button onClick={() => setShowCreateModal(true)}>
                  <Plus className="w-4 h-4 mr-2" />
                  Create Study Group
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="ai-insights" className="space-y-6">
          {aiRecommendations ? (
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-primary" />
                    AI Study Recommendations
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h4 className="font-medium mb-2">Personalized Study Plan</h4>
                    <ul className="text-sm space-y-1">
                      {aiRecommendations.studyPlan.map((item, idx) => (
                        <li key={idx} className="flex items-start gap-2">
                          <ChevronRight className="w-3 h-3 text-primary mt-0.5" />
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                  
                  <div>
                    <h4 className="font-medium mb-2">Recommended Resources</h4>
                    <div className="grid grid-cols-2 gap-2">
                      {aiRecommendations.resources.map((resource, idx) => (
                        <div key={idx} className="text-sm bg-muted/50 rounded px-3 py-2">
                          <BookOpen className="w-3 h-3 text-primary inline mr-1" />
                          {resource}
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h4 className="font-medium mb-2">AI Tips for Success</h4>
                    <ul className="text-sm space-y-1">
                      {aiRecommendations.personalizedTips.map((tip, idx) => (
                        <li key={idx} className="flex items-start gap-2">
                          <Star className="w-3 h-3 text-yellow-500 mt-0.5" />
                          <span>{tip}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </CardContent>
              </Card>
            </div>
          ) : (
            <Card>
              <CardContent className="flex items-center justify-center py-12">
                <div className="text-center">
                  <Brain className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-medium mb-2">AI Insights Loading</h3>
                  <p className="text-muted-foreground">Analyzing your learning patterns...</p>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="analytics" className="space-y-6">
          {userAnalytics ? (
            <div className="grid gap-6 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <PieChart className="w-5 h-5 text-primary" />
                    Study Group Performance
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span>Average Engagement</span>
                      <div className="flex items-center gap-2">
                        <Progress value={analytics.averageEngagement || 75} className="w-20" />
                        <span className="text-sm">{analytics.averageEngagement || 75}%</span>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Knowledge Growth</span>
                      <div className="flex items-center gap-2">
                        <Progress value={analytics.knowledgeGrowth || 68} className="w-20" />
                        <span className="text-sm">{analytics.knowledgeGrowth || 68}%</span>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Collaboration Score</span>
                      <div className="flex items-center gap-2">
                        <Progress value={analytics.collaborationScore || 82} className="w-20" />
                        <span className="text-sm">{analytics.collaborationScore || 82}%</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="w-5 h-5 text-primary" />
                    Learning Insights
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-medium text-green-600 mb-2">Strengths</h4>
                      <ul className="text-sm space-y-1">
                        <li className="flex items-center gap-2">
                          <CheckCircle2 className="w-3 h-3 text-green-500" />
                          Active group participation
                        </li>
                        <li className="flex items-center gap-2">
                          <CheckCircle2 className="w-3 h-3 text-green-500" />
                          Consistent study schedule
                        </li>
                      </ul>
                    </div>
                    <div>
                      <h4 className="font-medium text-orange-600 mb-2">Growth Areas</h4>
                      <ul className="text-sm space-y-1">
                        <li className="flex items-center gap-2">
                          <AlertCircle className="w-3 h-3 text-orange-500" />
                          Increase peer interactions
                        </li>
                        <li className="flex items-center gap-2">
                          <AlertCircle className="w-3 h-3 text-orange-500" />
                          Focus on challenging topics
                        </li>
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          ) : (
            <Card>
              <CardContent className="flex items-center justify-center py-12">
                <div className="text-center">
                  <BarChart3 className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-medium mb-2">Analytics Loading</h3>
                  <p className="text-muted-foreground">Calculating your study group performance...</p>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>

      {/* Create Group Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <Card className="w-full max-w-md mx-4">
            <CardHeader>
              <CardTitle>Create AI Study Group</CardTitle>
              <CardDescription>
                AI will generate welcome messages and study plans automatically
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="name">Group Name</Label>
                <Input
                  id="name"
                  value={newGroupData.name}
                  onChange={(e) => setNewGroupData({ ...newGroupData, name: e.target.value })}
                  placeholder="e.g., Advanced Physics Study Group"
                />
              </div>
              <div>
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={newGroupData.description}
                  onChange={(e) => setNewGroupData({ ...newGroupData, description: e.target.value })}
                  placeholder="Brief description of the study group focus..."
                />
              </div>
              <div>
                <Label htmlFor="subject">Subject</Label>
                <Input
                  id="subject"
                  value={newGroupData.subject}
                  onChange={(e) => setNewGroupData({ ...newGroupData, subject: e.target.value })}
                  placeholder="e.g., Mathematics, Science, Literature"
                />
              </div>
              <div>
                <Label htmlFor="maxMembers">Max Members</Label>
                <Input
                  id="maxMembers"
                  type="number"
                  value={newGroupData.maxMembers}
                  onChange={(e) => setNewGroupData({ ...newGroupData, maxMembers: parseInt(e.target.value) })}
                  min="2"
                  max="20"
                />
              </div>
            </CardContent>
            <div className="flex gap-2 p-6 pt-0">
              <Button
                variant="outline"
                onClick={() => setShowCreateModal(false)}
                className="flex-1"
              >
                Cancel
              </Button>
              <Button
                onClick={() => createGroupMutation.mutate(newGroupData)}
                disabled={createGroupMutation.isPending}
                className="flex-1"
              >
                Create Group
              </Button>
            </div>
          </Card>
        </div>
      )}
    </div>
  );

  return (
    <ModernLayout 
      activeSection="study-groups-ai"
      onSectionChange={handleSectionChange}
    >
      {renderContent()}
    </ModernLayout>
  );
}