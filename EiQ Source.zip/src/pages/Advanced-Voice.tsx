import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { 
  Mic, 
  Volume2, 
  Brain,
  Activity,
  Settings,
  Play,
  Pause,
  Square,
  Languages,
  TrendingUp,
  FileAudio,
  Zap,
  Target,
  Clock,
  CheckCircle,
  AlertTriangle,
  Award,
  LineChart,
  BookOpen,
  Lightbulb,
  MessageSquare,
  Globe,
  BarChart3,
  Headphones
} from "lucide-react";
import { useState, useRef, useEffect } from "react";

interface VoiceAnalysisResult {
  id: string;
  transcript: string;
  confidence: number;
  duration: number;
  aiAnalysis: {
    comprehension: number;
    articulation: number;
    vocabulary: number;
    fluency: number;
    technicalAccuracy: number;
    overallScore: number;
    insights: string[];
    recommendations: string[];
    skillLevel: 'beginner' | 'intermediate' | 'advanced' | 'expert';
  };
  timestamp: string;
}

interface VoiceSession {
  id: string;
  promptType: string;
  language: string;
  duration: number;
  score: number;
  analysis: VoiceAnalysisResult;
  createdAt: string;
}

interface VoicePrompt {
  id: string;
  category: string;
  title: string;
  description: string;
  text: string;
  expectedDuration: number;
  difficulty: string;
  language: string;
}

export default function AdvancedVoice() {
  const [activeTab, setActiveTab] = useState("assessment");
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const [selectedLanguage, setSelectedLanguage] = useState("english");
  const [selectedPrompt, setSelectedPrompt] = useState<string | null>(null);
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const [transcript, setTranscript] = useState("");
  const [currentMode, setCurrentMode] = useState("reading-comprehension");
  
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  // Fetch voice prompts
  const { data: voicePrompts } = useQuery<VoicePrompt[]>({
    queryKey: ["/api/voice/prompts", selectedLanguage, currentMode],
    staleTime: 10 * 60 * 1000, // 10 minutes
  });

  // Fetch voice analysis results
  const { data: voiceAnalysis } = useQuery<VoiceAnalysisResult[]>({
    queryKey: ["/api/voice/analysis-history"],
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  // Fetch voice sessions
  const { data: voiceSessions } = useQuery<VoiceSession[]>({
    queryKey: ["/api/voice/sessions"],
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  // Process voice recording
  const processVoiceMutation = useMutation({
    mutationFn: async ({ audioBlob, promptId, transcript }: { 
      audioBlob: Blob; 
      promptId: string; 
      transcript: string; 
    }) => {
      const formData = new FormData();
      formData.append('audio', audioBlob, 'recording.webm');
      formData.append('promptId', promptId);
      formData.append('transcript', transcript);
      formData.append('language', selectedLanguage);
      formData.append('duration', recordingTime.toString());

      return await apiRequest("/api/voice/process", {
        method: "POST",
        body: formData,
        headers: {}, // Let browser set content-type for FormData
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/voice/analysis-history"] });
      queryClient.invalidateQueries({ queryKey: ["/api/voice/sessions"] });
      toast({
        title: "Analysis Complete",
        description: "Your voice recording has been analyzed successfully.",
      });
      setAudioBlob(null);
      setTranscript("");
      setRecordingTime(0);
    },
    onError: () => {
      toast({
        title: "Analysis Failed",
        description: "Failed to process your voice recording. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Enhanced voice analysis
  const enhancedAnalysisMutation = useMutation({
    mutationFn: async (sessionId: string) => {
      return await apiRequest(`/api/voice/enhanced-analysis/${sessionId}`, {
        method: "POST",
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/voice/analysis-history"] });
      toast({
        title: "Enhanced Analysis Complete",
        description: "Detailed voice metrics and feedback are now available.",
      });
    },
  });

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;
      
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      
      const chunks: BlobPart[] = [];
      mediaRecorder.ondataavailable = (event) => {
        chunks.push(event.data);
      };
      
      mediaRecorder.onstop = () => {
        const blob = new Blob(chunks, { type: 'audio/webm' });
        setAudioBlob(blob);
      };
      
      mediaRecorder.start();
      setIsRecording(true);
      setRecordingTime(0);
      
      intervalRef.current = setInterval(() => {
        setRecordingTime(prev => prev + 1);
      }, 1000);
      
    } catch (error) {
      toast({
        title: "Recording Failed",
        description: "Unable to access microphone. Please check permissions.",
        variant: "destructive",
      });
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
      
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(track => track.stop());
      }
    }
  };

  const toggleRecording = () => {
    if (isRecording) {
      stopRecording();
    } else {
      startRecording();
    }
  };

  const submitAnalysis = () => {
    if (audioBlob && selectedPrompt && transcript.trim()) {
      processVoiceMutation.mutate({
        audioBlob,
        promptId: selectedPrompt,
        transcript: transcript.trim()
      });
    } else {
      toast({
        title: "Incomplete Submission",
        description: "Please record audio and provide a transcript before submitting.",
        variant: "destructive",
      });
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const getScoreColor = (score: number) => {
    if (score >= 90) return "text-green-600";
    if (score >= 80) return "text-blue-600";
    if (score >= 70) return "text-orange-600";
    return "text-red-600";
  };

  const getSkillLevelBadge = (level: string) => {
    const colors = {
      beginner: "bg-red-100 text-red-800",
      intermediate: "bg-yellow-100 text-yellow-800",
      advanced: "bg-blue-100 text-blue-800",
      expert: "bg-green-100 text-green-800"
    };
    return colors[level as keyof typeof colors] || colors.beginner;
  };

  useEffect(() => {
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  const assessmentModes = [
    {
      id: "reading-comprehension",
      title: "Reading Comprehension",
      description: "Read passages aloud with AI-powered analysis",
      icon: BookOpen,
      color: "text-blue-600",
      bgColor: "bg-blue-100"
    },
    {
      id: "conversational-ai",
      title: "Conversational Assessment",
      description: "Natural dialogue with AI on academic topics",
      icon: MessageSquare,
      color: "text-green-600",
      bgColor: "bg-green-100"
    },
    {
      id: "pronunciation-analysis",
      title: "Pronunciation Analysis",
      description: "Detailed phonetic analysis and correction",
      icon: Volume2,
      color: "text-purple-600",
      bgColor: "bg-purple-100"
    },
    {
      id: "presentation-skills",
      title: "Presentation Skills",
      description: "Practice presentations with real-time feedback",
      icon: Award,
      color: "text-orange-600",
      bgColor: "bg-orange-100"
    }
  ];

  const supportedLanguages = [
    { id: "english", name: "English", flag: "🇺🇸" },
    { id: "spanish", name: "Spanish", flag: "🇪🇸" },
    { id: "french", name: "French", flag: "🇫🇷" },
    { id: "german", name: "German", flag: "🇩🇪" },
    { id: "mandarin", name: "Mandarin", flag: "🇨🇳" },
    { id: "japanese", name: "Japanese", flag: "🇯🇵" }
  ];

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-4">
          <h1 className="text-4xl font-bold gradient-text">Advanced Voice & Multi-Modal Assessment</h1>
          <p className="text-muted-foreground max-w-3xl mx-auto">
            Comprehensive voice analysis with AI-powered feedback across multiple languages and assessment modes
          </p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="assessment">Voice Assessment</TabsTrigger>
            <TabsTrigger value="recording">Recording Studio</TabsTrigger>
            <TabsTrigger value="results">Analysis Results</TabsTrigger>
            <TabsTrigger value="history">Session History</TabsTrigger>
          </TabsList>

          <TabsContent value="assessment" className="space-y-6">
            {/* Assessment Mode Selection */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="w-5 h-5" />
                  Assessment Mode Selection
                </CardTitle>
                <p className="text-muted-foreground">Choose your preferred assessment type and language</p>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-4 mb-6">
                  {assessmentModes.map((mode) => (
                    <div 
                      key={mode.id}
                      className={`border rounded-lg p-4 cursor-pointer transition-all ${
                        currentMode === mode.id ? 'border-primary bg-primary/5' : 'hover:border-primary/50'
                      }`}
                      onClick={() => setCurrentMode(mode.id)}
                    >
                      <div className="flex items-center gap-3 mb-2">
                        <div className={`p-2 ${mode.bgColor} rounded-lg`}>
                          <mode.icon className={`w-5 h-5 ${mode.color}`} />
                        </div>
                        <h3 className="font-medium">{mode.title}</h3>
                      </div>
                      <p className="text-sm text-muted-foreground">{mode.description}</p>
                    </div>
                  ))}
                </div>

                {/* Language Selection */}
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="text-sm font-medium mb-2 block">Assessment Language</label>
                    <Select value={selectedLanguage} onValueChange={setSelectedLanguage}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select language" />
                      </SelectTrigger>
                      <SelectContent>
                        {supportedLanguages.map((lang) => (
                          <SelectItem key={lang.id} value={lang.id}>
                            <span className="flex items-center gap-2">
                              <span>{lang.flag}</span>
                              <span>{lang.name}</span>
                            </span>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <label className="text-sm font-medium mb-2 block">Voice Prompt</label>
                    <Select value={selectedPrompt || ""} onValueChange={setSelectedPrompt}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select prompt" />
                      </SelectTrigger>
                      <SelectContent>
                        {voicePrompts?.map((prompt) => (
                          <SelectItem key={prompt.id} value={prompt.id}>
                            {prompt.title} ({prompt.difficulty})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {selectedPrompt && voicePrompts && (
                  <div className="mt-6 p-4 bg-muted/30 rounded-lg">
                    <h4 className="font-medium mb-2">Assessment Prompt</h4>
                    <p className="text-sm text-muted-foreground mb-2">
                      {voicePrompts.find(p => p.id === selectedPrompt)?.description}
                    </p>
                    <div className="p-3 bg-background rounded border">
                      <p className="text-sm">
                        {voicePrompts.find(p => p.id === selectedPrompt)?.text}
                      </p>
                    </div>
                    <div className="flex items-center gap-4 mt-3 text-xs text-muted-foreground">
                      <span>Expected duration: {voicePrompts.find(p => p.id === selectedPrompt)?.expectedDuration} minutes</span>
                      <span>Difficulty: {voicePrompts.find(p => p.id === selectedPrompt)?.difficulty}</span>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="recording" className="space-y-6">
            {/* Recording Studio */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Mic className="w-5 h-5" />
                  Voice Recording Studio
                </CardTitle>
                <p className="text-muted-foreground">Record your voice response for AI analysis</p>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Recording Controls */}
                <div className="text-center space-y-4">
                  <div className={`w-32 h-32 rounded-full mx-auto flex items-center justify-center transition-all ${
                    isRecording ? 'bg-red-500 animate-pulse' : 'bg-primary'
                  }`}>
                    <Mic className="w-16 h-16 text-white" />
                  </div>
                  
                  <div className="text-2xl font-mono">
                    {formatTime(recordingTime)}
                  </div>

                  <div className="flex items-center justify-center gap-4">
                    <Button
                      onClick={toggleRecording}
                      size="lg"
                      className={isRecording ? "bg-red-500 hover:bg-red-600" : ""}
                      disabled={!selectedPrompt || processVoiceMutation.isPending}
                    >
                      {isRecording ? (
                        <>
                          <Square className="w-4 h-4 mr-2" />
                          Stop Recording
                        </>
                      ) : (
                        <>
                          <Play className="w-4 h-4 mr-2" />
                          Start Recording
                        </>
                      )}
                    </Button>
                  </div>

                  {!selectedPrompt && (
                    <p className="text-sm text-muted-foreground">
                      Please select an assessment prompt before recording
                    </p>
                  )}
                </div>

                {/* Transcript Input */}
                <div>
                  <label className="text-sm font-medium mb-2 block">
                    Transcript (Optional - helps improve analysis accuracy)
                  </label>
                  <Textarea
                    value={transcript}
                    onChange={(e) => setTranscript(e.target.value)}
                    placeholder="Enter what you said during the recording..."
                    className="min-h-[100px]"
                    disabled={processVoiceMutation.isPending}
                  />
                </div>

                {/* Submit Button */}
                {audioBlob && (
                  <div className="text-center">
                    <Button
                      onClick={submitAnalysis}
                      disabled={processVoiceMutation.isPending}
                      size="lg"
                    >
                      {processVoiceMutation.isPending ? (
                        <>
                          <Activity className="w-4 h-4 mr-2 animate-spin" />
                          Analyzing...
                        </>
                      ) : (
                        <>
                          <Brain className="w-4 h-4 mr-2" />
                          Analyze Recording
                        </>
                      )}
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="results" className="space-y-6">
            {/* Analysis Results */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="w-5 h-5" />
                  Voice Analysis Results
                </CardTitle>
                <p className="text-muted-foreground">Comprehensive AI-powered voice assessment feedback</p>
              </CardHeader>
              <CardContent>
                {voiceAnalysis && voiceAnalysis.length > 0 ? (
                  <div className="space-y-6">
                    {voiceAnalysis.slice(0, 3).map((analysis) => (
                      <div key={analysis.id} className="border rounded-lg p-6">
                        <div className="flex justify-between items-start mb-4">
                          <div>
                            <h3 className="text-lg font-semibold mb-1">Voice Analysis Report</h3>
                            <p className="text-sm text-muted-foreground">
                              Recorded: {new Date(analysis.timestamp).toLocaleDateString()} • 
                              Duration: {formatTime(analysis.duration)} • 
                              Confidence: {Math.round(analysis.confidence * 100)}%
                            </p>
                          </div>
                          <Badge className={getSkillLevelBadge(analysis.aiAnalysis.skillLevel)}>
                            {analysis.aiAnalysis.skillLevel}
                          </Badge>
                        </div>

                        {/* Score Breakdown */}
                        <div className="grid md:grid-cols-3 gap-4 mb-6">
                          <div className="text-center p-4 bg-muted/30 rounded-lg">
                            <div className={`text-3xl font-bold ${getScoreColor(analysis.aiAnalysis.overallScore)}`}>
                              {analysis.aiAnalysis.overallScore}
                            </div>
                            <div className="text-sm text-muted-foreground">Overall Score</div>
                          </div>
                          <div className="space-y-3">
                            <div className="flex justify-between items-center">
                              <span className="text-sm">Comprehension</span>
                              <span className="font-medium">{analysis.aiAnalysis.comprehension}%</span>
                            </div>
                            <div className="flex justify-between items-center">
                              <span className="text-sm">Articulation</span>
                              <span className="font-medium">{analysis.aiAnalysis.articulation}%</span>
                            </div>
                            <div className="flex justify-between items-center">
                              <span className="text-sm">Vocabulary</span>
                              <span className="font-medium">{analysis.aiAnalysis.vocabulary}%</span>
                            </div>
                          </div>
                          <div className="space-y-3">
                            <div className="flex justify-between items-center">
                              <span className="text-sm">Fluency</span>
                              <span className="font-medium">{analysis.aiAnalysis.fluency}%</span>
                            </div>
                            <div className="flex justify-between items-center">
                              <span className="text-sm">Technical Accuracy</span>
                              <span className="font-medium">{analysis.aiAnalysis.technicalAccuracy}%</span>
                            </div>
                          </div>
                        </div>

                        {/* AI Insights */}
                        {analysis.aiAnalysis.insights.length > 0 && (
                          <div className="mb-4">
                            <h4 className="font-medium mb-2 flex items-center gap-2">
                              <Brain className="w-4 h-4" />
                              AI Insights
                            </h4>
                            <ul className="space-y-1 text-sm">
                              {analysis.aiAnalysis.insights.map((insight, i) => (
                                <li key={i} className="flex items-start gap-2">
                                  <Zap className="w-3 h-3 mt-1 text-blue-500 flex-shrink-0" />
                                  <span>{insight}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}

                        {/* Recommendations */}
                        {analysis.aiAnalysis.recommendations.length > 0 && (
                          <div className="p-4 bg-blue-50 rounded-lg">
                            <h4 className="font-medium mb-2 flex items-center gap-2">
                              <Lightbulb className="w-4 h-4" />
                              Educational Recommendations
                            </h4>
                            <ul className="space-y-1 text-sm">
                              {analysis.aiAnalysis.recommendations.map((rec, i) => (
                                <li key={i} className="flex items-start gap-2">
                                  <Target className="w-3 h-3 mt-1 text-blue-500 flex-shrink-0" />
                                  <span>{rec}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}

                        {/* Transcript */}
                        {analysis.transcript && (
                          <div className="mt-4 p-3 bg-muted/30 rounded">
                            <h4 className="font-medium mb-2 text-sm">Transcript</h4>
                            <p className="text-sm text-muted-foreground">{analysis.transcript}</p>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <Headphones className="w-16 h-16 mx-auto mb-4 text-muted-foreground opacity-50" />
                    <h3 className="text-lg font-medium mb-2">No Analysis Results</h3>
                    <p className="text-muted-foreground mb-4">Complete a voice assessment to see detailed results here</p>
                    <Button onClick={() => setActiveTab("recording")}>
                      Start Recording
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="history" className="space-y-6">
            {/* Session History */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="w-5 h-5" />
                  Voice Assessment History
                </CardTitle>
                <p className="text-muted-foreground">Track your progress over time</p>
              </CardHeader>
              <CardContent>
                {voiceSessions && voiceSessions.length > 0 ? (
                  <div className="space-y-4">
                    {voiceSessions.map((session) => (
                      <div key={session.id} className="border rounded-lg p-4">
                        <div className="flex justify-between items-start mb-3">
                          <div>
                            <h4 className="font-medium">{session.promptType.replace('-', ' ')}</h4>
                            <p className="text-sm text-muted-foreground">
                              {new Date(session.createdAt).toLocaleDateString()} • 
                              Duration: {formatTime(session.duration)} • 
                              Language: {session.language}
                            </p>
                          </div>
                          <div className="text-right">
                            <div className={`text-xl font-bold ${getScoreColor(session.score)}`}>
                              {session.score}
                            </div>
                            <div className="text-xs text-muted-foreground">Score</div>
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <Button 
                            size="sm" 
                            variant="outline"
                            onClick={() => enhancedAnalysisMutation.mutate(session.id)}
                            disabled={enhancedAnalysisMutation.isPending}
                          >
                            Enhanced Analysis
                          </Button>
                          <Button size="sm" variant="outline">
                            View Details
                          </Button>
                          <Button size="sm" variant="outline">
                            Download Report
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <FileAudio className="w-16 h-16 mx-auto mb-4 text-muted-foreground opacity-50" />
                    <h3 className="text-lg font-medium mb-2">No Session History</h3>
                    <p className="text-muted-foreground mb-4">Your voice assessment sessions will appear here</p>
                    <Button onClick={() => setActiveTab("assessment")}>
                      Start Assessment
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}