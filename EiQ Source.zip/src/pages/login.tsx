import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardContent, CardTitle } from "@/components/ui/card";
import EiQLogo from "@/components/common/EiQLogo";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

export default function Login() {
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const handleGoogleLogin = () => {
    setLoading(true);
    window.location.href = "/api/auth/google";
  };

  const handleAppleLogin = () => {
    setLoading(true);
    window.location.href = "/api/auth/apple";
  };

  const handleGitHubLogin = () => {
    setLoading(true);
    window.location.href = "/api/auth/github";
  };

  const handleDemoLogin = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/auth/demo-token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      });
      
      if (response.ok) {
        const data = await response.json();
        localStorage.setItem('auth_token', data.token);
        window.location.href = '/';
      } else {
        throw new Error('Demo login failed');
      }
    } catch (error) {
      toast({
        title: "Login Failed",
        description: "Please try again",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-100 dark:from-gray-900 dark:to-green-900 flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <EiQLogo size="lg" variant="full" />
          </div>
          <CardTitle>Welcome to EiQ™</CardTitle>
          <p className="text-sm text-gray-600 dark:text-gray-300">
            Sign in to access your personalized learning experience
          </p>
          <div className="text-xs text-center text-muted-foreground mt-2">
            EiQ ™ powered by SikatLabs™|IDFS Pathway™|Alteria™
            <br />
            ©2025. All rights reserved.
          </div>
        </CardHeader>
        
        <CardContent>
          <div className="space-y-4">
            <Button
              onClick={handleGoogleLogin}
              className="w-full"
              variant="default"
              disabled={loading}
            >
              {loading ? "Connecting..." : "Continue with Google"}
            </Button>
            
            <Button
              onClick={handleAppleLogin}
              className="w-full"
              variant="outline"
              disabled={loading}
            >
              {loading ? "Connecting..." : "Continue with Apple"}
            </Button>
            
            <Button
              onClick={handleGitHubLogin}
              className="w-full"
              variant="outline"
              disabled={loading}
            >
              {loading ? "Connecting..." : "Continue with GitHub"}
            </Button>
            
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <span className="w-full border-t" />
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-background px-2 text-muted-foreground">Or</span>
              </div>
            </div>
            
            <Button
              onClick={handleDemoLogin}
              className="w-full"
              variant="secondary"
              disabled={loading}
            >
              {loading ? "Connecting..." : "Try Demo Account"}
            </Button>
            
            <div className="text-center text-xs text-gray-500">
              By signing in, you agree to our terms of service and privacy policy.
            </div>
            
            <div className="flex justify-center mt-4">
              <EiQLogo variant="future-stars" size="sm" showText={false} />
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}