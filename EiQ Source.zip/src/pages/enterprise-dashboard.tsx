import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { 
  Users, 
  Building2, 
  Shield, 
  BarChart3, 
  Upload, 
  Download, 
  FileText,
  AlertTriangle,
  CheckCircle,
  Clock,
  TrendingUp,
  Settings,
  Plus,
  Search
} from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { useToast } from '@/hooks/use-toast';

// Enterprise Dashboard for Organization Management
// Comprehensive administration interface for educational institutions

interface OrganizationStats {
  totalUsers: number;
  activeUsers: number;
  departments: number;
  roles: number;
  storageUsed: number;
  apiCallsThisMonth: number;
  subscriptionStatus: string;
}

interface Department {
  id: string;
  name: string;
  description?: string;
  departmentCode?: string;
  headOfDepartment?: string;
  isActive: boolean;
  userCount?: number;
}

interface Role {
  id: string;
  name: string;
  description?: string;
  roleType: 'system' | 'custom';
  userCount?: number;
  permissions: any;
}

interface AuditLogEntry {
  id: string;
  eventType: string;
  action: string;
  description: string;
  userId?: string;
  userEmail?: string;
  timestamp: string;
  riskLevel: string;
}

interface BulkOperation {
  id: string;
  operationType: string;
  operationName: string;
  status: 'pending' | 'running' | 'completed' | 'failed';
  processedCount: number;
  targetCount: number;
  startedAt?: string;
  completedAt?: string;
}

export default function EnterpriseDashboard() {
  const [selectedDepartment, setSelectedDepartment] = useState<string>('');
  const [searchQuery, setSearchQuery] = useState('');
  const [bulkImportFile, setBulkImportFile] = useState<File | null>(null);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Organization stats query
  const { data: orgStats, isLoading: statsLoading } = useQuery({
    queryKey: ['/api/enterprise/organization/stats'],
    retry: 1
  });

  // Departments query  
  const { data: departments, isLoading: departmentsLoading } = useQuery({
    queryKey: ['/api/enterprise/departments'],
    retry: 1
  });

  // Roles query
  const { data: roles, isLoading: rolesLoading } = useQuery({
    queryKey: ['/api/enterprise/roles'], 
    retry: 1
  });

  // Audit logs query
  const { data: auditLogs, isLoading: auditLoading } = useQuery({
    queryKey: ['/api/enterprise/audit-logs'],
    retry: 1
  });

  // Bulk operations query
  const { data: bulkOperations, isLoading: bulkOpsLoading } = useQuery({
    queryKey: ['/api/enterprise/bulk-operations'],
    retry: 1
  });

  // Bulk user import mutation
  const bulkImportMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append('file', file);
      return await apiRequest('/api/enterprise/bulk-import/users', {
        method: 'POST',
        body: formData
      });
    },
    onSuccess: (data) => {
      toast({
        title: 'Bulk Import Successful',
        description: `Successfully imported ${data.successful}/${data.total} users`,
        variant: 'default'
      });
      queryClient.invalidateQueries({ queryKey: ['/api/enterprise'] });
      setBulkImportFile(null);
    },
    onError: (error) => {
      toast({
        title: 'Import Failed', 
        description: 'Failed to import users. Please check your file format.',
        variant: 'destructive'
      });
    }
  });

  // Handle bulk import
  const handleBulkImport = () => {
    if (!bulkImportFile) return;
    bulkImportMutation.mutate(bulkImportFile);
  };

  // Mock data for development
  const mockOrgStats: OrganizationStats = orgStats || {
    totalUsers: 1247,
    activeUsers: 1089,
    departments: 12,
    roles: 8,
    storageUsed: 2.1, // GB
    apiCallsThisMonth: 45231,
    subscriptionStatus: 'Enterprise'
  };

  const mockDepartments: Department[] = departments || [
    { id: '1', name: 'Computer Science', departmentCode: 'CS', isActive: true, userCount: 234 },
    { id: '2', name: 'Mathematics', departmentCode: 'MATH', isActive: true, userCount: 189 },
    { id: '3', name: 'Engineering', departmentCode: 'ENG', isActive: true, userCount: 312 },
    { id: '4', name: 'Business Administration', departmentCode: 'BUS', isActive: true, userCount: 156 }
  ];

  const mockRoles: Role[] = roles || [
    { id: '1', name: 'Organization Admin', roleType: 'system', userCount: 3, permissions: {} },
    { id: '2', name: 'Department Manager', roleType: 'system', userCount: 12, permissions: {} },
    { id: '3', name: 'Instructor', roleType: 'system', userCount: 89, permissions: {} },
    { id: '4', name: 'Student', roleType: 'system', userCount: 1143, permissions: {} }
  ];

  const mockAuditLogs: AuditLogEntry[] = auditLogs || [
    { 
      id: '1', 
      eventType: 'user_action', 
      action: 'role_assigned', 
      description: 'Role assigned to new user',
      userEmail: 'admin@university.edu',
      timestamp: new Date(Date.now() - 2 * 60 * 1000).toISOString(),
      riskLevel: 'low'
    },
    {
      id: '2',
      eventType: 'system_action', 
      action: 'bulk_import',
      description: 'Bulk user import completed: 45/50 users',
      userEmail: 'admin@university.edu', 
      timestamp: new Date(Date.now() - 15 * 60 * 1000).toISOString(),
      riskLevel: 'medium'
    }
  ];

  const mockBulkOps: BulkOperation[] = bulkOperations || [
    {
      id: '1',
      operationType: 'user_import',
      operationName: 'Spring 2025 Student Import',
      status: 'completed',
      processedCount: 45,
      targetCount: 50,
      startedAt: new Date(Date.now() - 20 * 60 * 1000).toISOString(),
      completedAt: new Date(Date.now() - 15 * 60 * 1000).toISOString()
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <div className="border-b bg-white dark:bg-gray-800 px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
              Enterprise Dashboard
            </h1>
            <p className="text-gray-600 dark:text-gray-400 mt-1">
              Comprehensive organization management and administration
            </p>
          </div>
          <div className="flex gap-3">
            <Button variant="outline" data-testid="button-export-data">
              <Download className="w-4 h-4 mr-2" />
              Export Data
            </Button>
            <Button data-testid="button-organization-settings">
              <Settings className="w-4 h-4 mr-2" />
              Settings
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="p-6">
        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card data-testid="card-total-users">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Users</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold" data-testid="text-total-users">
                {mockOrgStats.totalUsers.toLocaleString()}
              </div>
              <p className="text-xs text-muted-foreground">
                {mockOrgStats.activeUsers} active users
              </p>
            </CardContent>
          </Card>

          <Card data-testid="card-departments">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Departments</CardTitle>
              <Building2 className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold" data-testid="text-departments">
                {mockOrgStats.departments}
              </div>
              <p className="text-xs text-muted-foreground">
                {mockOrgStats.roles} custom roles
              </p>
            </CardContent>
          </Card>

          <Card data-testid="card-api-usage">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">API Usage</CardTitle>
              <BarChart3 className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold" data-testid="text-api-usage">
                {mockOrgStats.apiCallsThisMonth.toLocaleString()}
              </div>
              <p className="text-xs text-muted-foreground">
                calls this month
              </p>
            </CardContent>
          </Card>

          <Card data-testid="card-subscription">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Subscription</CardTitle>
              <Shield className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold" data-testid="text-subscription">
                {mockOrgStats.subscriptionStatus}
              </div>
              <p className="text-xs text-muted-foreground">
                {mockOrgStats.storageUsed} GB storage used
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Management Tabs */}
        <Tabs defaultValue="departments" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="departments" data-testid="tab-departments">
              Departments
            </TabsTrigger>
            <TabsTrigger value="roles" data-testid="tab-roles">
              Roles & Permissions
            </TabsTrigger>
            <TabsTrigger value="bulk-ops" data-testid="tab-bulk-operations">
              Bulk Operations
            </TabsTrigger>
            <TabsTrigger value="audit" data-testid="tab-audit">
              Audit Logs
            </TabsTrigger>
            <TabsTrigger value="analytics" data-testid="tab-analytics">
              Analytics
            </TabsTrigger>
          </TabsList>

          {/* Departments Tab */}
          <TabsContent value="departments" className="space-y-6">
            <Card data-testid="card-departments-management">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Department Management</CardTitle>
                    <CardDescription>
                      Organize users into departments for better management
                    </CardDescription>
                  </div>
                  <Button data-testid="button-create-department">
                    <Plus className="w-4 h-4 mr-2" />
                    Create Department
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex gap-4">
                    <Input 
                      placeholder="Search departments..." 
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="max-w-sm"
                      data-testid="input-search-departments"
                    />
                    <Select value={selectedDepartment} onValueChange={setSelectedDepartment}>
                      <SelectTrigger className="w-48" data-testid="select-department-filter">
                        <SelectValue placeholder="Filter by status" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Departments</SelectItem>
                        <SelectItem value="active">Active Only</SelectItem>
                        <SelectItem value="inactive">Inactive Only</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Department</TableHead>
                        <TableHead>Code</TableHead>
                        <TableHead>Users</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {mockDepartments.map((dept) => (
                        <TableRow key={dept.id} data-testid={`row-department-${dept.id}`}>
                          <TableCell className="font-medium">
                            {dept.name}
                          </TableCell>
                          <TableCell>{dept.departmentCode}</TableCell>
                          <TableCell>{dept.userCount}</TableCell>
                          <TableCell>
                            <Badge variant={dept.isActive ? 'default' : 'secondary'}>
                              {dept.isActive ? 'Active' : 'Inactive'}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex gap-2">
                              <Button variant="outline" size="sm" data-testid={`button-edit-department-${dept.id}`}>
                                Edit
                              </Button>
                              <Button variant="outline" size="sm" data-testid={`button-manage-department-${dept.id}`}>
                                Manage Users
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Roles Tab */}
          <TabsContent value="roles" className="space-y-6">
            <Card data-testid="card-roles-management">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Roles & Permissions</CardTitle>
                    <CardDescription>
                      Manage user roles and granular permissions
                    </CardDescription>
                  </div>
                  <Button data-testid="button-create-role">
                    <Plus className="w-4 h-4 mr-2" />
                    Create Custom Role
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Role</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Users</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {mockRoles.map((role) => (
                      <TableRow key={role.id} data-testid={`row-role-${role.id}`}>
                        <TableCell className="font-medium">
                          {role.name}
                        </TableCell>
                        <TableCell>
                          <Badge variant={role.roleType === 'system' ? 'secondary' : 'default'}>
                            {role.roleType}
                          </Badge>
                        </TableCell>
                        <TableCell>{role.userCount}</TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button variant="outline" size="sm" data-testid={`button-view-role-${role.id}`}>
                              View Permissions
                            </Button>
                            {role.roleType === 'custom' && (
                              <Button variant="outline" size="sm" data-testid={`button-edit-role-${role.id}`}>
                                Edit
                              </Button>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Bulk Operations Tab */}
          <TabsContent value="bulk-ops" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* User Import */}
              <Card data-testid="card-bulk-import">
                <CardHeader>
                  <CardTitle>Bulk User Import</CardTitle>
                  <CardDescription>
                    Import multiple users from CSV file
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="border-2 border-dashed rounded-lg p-6 text-center">
                    <Upload className="w-8 h-8 mx-auto mb-4 text-muted-foreground" />
                    <Input
                      type="file"
                      accept=".csv"
                      onChange={(e) => setBulkImportFile(e.target.files?.[0] || null)}
                      className="max-w-sm mx-auto"
                      data-testid="input-import-file"
                    />
                    <p className="text-sm text-muted-foreground mt-2">
                      Upload CSV file with user data
                    </p>
                  </div>
                  
                  {bulkImportFile && (
                    <div className="bg-green-50 dark:bg-green-900/20 p-3 rounded-md">
                      <p className="text-sm text-green-800 dark:text-green-200">
                        File selected: {bulkImportFile.name}
                      </p>
                    </div>
                  )}

                  <Button 
                    onClick={handleBulkImport}
                    disabled={!bulkImportFile || bulkImportMutation.isPending}
                    className="w-full"
                    data-testid="button-start-import"
                  >
                    {bulkImportMutation.isPending ? 'Importing...' : 'Start Import'}
                  </Button>
                </CardContent>
              </Card>

              {/* Operation History */}
              <Card data-testid="card-operation-history">
                <CardHeader>
                  <CardTitle>Recent Operations</CardTitle>
                  <CardDescription>
                    Track bulk operations and their status
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {mockBulkOps.map((op) => (
                      <div key={op.id} className="flex items-center justify-between p-3 border rounded-md" data-testid={`operation-${op.id}`}>
                        <div>
                          <p className="font-medium">{op.operationName}</p>
                          <p className="text-sm text-muted-foreground">
                            {op.processedCount}/{op.targetCount} processed
                          </p>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge 
                            variant={
                              op.status === 'completed' ? 'default' :
                              op.status === 'failed' ? 'destructive' :
                              op.status === 'running' ? 'secondary' : 'outline'
                            }
                          >
                            {op.status}
                          </Badge>
                          {op.status === 'completed' && (
                            <CheckCircle className="w-4 h-4 text-green-600" />
                          )}
                          {op.status === 'failed' && (
                            <AlertTriangle className="w-4 h-4 text-red-600" />
                          )}
                          {op.status === 'running' && (
                            <Clock className="w-4 h-4 text-orange-600" />
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Audit Logs Tab */}
          <TabsContent value="audit" className="space-y-6">
            <Card data-testid="card-audit-logs">
              <CardHeader>
                <CardTitle>Audit Logs</CardTitle>
                <CardDescription>
                  Comprehensive activity tracking for compliance and security
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex gap-4">
                    <Input 
                      placeholder="Search audit logs..." 
                      className="max-w-sm"
                      data-testid="input-search-audit"
                    />
                    <Select>
                      <SelectTrigger className="w-48" data-testid="select-event-type">
                        <SelectValue placeholder="Event type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Events</SelectItem>
                        <SelectItem value="user_action">User Actions</SelectItem>
                        <SelectItem value="system_action">System Actions</SelectItem>
                        <SelectItem value="data_change">Data Changes</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Event</TableHead>
                        <TableHead>User</TableHead>
                        <TableHead>Timestamp</TableHead>
                        <TableHead>Risk Level</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {mockAuditLogs.map((log) => (
                        <TableRow key={log.id} data-testid={`audit-log-${log.id}`}>
                          <TableCell>
                            <div>
                              <p className="font-medium">{log.action}</p>
                              <p className="text-sm text-muted-foreground">{log.description}</p>
                            </div>
                          </TableCell>
                          <TableCell>{log.userEmail}</TableCell>
                          <TableCell>
                            {new Date(log.timestamp).toLocaleString()}
                          </TableCell>
                          <TableCell>
                            <Badge 
                              variant={
                                log.riskLevel === 'high' ? 'destructive' :
                                log.riskLevel === 'medium' ? 'secondary' : 'outline'
                              }
                            >
                              {log.riskLevel}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <Button variant="outline" size="sm" data-testid={`button-view-log-${log.id}`}>
                              View Details
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card data-testid="card-user-growth">
                <CardHeader>
                  <CardTitle>User Growth</CardTitle>
                  <CardDescription>
                    Track user registration and activity trends
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span>This Month</span>
                      <span className="font-medium">+127 users</span>
                    </div>
                    <Progress value={75} className="h-2" />
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <TrendingUp className="w-4 h-4 text-green-600" />
                      <span>15% increase from last month</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card data-testid="card-department-analytics">
                <CardHeader>
                  <CardTitle>Department Analytics</CardTitle>
                  <CardDescription>
                    Usage and engagement by department
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {mockDepartments.slice(0, 3).map((dept) => (
                      <div key={dept.id} className="flex items-center justify-between">
                        <span className="text-sm">{dept.name}</span>
                        <div className="flex items-center gap-2">
                          <div className="w-16 bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                            <div 
                              className="bg-green-600 h-2 rounded-full"
                              style={{ width: `${(dept.userCount! / mockOrgStats.totalUsers) * 100}%` }}
                            />
                          </div>
                          <span className="text-sm text-muted-foreground w-8">
                            {dept.userCount}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}