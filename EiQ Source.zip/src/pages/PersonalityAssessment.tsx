import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Users, 
  Brain, 
  Heart, 
  Lightbulb, 
  Target,
  BarChart3,
  Palette,
  Shield,
  Star,
  TrendingUp,
  CheckCircle,
  PlayCircle,
  Award,
  Clock
} from "lucide-react";
import { useQuery } from "@tanstack/react-query";

export default function PersonalityAssessment() {
  const [selectedAssessment, setSelectedAssessment] = useState("myers-briggs");

  // Real backend data integration
  const { data: personalityData } = useQuery({
    queryKey: ["/api/analytics/personality-profiles"],
    staleTime: 5 * 60 * 1000, // 5 minutes
    gcTime: 10 * 60 * 1000, // 10 minutes
  });

  const { data: cognitiveProfiles } = useQuery({
    queryKey: ["/api/analytics/cognitive-profiles"],
    staleTime: 5 * 60 * 1000, // 5 minutes
    gcTime: 10 * 60 * 1000, // 10 minutes
  });

  const personalityAssessments = [
    {
      id: "myers-briggs",
      title: "Myers-Briggs Type Indicator (MBTI)",
      description: "16 personality types based on cognitive preferences",
      icon: Users,
      color: "text-blue-500",
      bgColor: "bg-blue-500/10",
      borderColor: "border-blue-500/20",
      currentType: (personalityData as any)?.mbtiType || "INTJ",
      completion: 100,
      dimensions: [
        { name: "Extraversion vs Introversion", score: 75, preference: "Introversion" },
        { name: "Sensing vs Intuition", score: 68, preference: "Intuition" },
        { name: "Thinking vs Feeling", score: 82, preference: "Thinking" },
        { name: "Judging vs Perceiving", score: 71, preference: "Judging" }
      ],
      insights: [
        "Natural problem solver and strategic thinker",
        "Prefers working independently on complex projects",
        "Values competence and efficiency",
        "Often seen as analytical and decisive"
      ]
    },
    {
      id: "big-five",
      title: "Big Five (OCEAN) Personality Model",
      description: "Five-factor model measuring key personality dimensions",
      icon: Star,
      color: "text-green-500",
      bgColor: "bg-green-500/10",
      borderColor: "border-green-500/20",
      completion: 100,
      dimensions: [
        { name: "Openness to Experience", score: 85, percentile: 89 },
        { name: "Conscientiousness", score: 78, percentile: 82 },
        { name: "Extraversion", score: 42, percentile: 38 },
        { name: "Agreeableness", score: 67, percentile: 71 },
        { name: "Neuroticism", score: 35, percentile: 31 }
      ]
    },
    {
      id: "disc",
      title: "DISC Behavioral Assessment",
      description: "Workplace behavior and communication style analysis",
      icon: Target,
      color: "text-purple-500",
      bgColor: "bg-purple-500/10",
      borderColor: "border-purple-500/20",
      primaryStyle: (personalityData as any)?.discPrimary || "Conscientious",
      completion: 95,
      styles: [
        { name: "Dominance", score: 25, description: "Direct, decisive, problem-solver" },
        { name: "Influence", score: 45, description: "Enthusiastic, optimistic, people-oriented" },
        { name: "Steadiness", score: 60, description: "Patient, reliable, team-player" },
        { name: "Conscientiousness", score: 85, description: "Accurate, analytical, detail-oriented" }
      ]
    },
    {
      id: "emotional-intelligence",
      title: "Emotional Intelligence (EQ) Assessment", 
      description: "Emotional awareness and regulation capabilities",
      icon: Heart,
      color: "text-red-500",
      bgColor: "bg-red-500/10",
      borderColor: "border-red-500/20",
      overallEQ: (cognitiveProfiles as any)?.emotionalIQ || 118,
      completion: 88,
      domains: [
        { name: "Self-Awareness", score: 82, level: "High" },
        { name: "Self-Regulation", score: 75, level: "Moderate-High" },
        { name: "Motivation", score: 91, level: "Very High" },
        { name: "Empathy", score: 68, level: "Moderate" },
        { name: "Social Skills", score: 73, level: "Moderate-High" }
      ]
    },
    {
      id: "dsm-screening",
      title: "DSM-5 Cognitive Screening",
      description: "Cognitive evaluation framework for learning optimization",
      icon: Brain,
      color: "text-orange-500",
      bgColor: "bg-orange-500/10",
      borderColor: "border-orange-500/20",
      riskLevel: "Low",
      completion: 92,
      domains: [
        { name: "Attention & Focus", score: 88, status: "Excellent" },
        { name: "Working Memory", score: 84, status: "Good" },
        { name: "Processing Speed", score: 91, status: "Excellent" },
        { name: "Executive Function", score: 87, status: "Good" },
        { name: "Learning Flexibility", score: 89, status: "Excellent" }
      ],
      recommendations: [
        "Strengths in sustained attention and processing speed",
        "Continue current learning strategies",
        "Consider advanced cognitive challenges",
        "Monitor stress levels during high-demand periods"
      ]
    }
  ];

  const selectedAssessmentData = personalityAssessments.find(
    assessment => assessment.id === selectedAssessment
  ) || personalityAssessments[0];

  const careerMatches = [
    { career: "Software Engineer", match: 94, reason: "Analytical thinking + Problem solving" },
    { career: "Research Scientist", match: 89, reason: "Systematic approach + Innovation" },
    { career: "Data Analyst", match: 87, reason: "Detail-oriented + Pattern recognition" },
    { career: "Strategic Consultant", match: 82, reason: "Strategic thinking + Independence" }
  ];

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Personality & Cognitive Assessment</h1>
          <p className="text-muted-foreground mt-2">
            Comprehensive personality profiling with Myers Briggs, DISC, OCEAN, EQ, and DSM-5 frameworks
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="secondary" className="px-3 py-1">
            Multi-Framework
          </Badge>
          <Badge variant="outline" className="px-3 py-1">
            Clinical Grade
          </Badge>
        </div>
      </div>

      {/* Assessment Selection */}
      <Tabs value={selectedAssessment} onValueChange={setSelectedAssessment} className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          {personalityAssessments.map((assessment) => (
            <TabsTrigger key={assessment.id} value={assessment.id} className="flex flex-col items-center gap-1 py-3">
              <assessment.icon className="h-4 w-4" />
              <span className="text-xs text-center">{assessment.title.split(' ')[0]}</span>
            </TabsTrigger>
          ))}
        </TabsList>

        {personalityAssessments.map((assessment) => (
          <TabsContent key={assessment.id} value={assessment.id} className="space-y-6">
            {/* Assessment Overview */}
            <Card className={`border-2 ${assessment.borderColor}`}>
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className={`p-3 rounded-lg ${assessment.bgColor}`}>
                    <assessment.icon className={`h-8 w-8 ${assessment.color}`} />
                  </div>
                  <div className="flex-1">
                    <CardTitle className="text-xl">{assessment.title}</CardTitle>
                    <CardDescription>{assessment.description}</CardDescription>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-muted-foreground">Completion</p>
                    <p className="text-2xl font-bold text-green-600">{assessment.completion}%</p>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* MBTI Specific Content */}
                {assessment.id === "myers-briggs" && (
                  <div className="space-y-6">
                    <div className="text-center p-6 bg-muted/30 rounded-lg">
                      <h3 className="text-2xl font-bold mb-2">Personality Type: {assessment.currentType}</h3>
                      <p className="text-muted-foreground">The Architect - Strategic and Independent Thinker</p>
                    </div>

                    <div className="space-y-4">
                      <h3 className="font-semibold">Cognitive Dimensions</h3>
                      {assessment.dimensions?.map((dimension) => (
                        <div key={dimension.name} className="space-y-2">
                          <div className="flex justify-between items-center">
                            <span className="text-sm font-medium">{dimension.name}</span>
                            <span className="text-sm text-muted-foreground">{(dimension as any).preference}</span>
                          </div>
                          <Progress value={dimension.score} className="h-2" />
                        </div>
                      ))}
                    </div>

                    <div className="space-y-3">
                      <h3 className="font-semibold">Key Insights</h3>
                      {assessment.insights?.map((insight, index) => (
                        <div key={index} className="flex items-center gap-2 text-sm">
                          <CheckCircle className="h-4 w-4 text-green-500 flex-shrink-0" />
                          <span>{insight}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Big Five Specific Content */}
                {assessment.id === "big-five" && (
                  <div className="space-y-4">
                    <h3 className="font-semibold">OCEAN Dimensions</h3>
                    {assessment.dimensions?.map((dimension) => (
                      <div key={dimension.name} className="space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="text-sm font-medium">{dimension.name}</span>
                          <span className="text-sm text-muted-foreground">{(dimension as any).percentile}th percentile</span>
                        </div>
                        <Progress value={dimension.score} className="h-2" />
                      </div>
                    ))}
                  </div>
                )}

                {/* DISC Specific Content */}
                {assessment.id === "disc" && (
                  <div className="space-y-6">
                    <div className="text-center p-4 bg-muted/30 rounded-lg">
                      <h3 className="text-xl font-bold mb-2">Primary Style: {assessment.primaryStyle}</h3>
                      <p className="text-muted-foreground">Accurate, analytical, detail-oriented</p>
                    </div>

                    <div className="space-y-4">
                      <h3 className="font-semibold">DISC Profile</h3>
                      {assessment.styles?.map((style) => (
                        <div key={style.name} className="space-y-2">
                          <div className="flex justify-between items-center">
                            <span className="text-sm font-medium">{style.name}</span>
                            <span className="text-sm text-muted-foreground">{style.score}%</span>
                          </div>
                          <Progress value={style.score} className="h-2" />
                          <p className="text-xs text-muted-foreground">{style.description}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* EQ Specific Content */}
                {assessment.id === "emotional-intelligence" && (
                  <div className="space-y-6">
                    <div className="text-center p-4 bg-muted/30 rounded-lg">
                      <h3 className="text-xl font-bold mb-2">EQ Score: {assessment.overallEQ}</h3>
                      <p className="text-muted-foreground">Above Average Emotional Intelligence</p>
                    </div>

                    <div className="space-y-4">
                      <h3 className="font-semibold">EQ Domains</h3>
                      {assessment.domains?.map((domain) => (
                        <div key={domain.name} className="space-y-2">
                          <div className="flex justify-between items-center">
                            <span className="text-sm font-medium">{domain.name}</span>
                            <Badge variant="outline">{(domain as any).level}</Badge>
                          </div>
                          <Progress value={domain.score} className="h-2" />
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* DSM Specific Content */}
                {assessment.id === "dsm-screening" && (
                  <div className="space-y-6">
                    <div className="text-center p-4 bg-green-50 dark:bg-green-950/20 rounded-lg">
                      <h3 className="text-xl font-bold mb-2 text-green-600">Risk Level: {assessment.riskLevel}</h3>
                      <p className="text-muted-foreground">Cognitive profile supports optimal learning</p>
                    </div>

                    <div className="space-y-4">
                      <h3 className="font-semibold">Cognitive Domains</h3>
                      {assessment.domains?.map((domain) => (
                        <div key={domain.name} className="space-y-2">
                          <div className="flex justify-between items-center">
                            <span className="text-sm font-medium">{domain.name}</span>
                            <Badge variant={(domain as any).status === 'Excellent' ? 'default' : 'secondary'}>
                              {(domain as any).status}
                            </Badge>
                          </div>
                          <Progress value={domain.score} className="h-2" />
                        </div>
                      ))}
                    </div>

                    <div className="space-y-3">
                      <h3 className="font-semibold">Recommendations</h3>
                      {assessment.recommendations?.map((rec, index) => (
                        <div key={index} className="flex items-center gap-2 text-sm">
                          <Lightbulb className="h-4 w-4 text-yellow-500 flex-shrink-0" />
                          <span>{rec}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Action Buttons */}
            <div className="flex gap-4">
              <Button size="lg" className="flex items-center gap-2">
                <PlayCircle className="h-5 w-5" />
                {assessment.completion === 100 ? 'Retake Assessment' : 'Continue Assessment'}
              </Button>
              <Button variant="outline" size="lg" className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5" />
                Detailed Report
              </Button>
              <Button variant="outline" size="lg" className="flex items-center gap-2">
                <Target className="h-5 w-5" />
                Career Match
              </Button>
            </div>
          </TabsContent>
        ))}
      </Tabs>

      {/* Career Matches */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Award className="h-5 w-5 text-purple-500" />
            Career Compatibility Analysis
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {careerMatches.map((career, index) => (
            <div key={index} className="flex items-center justify-between p-4 bg-muted/30 rounded-lg">
              <div>
                <h4 className="font-medium">{career.career}</h4>
                <p className="text-sm text-muted-foreground">{career.reason}</p>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-2xl font-bold text-green-600">{career.match}%</span>
                <Badge variant="default">Match</Badge>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}