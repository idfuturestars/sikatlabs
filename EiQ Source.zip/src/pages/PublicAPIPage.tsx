import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Copy, Play, Code, Zap, Brain, Database } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function PublicAPIPage() {
  const [apiKey, setApiKey] = useState("");
  const [response, setResponse] = useState("");
  const { toast } = useToast();

  const endpoints = [
    {
      method: "GET",
      path: "/api/auth/demo-token",
      description: "Get a demo authentication token",
      example: `curl -X GET "https://eiqscore.replit.app/api/auth/demo-token"`
    },
    {
      method: "POST",
      path: "/api/assessment/start",
      description: "Start a new assessment session",
      example: `curl -X POST "https://eiqscore.replit.app/api/assessment/start" \\
  -H "Authorization: Bearer YOUR_TOKEN" \\
  -H "Content-Type: application/json" \\
  -d '{"type": "adaptive", "difficulty": "medium"}'`
    },
    {
      method: "GET",
      path: "/api/eiq/score",
      description: "Get user's EiQ score and analytics",
      example: `curl -X GET "https://eiqscore.replit.app/api/eiq/score" \\
  -H "Authorization: Bearer YOUR_TOKEN"`
    },
    {
      method: "POST",
      path: "/api/ai/question",
      description: "Generate AI-powered assessment questions",
      example: `curl -X POST "https://eiqscore.replit.app/api/ai/question" \\
  -H "Authorization: Bearer YOUR_TOKEN" \\
  -H "Content-Type: application/json" \\
  -d '{"topic": "logical_reasoning", "difficulty": 7}'`
    }
  ];

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied!",
      description: "Command copied to clipboard",
    });
  };

  const handleTest = async (endpoint: any) => {
    try {
      const url = endpoint.path === "/api/auth/demo-token" 
        ? "/api/auth/demo-token" 
        : endpoint.path;
      
      const options: RequestInit = {
        method: endpoint.method,
        headers: {
          'Content-Type': 'application/json',
        }
      };

      if (apiKey && endpoint.path !== "/api/auth/demo-token") {
        options.headers = {
          ...options.headers,
          'Authorization': `Bearer ${apiKey}`
        };
      }

      const res = await fetch(url, options);
      const data = await res.json();
      setResponse(JSON.stringify(data, null, 2));
    } catch (error) {
      setResponse(`Error: ${error}`);
    }
  };

  return (
    <div className="min-h-screen bg-background p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Code className="w-8 h-8 text-primary" />
            <h1 className="text-3xl font-bold">EiQ★ Public API</h1>
          </div>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Integrate EiQ's AI-powered assessment capabilities into your applications. 
            Access our adaptive learning algorithms, scoring systems, and analytics.
          </p>
        </div>

        {/* API Key Input */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Zap className="w-5 h-5" />
              API Authentication
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex gap-4">
              <Input 
                placeholder="Enter your API key (optional for demo endpoints)"
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                className="flex-1"
              />
              <Button variant="outline">
                Get API Key
              </Button>
            </div>
            <p className="text-sm text-muted-foreground mt-2">
              Start with /api/auth/demo-token to get a demo token for testing
            </p>
          </CardContent>
        </Card>

        <Tabs defaultValue="endpoints" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="endpoints">Endpoints</TabsTrigger>
            <TabsTrigger value="examples">Examples</TabsTrigger>
            <TabsTrigger value="playground">Playground</TabsTrigger>
          </TabsList>

          <TabsContent value="endpoints" className="space-y-4">
            {endpoints.map((endpoint, index) => (
              <Card key={index}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="flex items-center gap-2">
                      <Badge variant={endpoint.method === "GET" ? "default" : "secondary"}>
                        {endpoint.method}
                      </Badge>
                      <code className="text-sm">{endpoint.path}</code>
                    </CardTitle>
                    <div className="flex gap-2">
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => handleCopy(endpoint.example)}
                      >
                        <Copy className="w-4 h-4" />
                      </Button>
                      <Button 
                        size="sm"
                        onClick={() => handleTest(endpoint)}
                      >
                        <Play className="w-4 h-4" />
                        Test
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground mb-4">{endpoint.description}</p>
                  <div className="bg-muted p-4 rounded-lg">
                    <pre className="text-sm overflow-x-auto">
                      <code>{endpoint.example}</code>
                    </pre>
                  </div>
                </CardContent>
              </Card>
            ))}
          </TabsContent>

          <TabsContent value="examples">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Brain className="w-5 h-5" />
                  Integration Examples
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <h3 className="font-medium mb-2">JavaScript/Node.js</h3>
                  <div className="bg-muted p-4 rounded-lg">
                    <pre className="text-sm overflow-x-auto">
                      <code>{`// Get demo token
const response = await fetch('/api/auth/demo-token');
const { token } = await response.json();

// Start assessment
const assessment = await fetch('/api/assessment/start', {
  method: 'POST',
  headers: {
    'Authorization': \`Bearer \${token}\`,
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    type: 'adaptive',
    difficulty: 'medium'
  })
});`}</code>
                    </pre>
                  </div>
                </div>

                <div>
                  <h3 className="font-medium mb-2">Python</h3>
                  <div className="bg-muted p-4 rounded-lg">
                    <pre className="text-sm overflow-x-auto">
                      <code>{`import requests

# Get demo token
response = requests.get('https://eiqscore.replit.app/api/auth/demo-token')
token = response.json()['token']

# Start assessment
assessment = requests.post(
    'https://eiqscore.replit.app/api/assessment/start',
    headers={
        'Authorization': f'Bearer {token}',
        'Content-Type': 'application/json'
    },
    json={
        'type': 'adaptive',
        'difficulty': 'medium'
    }
)`}</code>
                    </pre>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="playground">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Play className="w-5 h-5" />
                    API Playground
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground mb-4">
                    Test our endpoints directly from your browser. Click "Test" on any endpoint above to see live results.
                  </p>
                  <Button 
                    onClick={() => handleTest(endpoints[0])}
                    className="w-full"
                  >
                    Test Demo Token Endpoint
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Database className="w-5 h-5" />
                    Response
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="bg-muted p-4 rounded-lg min-h-[200px]">
                    <pre className="text-sm overflow-x-auto">
                      <code>
                        {response || "Click 'Test' on any endpoint to see the response here"}
                      </code>
                    </pre>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}