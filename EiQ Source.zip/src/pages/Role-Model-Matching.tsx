import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Progress } from "@/components/ui/progress";
import { 
  Crown, 
  Star, 
  Users, 
  TrendingUp,
  Brain,
  Target,
  BookOpen,
  Zap
} from "lucide-react";

export default function RoleModelMatching() {
  const matchedRoleModels = [
    {
      id: "marie-curie",
      name: "Marie Curie",
      field: "Physics & Chemistry",
      matchScore: 94,
      traits: ["Perseverance", "Scientific Curiosity", "Breakthrough Thinking"],
      description: "First woman to win a Nobel Prize, pioneered radioactivity research",
      image: "/api/placeholder/150/150",
      learningPath: "STEM Excellence"
    },
    {
      id: "leonardo-da-vinci", 
      name: "Leonardo da Vinci",
      field: "Renaissance Polymath",
      matchScore: 89,
      traits: ["Creative Problem Solving", "Multi-disciplinary Thinking", "Innovation"],
      description: "Artist, inventor, and scientist who embodied interdisciplinary excellence",
      image: "/api/placeholder/150/150", 
      learningPath: "Creative Innovation"
    },
    {
      id: "katherine-johnson",
      name: "Katherine Johnson",
      field: "Mathematics & Space Science",
      matchScore: 87,
      traits: ["Analytical Precision", "Determination", "Mathematical Genius"],
      description: "NASA mathematician whose calculations were critical to space missions",
      image: "/api/placeholder/150/150",
      learningPath: "Mathematical Sciences"
    }
  ];

  const personalityTraits = [
    { trait: "Analytical Thinking", score: 92, color: "bg-blue-500" },
    { trait: "Creative Problem Solving", score: 88, color: "bg-purple-500" },
    { trait: "Perseverance", score: 85, color: "bg-green-500" },
    { trait: "Scientific Curiosity", score: 91, color: "bg-orange-500" },
    { trait: "Leadership Potential", score: 78, color: "bg-red-500" }
  ];

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center gap-3">
        <Crown className="w-8 h-8 text-primary" />
        <div>
          <h1 className="text-2xl font-bold">Role Model Matching</h1>
          <p className="text-muted-foreground">Discover historical figures and leaders who share your traits and learning style</p>
        </div>
      </div>

      {/* Matching Overview */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="w-5 h-5" />
            Your Personality-Based Matches
          </CardTitle>
          <p className="text-muted-foreground">
            Based on your assessment results, cognitive profile, and learning preferences
          </p>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-3 text-center">
            <div className="p-4 bg-primary/10 rounded-lg">
              <div className="text-2xl font-bold text-primary">3</div>
              <div className="text-sm text-muted-foreground">Top Matches Found</div>
            </div>
            <div className="p-4 bg-green-100 rounded-lg">
              <div className="text-2xl font-bold text-green-600">90%</div>
              <div className="text-sm text-muted-foreground">Average Match Score</div>
            </div>
            <div className="p-4 bg-blue-100 rounded-lg">
              <div className="text-2xl font-bold text-blue-600">STEM</div>
              <div className="text-sm text-muted-foreground">Primary Field Affinity</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Role Model Cards */}
      <div className="grid gap-6 md:grid-cols-1 lg:grid-cols-2 xl:grid-cols-3">
        {matchedRoleModels.map((roleModel) => (
          <Card key={roleModel.id} className="relative">
            <CardHeader>
              <div className="flex items-center gap-3">
                <Avatar className="w-16 h-16">
                  <AvatarImage src={roleModel.image} />
                  <AvatarFallback className="bg-primary text-primary-foreground text-lg font-bold">
                    {roleModel.name.split(' ').map(n => n[0]).join('')}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <CardTitle className="text-lg">{roleModel.name}</CardTitle>
                  <p className="text-sm text-muted-foreground">{roleModel.field}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <Star className="w-4 h-4 text-yellow-500" />
                    <span className="text-sm font-medium">{roleModel.matchScore}% Match</span>
                  </div>
                </div>
              </div>
            </CardHeader>
            
            <CardContent className="space-y-4">
              <p className="text-sm text-muted-foreground">{roleModel.description}</p>
              
              <div>
                <h4 className="font-medium mb-2 text-sm">Shared Traits:</h4>
                <div className="flex flex-wrap gap-1">
                  {roleModel.traits.map((trait) => (
                    <Badge key={trait} variant="secondary" className="text-xs">
                      {trait}
                    </Badge>
                  ))}
                </div>
              </div>

              <div className="pt-2 space-y-2">
                <Button className="w-full" size="sm">
                  Explore Learning Path
                </Button>
                <div className="text-center">
                  <Badge variant="outline" className="text-xs">
                    {roleModel.learningPath}
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Personality Traits Analysis */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="w-5 h-5" />
            Your Personality Profile
          </CardTitle>
          <p className="text-muted-foreground">
            Key traits that drive your role model matching algorithm
          </p>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {personalityTraits.map((trait) => (
              <div key={trait.trait} className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="font-medium">{trait.trait}</span>
                  <span className="text-muted-foreground">{trait.score}%</span>
                </div>
                <div className="w-full bg-muted rounded-full h-2">
                  <div 
                    className={`h-2 rounded-full ${trait.color}`}
                    style={{ width: `${trait.score}%` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Learning Recommendations */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BookOpen className="w-5 h-5" />
            Personalized Learning Recommendations
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-3">
              <h4 className="font-medium flex items-center gap-2">
                <TrendingUp className="w-4 h-4" />
                Suggested Pathways
              </h4>
              <div className="space-y-2 text-sm">
                <div className="p-3 bg-muted/50 rounded">
                  <div className="font-medium">STEM Excellence Track</div>
                  <div className="text-muted-foreground">Following Marie Curie's scientific methodology</div>
                </div>
                <div className="p-3 bg-muted/50 rounded">
                  <div className="font-medium">Creative Innovation Path</div>
                  <div className="text-muted-foreground">Leonardo's interdisciplinary approach</div>
                </div>
                <div className="p-3 bg-muted/50 rounded">
                  <div className="font-medium">Mathematical Sciences</div>
                  <div className="text-muted-foreground">Katherine Johnson's analytical precision</div>
                </div>
              </div>
            </div>
            <div className="space-y-3">
              <h4 className="font-medium flex items-center gap-2">
                <Zap className="w-4 h-4" />
                Next Steps
              </h4>
              <div className="space-y-2 text-sm text-muted-foreground">
                <div>• Complete advanced personality assessment for deeper matches</div>
                <div>• Explore detailed biographies and learning strategies</div>
                <div>• Join role model-based study groups and mentorship</div>
                <div>• Access curated content based on your matches</div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}