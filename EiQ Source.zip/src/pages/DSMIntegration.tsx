import { useState, useCallback } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Brain, 
  Shield, 
  Heart, 
  Users, 
  Target, 
  TrendingUp,
  BarChart3,
  Award,
  Zap,
  Eye,
  Clock,
  AlertTriangle,
  CheckCircle,
  Info,
  Activity,
  Stethoscope,
  BookOpen
} from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { cn } from "@/lib/utils";
import ModernLayout from "@/components/layout/ModernLayout";
import { useLocation } from "wouter";

export default function DSMIntegration() {
  const [, setLocation] = useLocation();
  const [selectedDomain, setSelectedDomain] = useState("cognitive");

  const handleNavigation = useCallback((section: string) => {
    const routeMap: { [key: string]: string } = {
      "dashboard": "/",
      "assessment-center": "/assessment-center",
      "standardized-tests": "/standardized-tests",
      "multi-iq-scoring": "/multi-iq-scoring",
      "dsm-integration": "/dsm-integration",
      "voice-assessment": "/voice-assessment",
      "eiq-analytics": "/eiq-analytics",
      "ai-features": "/ai-features",
      "learning-paths": "/learning-paths",
      "ai-agents": "/ai-agents"
    };
    const route = routeMap[section] || "/";
    setLocation(route);
  }, [setLocation]);

  // Real backend data integration with fallback structure
  const { data: cognitiveProfile } = useQuery({
    queryKey: ["/api/assessment/dsm/cognitive-profile"],
    staleTime: 10 * 60 * 1000, // 10 minutes
    gcTime: 20 * 60 * 1000, // 20 minutes
  });

  const { data: riskAssessment } = useQuery({
    queryKey: ["/api/assessment/dsm/risk-assessment"],
    staleTime: 15 * 60 * 1000, // 15 minutes
    gcTime: 30 * 60 * 1000, // 30 minutes
  });

  // Comprehensive fallback data structure for cognitive assessment
  const cognitiveData = (cognitiveProfile as any) ?? {
    attention: { score: 85, percentile: 78 },
    memory: { score: 92, percentile: 89 },
    executive: { score: 76, percentile: 68 },
    processing: { score: 88, percentile: 82 },
    social: { score: 82, percentile: 75 },
    factors: [
      { name: "ADHD Screening", status: "Negative", severity: "none" },
      { name: "Depression Screening", status: "Mild Indicators", severity: "low" },
      { name: "Anxiety Patterns", status: "Moderate", severity: "moderate" },
      { name: "Memory Concerns", status: "None", severity: "none" },
      { name: "Executive Issues", status: "Mild", severity: "low" }
    ]
  };

  const riskData = (riskAssessment as any) ?? {
    factors: [
      {
        category: "Attention-Related",
        risk: "Low",
        color: "text-green-500",
        bgColor: "bg-green-500/10",
        factors: [
          { name: "ADHD Screening", status: "Negative", severity: "none" },
          { name: "Attention Deficits", status: "Minimal", severity: "low" }
        ]
      },
      {
        category: "Mood-Related", 
        risk: "Low-Moderate",
        color: "text-yellow-500",
        bgColor: "bg-yellow-500/10",
        factors: [
          { name: "Depression Screening", status: "Mild Indicators", severity: "low" },
          { name: "Anxiety Patterns", status: "Moderate", severity: "moderate" }
        ]
      },
      {
        category: "Cognitive",
        risk: "Low",
        color: "text-green-500", 
        bgColor: "bg-green-500/10",
        factors: [
          { name: "Memory Concerns", status: "None", severity: "none" },
          { name: "Executive Issues", status: "Mild", severity: "low" }
        ]
      }
    ]
  };

  const cognitiveAreas = [
    {
      id: "attention",
      name: "Attention & Focus",
      icon: Target,
      score: cognitiveData.attention.score,
      percentile: cognitiveData.attention.percentile,
      status: "Normal Range",
      color: "text-green-500",
      description: "Sustained attention, selective attention, and divided attention abilities",
      indicators: [
        { metric: "Sustained Attention", value: 88, status: "good" },
        { metric: "Selective Attention", value: 82, status: "good" },
        { metric: "Divided Attention", value: 85, status: "good" },
        { metric: "Attention Switching", value: 79, status: "fair" }
      ]
    },
    {
      id: "memory",
      name: "Memory Systems",
      icon: Brain,
      score: cognitiveData.memory.score,
      percentile: cognitiveData.memory.percentile,
      status: "Above Average",
      color: "text-blue-500",
      description: "Working memory, long-term memory, and episodic memory function",
      indicators: [
        { metric: "Working Memory", value: 94, status: "excellent" },
        { metric: "Long-term Memory", value: 91, status: "good" },
        { metric: "Episodic Memory", value: 89, status: "good" },
        { metric: "Semantic Memory", value: 95, status: "excellent" }
      ]
    },
    {
      id: "executive",
      name: "Executive Function",
      icon: Zap,
      score: cognitiveData.executive.score,
      percentile: cognitiveData.executive.percentile,
      status: "Low-Normal Range",
      color: "text-yellow-500",
      description: "Planning, decision-making, impulse control, and cognitive flexibility",
      indicators: [
        { metric: "Planning & Organization", value: 78, status: "fair" },
        { metric: "Impulse Control", value: 72, status: "fair" },
        { metric: "Cognitive Flexibility", value: 80, status: "good" },
        { metric: "Working Memory Update", value: 74, status: "fair" }
      ]
    },
    {
      id: "processing",
      name: "Processing Speed",
      icon: Clock,
      score: cognitiveData.processing.score,
      percentile: cognitiveData.processing.percentile,
      status: "Normal Range",
      color: "text-green-500",
      description: "Speed of cognitive processing and psychomotor function",
      indicators: [
        { metric: "Simple Reaction Time", value: 91, status: "excellent" },
        { metric: "Choice Reaction Time", value: 86, status: "good" },
        { metric: "Processing Speed", value: 88, status: "good" },
        { metric: "Psychomotor Speed", value: 85, status: "good" }
      ]
    },
    {
      id: "social",
      name: "Social Cognition",
      icon: Users,
      score: cognitiveData.social.score,
      percentile: cognitiveData.social.percentile,
      status: "Normal Range",
      color: "text-green-500",
      description: "Theory of mind, emotion recognition, and social inference",
      indicators: [
        { metric: "Theory of Mind", value: 84, status: "good" },
        { metric: "Emotion Recognition", value: 79, status: "fair" },
        { metric: "Social Inference", value: 83, status: "good" },
        { metric: "Empathy Response", value: 81, status: "good" }
      ]
    }
  ];

  const riskFactors = riskData.factors;

  const getStatusColor = (status: string) => {
    switch (status) {
      case "excellent": return "text-green-500";
      case "good": return "text-blue-500";
      case "fair": return "text-yellow-500";
      case "poor": return "text-red-500";
      default: return "text-gray-500";
    }
  };

  const getScoreInterpretation = (score: number) => {
    if (score >= 115) return { label: "Above Average", color: "text-green-500" };
    if (score >= 85) return { label: "Normal Range", color: "text-blue-500" };
    if (score >= 70) return { label: "Low-Normal Range", color: "text-yellow-500" };
    return { label: "Below Average", color: "text-red-500" };
  };

  const selectedArea = cognitiveAreas.find(area => area.id === selectedDomain);

  return (
    <ModernLayout
      activeSection="dsm-integration"
      onSectionChange={handleNavigation}
    >
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">DSM-5-TR Cognitive Assessment</h1>
            <p className="text-muted-foreground">
              Comprehensive cognitive evaluation aligned with DSM-5-TR diagnostic criteria
            </p>
          </div>
        <Badge variant="secondary" className="text-sm">
          <Stethoscope className="w-4 h-4 mr-1" />
          Clinical-Grade Assessment
        </Badge>
      </div>

      {/* Important Disclaimer */}
      <Alert>
        <Info className="h-4 w-4" />
        <AlertDescription>
          <strong>Educational Purpose Only:</strong> This assessment is designed for educational and research purposes. 
          It is not intended for clinical diagnosis. Please consult with a qualified mental health professional 
          for any clinical concerns or diagnostic needs.
        </AlertDescription>
      </Alert>

      {/* Overall Summary */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Overall Cognitive Index</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">
              {Math.round(cognitiveAreas.reduce((sum, area) => sum + area.score, 0) / cognitiveAreas.length)}
            </div>
            <p className="text-xs text-muted-foreground">Composite Score</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Risk Assessment</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-500">Low</div>
            <p className="text-xs text-muted-foreground">Overall risk profile</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Domains Assessed</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-500">{cognitiveAreas.length}</div>
            <p className="text-xs text-muted-foreground">Cognitive domains</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Assessment Completion</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">98%</div>
            <p className="text-xs text-muted-foreground">Battery completed</p>
          </CardContent>
        </Card>
      </div>

      {/* Cognitive Domains */}
      <Tabs value={selectedDomain} onValueChange={setSelectedDomain} className="w-full">
        <TabsList className="grid w-full grid-cols-5">
          {cognitiveAreas.map((area) => (
            <TabsTrigger key={area.id} value={area.id} className="flex items-center gap-1 text-xs">
              <area.icon className="w-3 h-3" />
              {area.name.split(' ')[0]}
            </TabsTrigger>
          ))}
        </TabsList>

        {cognitiveAreas.map((area) => (
          <TabsContent key={area.id} value={area.id} className="space-y-6">
            {/* Domain Overview */}
            <Card className="border-2">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="p-3 rounded-lg bg-primary/10">
                    <area.icon className={`w-8 h-8 ${area.color}`} />
                  </div>
                  <div className="flex-1">
                    <CardTitle className="text-xl">{area.name}</CardTitle>
                    <CardDescription>{area.description}</CardDescription>
                  </div>
                  <div className="text-right">
                    <div className={`text-3xl font-bold ${area.color}`}>
                      {area.score}
                    </div>
                    <p className="text-sm text-muted-foreground">{area.percentile}th percentile</p>
                    <Badge variant="secondary" className="mt-1">
                      {area.status}
                    </Badge>
                  </div>
                </div>
              </CardHeader>
            </Card>

            {/* Detailed Metrics */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="w-5 h-5" />
                  Detailed Assessment Metrics
                </CardTitle>
                <CardDescription>
                  Specific cognitive indicators and performance measures for {area.name.toLowerCase()}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {area.indicators.map((indicator, index) => (
                    <div key={index} className="space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <Activity className={`w-4 h-4 ${getStatusColor(indicator.status)}`} />
                          <div>
                            <h4 className="font-medium">{indicator.metric}</h4>
                            <p className="text-sm text-muted-foreground capitalize">
                              Status: {indicator.status}
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className={`text-lg font-bold ${getStatusColor(indicator.status)}`}>
                            {indicator.value}
                          </div>
                          <p className="text-xs text-muted-foreground">
                            {getScoreInterpretation(indicator.value).label}
                          </p>
                        </div>
                      </div>
                      <Progress value={indicator.value} className="h-2" />
                      <div className="flex justify-between text-xs text-muted-foreground">
                        <span>Score: {indicator.value}/100</span>
                        <span>Performance: {indicator.status}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        ))}
      </Tabs>

      {/* Risk Assessment */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="w-5 h-5" />
            DSM-5-TR Risk Factor Analysis
          </CardTitle>
          <CardDescription>
            Screening for potential areas of concern based on established diagnostic criteria
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {riskFactors.map((category: any, index: number) => (
              <Card key={index} className="border">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">{category.category}</CardTitle>
                    <Badge className={`${category.bgColor} ${category.color}`}>
                      {category.risk} Risk
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {category.factors.map((factor: any, factorIndex: number) => (
                      <div key={factorIndex} className="flex items-center justify-between">
                        <span className="text-sm font-medium">{factor.name}</span>
                        <div className="flex items-center gap-2">
                          {factor.severity === "none" && <CheckCircle className="w-4 h-4 text-green-500" />}
                          {factor.severity === "low" && <Info className="w-4 h-4 text-blue-500" />}
                          {factor.severity === "moderate" && <AlertTriangle className="w-4 h-4 text-yellow-500" />}
                          {factor.severity === "high" && <AlertTriangle className="w-4 h-4 text-red-500" />}
                          <span className="text-xs text-muted-foreground">{factor.status}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Clinical Recommendations */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BookOpen className="w-5 h-5" />
            Educational Recommendations
          </CardTitle>
          <CardDescription>
            Suggested educational strategies and potential areas for professional consultation
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h4 className="font-medium text-green-500">Cognitive Strengths to Leverage</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li className="flex items-start gap-2">
                  <CheckCircle className="w-4 h-4 text-green-500 mt-0.5" />
                  <span>Strong memory systems support complex learning tasks</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="w-4 h-4 text-green-500 mt-0.5" />
                  <span>Good processing speed facilitates efficient information handling</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="w-4 h-4 text-green-500 mt-0.5" />
                  <span>Adequate social cognition supports collaborative learning</span>
                </li>
              </ul>
            </div>
            
            <div className="space-y-4">
              <h4 className="font-medium text-blue-500">Areas for Development</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li className="flex items-start gap-2">
                  <Info className="w-4 h-4 text-blue-500 mt-0.5" />
                  <span>Executive function training may improve planning and organization</span>
                </li>
                <li className="flex items-start gap-2">
                  <Info className="w-4 h-4 text-blue-500 mt-0.5" />
                  <span>Attention switching exercises could enhance cognitive flexibility</span>
                </li>
                <li className="flex items-start gap-2">
                  <Info className="w-4 h-4 text-blue-500 mt-0.5" />
                  <span>Emotion recognition practice may strengthen social skills</span>
                </li>
              </ul>
            </div>
          </div>

          <div className="mt-6 p-4 bg-muted rounded-lg">
            <h4 className="font-medium text-yellow-600 mb-2">Consider Professional Consultation If:</h4>
            <ul className="space-y-1 text-sm text-muted-foreground">
              <li>• Cognitive concerns significantly impact daily functioning or academic performance</li>
              <li>• Multiple risk factors are present across different domains</li>
              <li>• Symptoms have persisted for several months despite interventions</li>
              <li>• There are concerns about mood, anxiety, or behavioral regulation</li>
            </ul>
          </div>
        </CardContent>
      </Card>
      </div>
    </ModernLayout>
  );
}