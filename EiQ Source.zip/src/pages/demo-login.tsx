import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import EiQLogo from "@/components/common/EiQLogo";
import { useToast } from "@/hooks/use-toast";

export default function DemoLogin() {
  const [, setLocation] = useLocation();
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleDemoLogin = async () => {
    setIsLoading(true);
    try {
      // Call the demo authentication endpoint
      const response = await fetch('/api/auth/demo-token', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      const data = await response.json();
      
      if (data.success && data.data.token) {
        // Store the JWT token
        localStorage.setItem('auth_token', data.data.token);
        // Redirect to home/dashboard
        window.location.href = '/';
      } else {
        console.error('Demo login failed:', data.message);
        // Fall back to simple redirect for now
        window.location.href = '/';
      }
    } catch (error) {
      console.error("Demo login error:", error);
      // Fall back to simple redirect for now
      window.location.href = '/';
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-100 dark:from-gray-900 dark:to-green-900 flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center space-y-4">
          <EiQLogo size="lg" variant="full" />
          <CardTitle className="text-2xl font-bold">
            Sign In to EiQ™
          </CardTitle>
          <p className="text-sm text-muted-foreground">
            Choose your preferred sign-in method
          </p>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            <Button
              onClick={() => window.location.href = '/api/auth/google'}
              className="w-full"
              variant="default"
              disabled={isLoading}
            >
              {isLoading ? "Connecting..." : "Continue with Google"}
            </Button>
            
            <Button
              onClick={() => window.location.href = '/api/auth/apple'}
              className="w-full"
              variant="outline"
              disabled={isLoading}
            >
              {isLoading ? "Connecting..." : "Continue with Apple"}
            </Button>
            
            <Button
              onClick={() => window.location.href = '/api/auth/github'}
              className="w-full"
              variant="outline"
              disabled={isLoading}
            >
              {isLoading ? "Connecting..." : "Continue with GitHub"}
            </Button>
            
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <span className="w-full border-t" />
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-background px-2 text-muted-foreground">Or</span>
              </div>
            </div>
            
            <Button 
              onClick={handleDemoLogin}
              className="w-full"
              variant="secondary"
              disabled={isLoading}
            >
              {isLoading ? "Connecting..." : "Try Demo Account"}
            </Button>
          </div>
          
          <div className="text-center">
            <p className="text-xs text-muted-foreground">
              By signing in, you agree to our terms of service and privacy policy.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}