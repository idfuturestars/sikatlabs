import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Timer, Brain, Trophy, Target, ChevronRight, Calculator, Zap, BookOpen } from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';

interface MathAbility {
  theta: number;
  standardError: number;
  problemsSolved: number;
  lastUpdated: string;
}

interface MathProblem {
  id: string;
  question: string;
  options: string[];
  domain: string;
  difficulty: string;
  irtDifficulty: string;
  explanation?: string;
  correctAnswer: number;
}

interface MathTestSession {
  id: string;
  sessionType: string;
  timeLimit: number;
  problemCount: number;
  status: string;
  score?: number;
  completedAt?: string;
}

interface LeaderboardEntry {
  userId: string;
  username: string;
  score: number;
  rank: number;
  questionsCorrect: number;
  totalQuestions: number;
  averageTime: number;
  percentile: number;
}

export default function MathTesting() {
  const [activeMode, setActiveMode] = useState<'dashboard' | 'speed' | 'gauss' | 'adaptive'>('dashboard');
  const [selectedDomain, setSelectedDomain] = useState<string>('all');
  const queryClient = useQueryClient();

  // Fetch user's math ability
  const { data: mathAbility } = useQuery({
    queryKey: ['/api/math/ability'],
    queryFn: () => apiRequest('GET', '/api/math/ability'),
    retry: false
  });

  // Fetch active session
  const { data: activeSession } = useQuery({
    queryKey: ['/api/math/sessions/active'],
    queryFn: () => apiRequest('GET', '/api/math/sessions/active'),
    retry: false
  });

  // Fetch leaderboard
  const { data: leaderboard } = useQuery({
    queryKey: ['/api/math/leaderboard'],
    queryFn: () => apiRequest('GET', '/api/math/leaderboard'),
    retry: false
  });

  // Start speed round mutation
  const startSpeedRound = useMutation({
    mutationFn: (data: { difficulty: string; timeLimit: number }) =>
      apiRequest('POST', '/api/math/contest/speed-round', data),
    onSuccess: (data) => {
      setActiveMode('speed');
      queryClient.invalidateQueries({ queryKey: ['/api/math/sessions/active'] });
    }
  });

  // Start Gauss challenge mutation
  const startGaussChallenge = useMutation({
    mutationFn: () =>
      apiRequest('POST', '/api/math/contest/gauss-challenge', {}),
    onSuccess: (data) => {
      setActiveMode('gauss');
      queryClient.invalidateQueries({ queryKey: ['/api/math/sessions/active'] });
    }
  });

  const getAbilityLevel = (theta: number): string => {
    if (theta < -1) return 'Beginner';
    if (theta < 0) return 'Intermediate';
    if (theta < 1) return 'Advanced';
    return 'Expert';
  };

  const getAbilityColor = (theta: number): string => {
    if (theta < -1) return 'bg-red-500';
    if (theta < 0) return 'bg-yellow-500';
    if (theta < 1) return 'bg-blue-500';
    return 'bg-green-500';
  };

  if (activeMode === 'speed' || activeMode === 'gauss') {
    return <MathTestingInterface mode={activeMode} onExit={() => setActiveMode('dashboard')} />;
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="text-center space-y-2">
        <h1 className="text-4xl font-bold bg-gradient-to-r from-green-400 to-blue-500 bg-clip-text text-transparent">
          Gauss Math Testing System
        </h1>
        <p className="text-gray-600 dark:text-gray-300">
          World-class adaptive mathematics assessment with IRT-based difficulty adjustment
        </p>
      </div>

      {/* Active Session Alert */}
      {activeSession && (
        <Card className="border-orange-200 bg-orange-50 dark:bg-orange-950/20">
          <CardHeader>
            <CardTitle className="text-orange-800 dark:text-orange-200 flex items-center gap-2">
              <Timer className="h-5 w-5" />
              Active Session Detected
            </CardTitle>
            <CardDescription>
              You have an ongoing {activeSession.sessionType.replace('_', ' ')} session.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button 
              onClick={() => setActiveMode(activeSession.sessionType.includes('gauss') ? 'gauss' : 'speed')}
              className="bg-orange-600 hover:bg-orange-700"
            >
              Continue Session
            </Button>
          </CardContent>
        </Card>
      )}

      {/* User Math Ability Stats */}
      {mathAbility && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Brain className="h-5 w-5" />
              Your Math Ability Profile
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold">{getAbilityLevel(mathAbility.theta)}</div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Current Level</div>
                <div className={`w-full h-2 rounded-full mt-2 ${getAbilityColor(mathAbility.theta)}`}></div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold">{mathAbility.theta.toFixed(2)}</div>
                <div className="text-sm text-gray-600 dark:text-gray-400">IRT Theta Score</div>
                <div className="text-xs text-gray-500 mt-1">Range: -3.0 to +3.0</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold">{mathAbility.problemsSolved || 0}</div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Problems Solved</div>
                <div className="text-xs text-gray-500 mt-1">Standard Error: ±{mathAbility.standardError.toFixed(2)}</div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Challenge Modes */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Speed Round */}
        <Card className="cursor-pointer hover:shadow-lg transition-shadow border-blue-200 hover:border-blue-300">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-blue-700 dark:text-blue-300">
              <Zap className="h-5 w-5" />
              Speed Round
            </CardTitle>
            <CardDescription>
              Fast-paced 5-minute challenges with instant scoring
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Time Limit:</span>
                <span>5 minutes</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>Questions:</span>
                <span>10-15 problems</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>Scoring:</span>
                <span>Speed × Accuracy</span>
              </div>
            </div>
            <Button 
              className="w-full bg-blue-600 hover:bg-blue-700"
              onClick={() => startSpeedRound.mutate({ difficulty: 'medium', timeLimit: 300 })}
              disabled={startSpeedRound.isPending}
            >
              {startSpeedRound.isPending ? 'Starting...' : 'Start Speed Round'}
            </Button>
          </CardContent>
        </Card>

        {/* Gauss Challenge */}
        <Card className="cursor-pointer hover:shadow-lg transition-shadow border-green-200 hover:border-green-300">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-green-700 dark:text-green-300">
              <Calculator className="h-5 w-5" />
              Gauss Challenge
            </CardTitle>
            <CardDescription>
              Adaptive difficulty with IRT-based problem selection
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Time Limit:</span>
                <span>60 minutes</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>Questions:</span>
                <span>Adaptive (10-20)</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>Difficulty:</span>
                <span>IRT Adaptive</span>
              </div>
            </div>
            <Button 
              className="w-full bg-green-600 hover:bg-green-700"
              onClick={() => startGaussChallenge.mutate()}
              disabled={startGaussChallenge.isPending}
            >
              {startGaussChallenge.isPending ? 'Starting...' : 'Start Gauss Challenge'}
            </Button>
          </CardContent>
        </Card>

        {/* Practice Mode */}
        <Card className="cursor-pointer hover:shadow-lg transition-shadow border-purple-200 hover:border-purple-300">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-purple-700 dark:text-purple-300">
              <BookOpen className="h-5 w-5" />
              Practice Mode
            </CardTitle>
            <CardDescription>
              Untimed practice with hints and detailed explanations
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Time Limit:</span>
                <span>None</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>Hints:</span>
                <span>AI-powered</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>Explanations:</span>
                <span>Detailed</span>
              </div>
            </div>
            <Button 
              className="w-full bg-purple-600 hover:bg-purple-700"
              onClick={() => setActiveMode('adaptive')}
            >
              Start Practice
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Leaderboard */}
      {leaderboard && leaderboard.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Trophy className="h-5 w-5" />
              Weekly Leaderboard
            </CardTitle>
            <CardDescription>
              Top performers this week
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {leaderboard.map((entry: LeaderboardEntry, index: number) => (
                <div
                  key={entry.userId}
                  className="flex items-center justify-between p-3 rounded-lg border"
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white font-bold ${
                      index === 0 ? 'bg-yellow-500' : 
                      index === 1 ? 'bg-gray-400' : 
                      index === 2 ? 'bg-orange-600' : 'bg-gray-600'
                    }`}>
                      {entry.rank}
                    </div>
                    <div>
                      <div className="font-semibold">{entry.username || `User ${entry.userId.slice(-4)}`}</div>
                      <div className="text-sm text-gray-600 dark:text-gray-400">
                        {entry.questionsCorrect}/{entry.totalQuestions} correct
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold">{entry.score} pts</div>
                    <div className="text-sm text-gray-600 dark:text-gray-400">
                      {entry.averageTime}s avg
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Math Domains Overview */}
      <Card>
        <CardHeader>
          <CardTitle>Available Math Domains</CardTitle>
          <CardDescription>
            Practice specific mathematical areas to improve your skills
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { name: 'Algebra', icon: '𝑥', description: 'Linear & quadratic equations' },
              { name: 'Geometry', icon: '△', description: 'Shapes, angles, proofs' },
              { name: 'Calculus', icon: '∫', description: 'Derivatives & integrals' },
              { name: 'Statistics', icon: '📊', description: 'Data analysis & probability' },
              { name: 'Number Theory', icon: '🔢', description: 'Prime numbers & divisibility' },
              { name: 'Combinatorics', icon: '🔀', description: 'Counting & arrangements' },
              { name: 'Logic', icon: '⊢', description: 'Mathematical reasoning' },
              { name: 'Applied Math', icon: '🧮', description: 'Real-world problems' }
            ].map((domain) => (
              <Card 
                key={domain.name} 
                className="cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
                onClick={() => {
                  setSelectedDomain(domain.name.toLowerCase());
                  setActiveMode('adaptive');
                }}
              >
                <CardContent className="p-4 text-center">
                  <div className="text-2xl mb-2">{domain.icon}</div>
                  <div className="font-semibold">{domain.name}</div>
                  <div className="text-xs text-gray-600 dark:text-gray-400 mt-1">
                    {domain.description}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// Math Testing Interface Component
function MathTestingInterface({ mode, onExit }: { mode: string; onExit: () => void }) {
  const [currentProblem, setCurrentProblem] = useState(0);
  const [answers, setAnswers] = useState<Record<number, number>>({});
  const [timeLeft, setTimeLeft] = useState(0);
  const [session, setSession] = useState<MathTestSession | null>(null);
  const [problems, setProblems] = useState<MathProblem[]>([]);
  const [showHint, setShowHint] = useState(false);
  const [hint, setHint] = useState('');
  const [attemptsCount, setAttemptsCount] = useState(0);

  // Timer effect
  useEffect(() => {
    if (timeLeft > 0) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
      return () => clearTimeout(timer);
    } else if (timeLeft === 0 && session && session.status === 'active') {
      handleCompleteSession();
    }
  }, [timeLeft]);

  // Fetch session and problems when component loads
  useEffect(() => {
    fetchActiveSession();
  }, []);

  const fetchActiveSession = async () => {
    try {
      const activeSession = await fetch('/api/math/sessions/active').then(res => res.json());
      if (activeSession) {
        setSession(activeSession);
        setTimeLeft(Math.max(0, activeSession.timeLimit - Math.floor((Date.now() - new Date(activeSession.createdAt).getTime()) / 1000)));
        
        // Fetch problems based on session type
        if (mode === 'gauss') {
          const adaptiveProblems = await fetch('/api/math/problems/adaptive').then(res => res.json());
          setProblems(adaptiveProblems.problems || []);
        } else {
          const speedProblems = await fetch('/api/math/problems?difficulty=medium&limit=10').then(res => res.json());
          setProblems(speedProblems || []);
        }
      }
    } catch (error) {
      console.error('Error fetching session:', error);
    }
  };

  const handleAnswerSelect = (answerIndex: number) => {
    setAnswers({ ...answers, [currentProblem]: answerIndex });
    setAttemptsCount(attemptsCount + 1);
  };

  const handleNextProblem = async () => {
    // Submit current answer
    if (answers[currentProblem] !== undefined && session && problems[currentProblem]) {
      const problem = problems[currentProblem];
      const isCorrect = answers[currentProblem] === problem.correctAnswer;
      
      try {
        await fetch('/api/math/responses', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            sessionId: session.id,
            problemId: problem.id,
            userAnswer: answers[currentProblem].toString(),
            isCorrect,
            responseTime: Math.floor(Math.random() * 30) + 10, // Simulated response time
            questionOrder: currentProblem + 1
          })
        });
      } catch (error) {
        console.error('Error submitting answer:', error);
      }
    }

    if (currentProblem < problems.length - 1) {
      setCurrentProblem(currentProblem + 1);
      setShowHint(false);
      setHint('');
      setAttemptsCount(0);
    } else {
      handleCompleteSession();
    }
  };

  const handleGetHint = async () => {
    if (problems[currentProblem]) {
      try {
        const hintResponse = await fetch(`/api/math/hints/${problems[currentProblem].id}`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            userAnswer: answers[currentProblem]?.toString() || '',
            attemptsCount
          })
        }).then(res => res.json());
        setHint(hintResponse.hint);
        setShowHint(true);
      } catch (error) {
        console.error('Error getting hint:', error);
        setHint('Think about the fundamental concepts involved in this problem.');
        setShowHint(true);
      }
    }
  };

  const handleCompleteSession = async () => {
    if (session) {
      try {
        const correctAnswers = Object.entries(answers).filter(([index, answer]) => {
          const problemIndex = parseInt(index);
          return problems[problemIndex] && answer === problems[problemIndex].correctAnswer;
        }).length;

        const results = {
          score: Math.round((correctAnswers / problems.length) * 100),
          correctAnswers,
          totalQuestions: problems.length,
          timeUsed: session.timeLimit - timeLeft,
          accuracy: correctAnswers / problems.length
        };

        await fetch(`/api/math/sessions/${session.id}/complete`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ results })
        });

        // Show results and return to dashboard
        alert(`Session Complete!\nScore: ${results.score}%\nCorrect: ${correctAnswers}/${problems.length}`);
        onExit();
      } catch (error) {
        console.error('Error completing session:', error);
        onExit();
      }
    }
  };

  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  if (!session || !problems.length) {
    return (
      <div className="container mx-auto p-6 text-center">
        <div className="text-xl">Loading math problems...</div>
      </div>
    );
  }

  const problem = problems[currentProblem];
  const progress = ((currentProblem + 1) / problems.length) * 100;

  return (
    <div className="container mx-auto p-6 max-w-4xl">
      {/* Header */}
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold capitalize">
            {mode.replace('_', ' ')} Mode
          </h1>
          <p className="text-gray-600 dark:text-gray-400">
            Question {currentProblem + 1} of {problems.length}
          </p>
        </div>
        <div className="flex items-center gap-4">
          <div className="text-right">
            <div className="text-2xl font-bold text-orange-600">
              {formatTime(timeLeft)}
            </div>
            <div className="text-sm text-gray-600 dark:text-gray-400">
              Time Remaining
            </div>
          </div>
          <Button variant="outline" onClick={onExit}>
            Exit
          </Button>
        </div>
      </div>

      {/* Progress */}
      <div className="mb-6">
        <Progress value={progress} className="h-3" />
      </div>

      {/* Problem */}
      <Card className="mb-6">
        <CardHeader>
          <div className="flex justify-between items-start">
            <div>
              <CardTitle className="text-xl">
                {problem.question}
              </CardTitle>
              <div className="flex gap-2 mt-2">
                <Badge variant="secondary">{problem.domain}</Badge>
                <Badge variant="outline">{problem.difficulty}</Badge>
              </div>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {problem.options?.map((option, index) => (
              <Button
                key={index}
                variant={answers[currentProblem] === index ? "default" : "outline"}
                className="w-full text-left justify-start p-4 h-auto"
                onClick={() => handleAnswerSelect(index)}
              >
                <span className="font-semibold mr-3">{String.fromCharCode(65 + index)}.</span>
                {option}
              </Button>
            ))}
          </div>

          {/* Hint Section */}
          {mode !== 'speed' && (
            <div className="mt-6 space-y-3">
              {!showHint ? (
                <Button 
                  variant="outline" 
                  onClick={handleGetHint}
                  className="w-full"
                >
                  Get AI Hint
                </Button>
              ) : (
                <Card className="bg-blue-50 dark:bg-blue-950/20 border-blue-200">
                  <CardContent className="p-4">
                    <div className="flex items-start gap-2">
                      <Target className="h-5 w-5 text-blue-600 mt-0.5" />
                      <div>
                        <div className="font-semibold text-blue-800 dark:text-blue-200">
                          AI Hint
                        </div>
                        <div className="text-blue-700 dark:text-blue-300 mt-1">
                          {hint}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          )}

          {/* Navigation */}
          <div className="flex justify-between mt-6">
            <Button
              variant="outline"
              onClick={() => setCurrentProblem(Math.max(0, currentProblem - 1))}
              disabled={currentProblem === 0}
            >
              Previous
            </Button>
            <Button
              onClick={handleNextProblem}
              disabled={answers[currentProblem] === undefined}
              className="flex items-center gap-2"
            >
              {currentProblem === problems.length - 1 ? 'Finish' : 'Next'}
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}