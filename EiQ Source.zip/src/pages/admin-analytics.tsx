import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { 
  Users, 
  BarChart3,
  TrendingUp,
  Activity,
  Shield,
  AlertTriangle,
  CheckCircle2,
  Globe,
  Clock,
  Target,
  Brain,
  Zap,
  Database,
  Server,
  Monitor,
  FileText,
  Settings,
  Search,
  Filter,
  Download,
  RefreshCw
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { motion } from "framer-motion";

interface SystemMetric {
  name: string;
  value: number;
  unit: string;
  trend: 'up' | 'down' | 'stable';
  status: 'healthy' | 'warning' | 'critical';
  target: number;
}

interface UserMetric {
  totalUsers: number;
  activeUsers: number;
  newUsers: number;
  retentionRate: number;
  avgSessionTime: number;
  completionRate: number;
}

interface AssessmentMetric {
  totalAssessments: number;
  avgEiqScore: number;
  completionRate: number;
  avgDuration: number;
  difficultyCurve: number;
  adaptiveAccuracy: number;
}

interface SecurityAlert {
  id: string;
  type: 'authentication' | 'authorization' | 'data' | 'system';
  severity: 'low' | 'medium' | 'high' | 'critical';
  message: string;
  timestamp: string;
  resolved: boolean;
  source: string;
}

const SYSTEM_METRICS: SystemMetric[] = [
  { name: "CPU Usage", value: 23.4, unit: "%", trend: "stable", status: "healthy", target: 80 },
  { name: "Memory Usage", value: 67.2, unit: "%", trend: "up", status: "warning", target: 85 },
  { name: "Database Connections", value: 245, unit: "", trend: "stable", status: "healthy", target: 500 },
  { name: "API Response Time", value: 247, unit: "ms", trend: "down", status: "healthy", target: 500 },
  { name: "Error Rate", value: 0.12, unit: "%", trend: "down", status: "healthy", target: 1 },
  { name: "Uptime", value: 99.94, unit: "%", trend: "stable", status: "healthy", target: 99.9 }
];

const USER_METRICS: UserMetric = {
  totalUsers: 15847,
  activeUsers: 2394,
  newUsers: 127,
  retentionRate: 84.2,
  avgSessionTime: 42.5,
  completionRate: 78.9
};

const ASSESSMENT_METRICS: AssessmentMetric = {
  totalAssessments: 47293,
  avgEiqScore: 642,
  completionRate: 82.1,
  avgDuration: 38.7,
  difficultyCurve: 1.34,
  adaptiveAccuracy: 91.8
};

const SECURITY_ALERTS: SecurityAlert[] = [
  {
    id: "alert_1",
    type: "authentication",
    severity: "medium",
    message: "Unusual login pattern detected from IP range 192.168.x.x",
    timestamp: "2025-08-14 10:45:23",
    resolved: false,
    source: "Auth Service"
  },
  {
    id: "alert_2", 
    type: "authorization",
    severity: "low",
    message: "Multiple failed API key attempts",
    timestamp: "2025-08-14 09:32:18",
    resolved: true,
    source: "API Gateway"
  },
  {
    id: "alert_3",
    type: "system",
    severity: "high", 
    message: "Memory usage approaching 85% threshold",
    timestamp: "2025-08-14 08:15:44",
    resolved: false,
    source: "System Monitor"
  }
];

export default function AdminAnalytics() {
  const { toast } = useToast();
  const [timeRange, setTimeRange] = useState("24h");
  const [selectedMetric, setSelectedMetric] = useState<SystemMetric | null>(null);
  const [refreshing, setRefreshing] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [filterSeverity, setFilterSeverity] = useState("all");

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'healthy': return 'text-green-600 bg-green-100 dark:bg-green-900 dark:text-green-200';
      case 'warning': return 'text-yellow-600 bg-yellow-100 dark:bg-yellow-900 dark:text-yellow-200';
      case 'critical': return 'text-red-600 bg-red-100 dark:bg-red-900 dark:text-red-200';
      default: return 'text-gray-600 bg-gray-100 dark:bg-gray-900 dark:text-gray-200';
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'low': return 'text-blue-600 bg-blue-100 dark:bg-blue-900 dark:text-blue-200';
      case 'medium': return 'text-yellow-600 bg-yellow-100 dark:bg-yellow-900 dark:text-yellow-200';
      case 'high': return 'text-orange-600 bg-orange-100 dark:bg-orange-900 dark:text-orange-200';
      case 'critical': return 'text-red-600 bg-red-100 dark:bg-red-900 dark:text-red-200';
      default: return 'text-gray-600 bg-gray-100 dark:bg-gray-900 dark:text-gray-200';
    }
  };

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case 'up': return <TrendingUp className="w-4 h-4 text-green-500" />;
      case 'down': return <TrendingUp className="w-4 h-4 text-red-500 rotate-180" />;
      default: return <Activity className="w-4 h-4 text-gray-500" />;
    }
  };

  const refreshMetrics = async () => {
    setRefreshing(true);
    toast({
      title: "Refreshing Analytics",
      description: "Updating system metrics and user data..."
    });
    
    // Simulate API call
    setTimeout(() => {
      setRefreshing(false);
      toast({
        title: "Metrics Updated",
        description: "All analytics data has been refreshed successfully."
      });
    }, 2000);
  };

  const exportData = () => {
    toast({
      title: "Export Started",
      description: "Analytics data is being prepared for download..."
    });
  };

  const filteredAlerts = SECURITY_ALERTS.filter(alert => {
    const matchesSearch = alert.message.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         alert.source.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesSeverity = filterSeverity === "all" || alert.severity === filterSeverity;
    return matchesSearch && matchesSeverity;
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-100 dark:from-slate-900 dark:to-slate-800 p-6">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-slate-900 dark:text-white flex items-center space-x-3">
              <Monitor className="w-8 h-8 text-blue-500" />
              <span>Admin Analytics Dashboard</span>
            </h1>
            <p className="text-slate-600 dark:text-slate-300 mt-2">
              Comprehensive platform monitoring, user analytics, and system health overview
            </p>
          </div>
          <div className="flex items-center space-x-2">
            <Select value={timeRange} onValueChange={setTimeRange}>
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1h">Last Hour</SelectItem>
                <SelectItem value="24h">Last 24h</SelectItem>
                <SelectItem value="7d">Last 7 days</SelectItem>
                <SelectItem value="30d">Last 30 days</SelectItem>
              </SelectContent>
            </Select>
            <Button onClick={refreshMetrics} disabled={refreshing}>
              <RefreshCw className={`w-4 h-4 mr-2 ${refreshing ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
            <Button onClick={exportData} variant="outline">
              <Download className="w-4 h-4 mr-2" />
              Export
            </Button>
          </div>
        </div>

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-6">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="users">Users</TabsTrigger>
            <TabsTrigger value="assessments">Assessments</TabsTrigger>
            <TabsTrigger value="system">System</TabsTrigger>
            <TabsTrigger value="security">Security</TabsTrigger>
            <TabsTrigger value="content">Content</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Users</CardTitle>
                  <Users className="h-4 w-4 text-blue-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{USER_METRICS.totalUsers.toLocaleString()}</div>
                  <p className="text-xs text-muted-foreground">
                    +{USER_METRICS.newUsers} new today
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Active Users</CardTitle>
                  <Activity className="h-4 w-4 text-green-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{USER_METRICS.activeUsers.toLocaleString()}</div>
                  <p className="text-xs text-muted-foreground">
                    {((USER_METRICS.activeUsers / USER_METRICS.totalUsers) * 100).toFixed(1)}% of total
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Assessments</CardTitle>
                  <Brain className="h-4 w-4 text-purple-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{ASSESSMENT_METRICS.totalAssessments.toLocaleString()}</div>
                  <p className="text-xs text-muted-foreground">
                    {ASSESSMENT_METRICS.completionRate}% completion rate
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Avg EIQ Score</CardTitle>
                  <Target className="h-4 w-4 text-orange-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{ASSESSMENT_METRICS.avgEiqScore}</div>
                  <p className="text-xs text-muted-foreground">
                    Population percentile: 73rd
                  </p>
                </CardContent>
              </Card>
            </div>

            <div className="grid gap-6 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>System Health Overview</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {SYSTEM_METRICS.slice(0, 4).map((metric) => (
                      <div key={metric.name} className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          {getTrendIcon(metric.trend)}
                          <span className="font-medium">{metric.name}</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <span className="font-bold">
                            {metric.value}{metric.unit}
                          </span>
                          <Badge className={getStatusColor(metric.status)}>
                            {metric.status}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Recent Security Alerts</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {SECURITY_ALERTS.slice(0, 3).map((alert) => (
                      <div key={alert.id} className="flex items-start space-x-3">
                        <div className="flex-shrink-0 mt-1">
                          {alert.resolved ? (
                            <CheckCircle2 className="w-4 h-4 text-green-500" />
                          ) : (
                            <AlertTriangle className="w-4 h-4 text-red-500" />
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center space-x-2">
                            <Badge className={getSeverityColor(alert.severity)}>
                              {alert.severity}
                            </Badge>
                            <span className="text-xs text-muted-foreground">
                              {alert.source}
                            </span>
                          </div>
                          <p className="text-sm mt-1">{alert.message}</p>
                          <p className="text-xs text-muted-foreground">
                            {alert.timestamp}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Users Tab */}
          <TabsContent value="users" className="space-y-6">
            <div className="grid gap-6 md:grid-cols-3">
              <Card>
                <CardHeader>
                  <CardTitle>User Engagement</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between">
                    <span>Retention Rate</span>
                    <span className="font-bold">{USER_METRICS.retentionRate}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Avg Session Time</span>
                    <span className="font-bold">{USER_METRICS.avgSessionTime} min</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Completion Rate</span>
                    <span className="font-bold">{USER_METRICS.completionRate}%</span>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>User Distribution</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-64 bg-slate-100 dark:bg-slate-800 rounded-lg flex items-center justify-center">
                    <div className="text-center">
                      <BarChart3 className="w-12 h-12 text-muted-foreground mx-auto mb-2" />
                      <p className="text-muted-foreground">Geographic user distribution chart</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Growth Metrics</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-64 bg-slate-100 dark:bg-slate-800 rounded-lg flex items-center justify-center">
                    <div className="text-center">
                      <TrendingUp className="w-12 h-12 text-muted-foreground mx-auto mb-2" />
                      <p className="text-muted-foreground">User growth trend over time</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Assessments Tab */}
          <TabsContent value="assessments" className="space-y-6">
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Assessments</CardTitle>
                  <Brain className="h-4 w-4 text-purple-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{ASSESSMENT_METRICS.totalAssessments.toLocaleString()}</div>
                  <p className="text-xs text-muted-foreground">Across all domains</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Avg Duration</CardTitle>
                  <Clock className="h-4 w-4 text-blue-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{ASSESSMENT_METRICS.avgDuration} min</div>
                  <p className="text-xs text-muted-foreground">Per assessment session</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Adaptive Accuracy</CardTitle>
                  <Target className="h-4 w-4 text-green-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{ASSESSMENT_METRICS.adaptiveAccuracy}%</div>
                  <p className="text-xs text-muted-foreground">IRT targeting precision</p>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Assessment Performance Analytics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80 bg-slate-100 dark:bg-slate-800 rounded-lg flex items-center justify-center">
                  <div className="text-center">
                    <BarChart3 className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                    <p className="text-muted-foreground mb-2">Interactive assessment analytics</p>
                    <div className="flex justify-center space-x-4">
                      <Badge variant="outline">EIQ Distribution</Badge>
                      <Badge variant="outline">Domain Performance</Badge>
                      <Badge variant="outline">Difficulty Analysis</Badge>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* System Tab */}
          <TabsContent value="system" className="space-y-6">
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {SYSTEM_METRICS.map((metric) => (
                <motion.div
                  key={metric.name}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  whileHover={{ scale: 1.02 }}
                >
                  <Card className="cursor-pointer" onClick={() => setSelectedMetric(metric)}>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">{metric.name}</CardTitle>
                      {getTrendIcon(metric.trend)}
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">
                        {metric.value}
                        <span className="text-sm font-normal text-muted-foreground ml-1">
                          {metric.unit}
                        </span>
                      </div>
                      <div className="flex items-center justify-between mt-2">
                        <Badge className={getStatusColor(metric.status)}>
                          {metric.status}
                        </Badge>
                        <span className="text-xs text-muted-foreground">
                          Target: {metric.target}{metric.unit}
                        </span>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </TabsContent>

          {/* Security Tab */}
          <TabsContent value="security" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center space-x-2">
                    <Shield className="w-5 h-5 text-green-500" />
                    <span>Security Alerts & Monitoring</span>
                  </CardTitle>
                  <div className="flex items-center space-x-2">
                    <Input
                      placeholder="Search alerts..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="w-64"
                    />
                    <Select value={filterSeverity} onValueChange={setFilterSeverity}>
                      <SelectTrigger className="w-32">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Levels</SelectItem>
                        <SelectItem value="low">Low</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                        <SelectItem value="critical">Critical</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {filteredAlerts.map((alert) => (
                    <Card key={alert.id}>
                      <CardContent className="pt-6">
                        <div className="flex items-start justify-between">
                          <div className="flex items-start space-x-3">
                            <div className="flex-shrink-0 mt-1">
                              {alert.resolved ? (
                                <CheckCircle2 className="w-5 h-5 text-green-500" />
                              ) : (
                                <AlertTriangle className="w-5 h-5 text-red-500" />
                              )}
                            </div>
                            <div className="flex-1">
                              <div className="flex items-center space-x-2 mb-2">
                                <Badge className={getSeverityColor(alert.severity)}>
                                  {alert.severity.toUpperCase()}
                                </Badge>
                                <Badge variant="outline">{alert.type}</Badge>
                                <span className="text-sm text-muted-foreground">
                                  {alert.source}
                                </span>
                              </div>
                              <p className="text-sm font-medium mb-1">{alert.message}</p>
                              <p className="text-xs text-muted-foreground">
                                {alert.timestamp}
                              </p>
                            </div>
                          </div>
                          <div className="flex space-x-2">
                            {!alert.resolved && (
                              <Button size="sm">
                                Resolve
                              </Button>
                            )}
                            <Button size="sm" variant="outline">
                              Details
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Content Tab */}
          <TabsContent value="content" className="space-y-6">
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Question Bank</CardTitle>
                  <Database className="h-4 w-4 text-blue-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">1,247</div>
                  <p className="text-xs text-muted-foreground">Calibrated questions</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Role Models</CardTitle>
                  <Users className="h-4 w-4 text-purple-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">47</div>
                  <p className="text-xs text-muted-foreground">Historical figures</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Learning Paths</CardTitle>
                  <Target className="h-4 w-4 text-green-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">156</div>
                  <p className="text-xs text-muted-foreground">Curated pathways</p>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Content Management</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span>Question Bank Utilization</span>
                    <span className="font-bold">87.3%</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Role Model Engagement</span>
                    <span className="font-bold">94.1%</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Pathway Completion Rate</span>
                    <span className="font-bold">71.8%</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}