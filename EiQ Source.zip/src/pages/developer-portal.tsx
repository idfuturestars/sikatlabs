import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Copy, Key, Code, FileText, Zap, Users, Globe } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface ApiKey {
  id: string;
  name: string;
  key: string;
  createdAt: string;
  lastUsed: string;
  requests: number;
  rateLimit: string;
  status: 'active' | 'suspended';
}

export default function DeveloperPortal() {
  const { toast } = useToast();
  const [apiKeys, setApiKeys] = useState<ApiKey[]>([
    {
      id: "1",
      name: "Production API Key",
      key: "eiq_prod_ak_1234567890abcdef",
      createdAt: "2025-08-10",
      lastUsed: "2025-08-14",
      requests: 15847,
      rateLimit: "1000/hour",
      status: "active"
    },
    {
      id: "2", 
      name: "Development API Key",
      key: "eiq_dev_ak_fedcba0987654321",
      createdAt: "2025-08-12",
      lastUsed: "2025-08-14",
      requests: 3421,
      rateLimit: "500/hour",
      status: "active"
    }
  ]);
  
  const [newKeyName, setNewKeyName] = useState("");

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied to clipboard",
      description: "API key has been copied to your clipboard."
    });
  };

  const generateNewKey = () => {
    if (!newKeyName.trim()) return;
    
    const newKey: ApiKey = {
      id: Date.now().toString(),
      name: newKeyName,
      key: `eiq_${Date.now()}_${Math.random().toString(36).substr(2, 16)}`,
      createdAt: new Date().toISOString().split('T')[0],
      lastUsed: "Never",
      requests: 0,
      rateLimit: "1000/hour",
      status: "active"
    };
    
    setApiKeys(prev => [...prev, newKey]);
    setNewKeyName("");
    toast({
      title: "API Key Generated",
      description: "Your new API key has been created successfully."
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800 p-6">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="flex items-center justify-center space-x-3">
            <div className="relative">
              <span className="text-4xl font-bold text-slate-900 dark:text-white">E</span>
              <span className="absolute top-0 left-3 text-lg text-emerald-500">✦</span>
              <span className="text-4xl font-bold text-slate-900 dark:text-white">Q™</span>
            </div>
            <span className="text-2xl text-slate-600 dark:text-slate-400">Developer Portal</span>
          </div>
          <p className="text-slate-600 dark:text-slate-300 max-w-2xl mx-auto">
            Build intelligent applications with the EIQ™ Educational Intelligence API. 
            Access cognitive assessments, learning analytics, and AI-powered insights.
          </p>
        </div>

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="api-keys">API Keys</TabsTrigger>
            <TabsTrigger value="documentation">Documentation</TabsTrigger>
            <TabsTrigger value="examples">Examples</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
          </TabsList>

          <TabsContent value="overview">
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">API Requests</CardTitle>
                  <Zap className="h-4 w-4 text-emerald-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">19,268</div>
                  <p className="text-xs text-muted-foreground">+12% from last month</p>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Active Assessments</CardTitle>
                  <Users className="h-4 w-4 text-blue-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">2,847</div>
                  <p className="text-xs text-muted-foreground">Live assessment sessions</p>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Global Reach</CardTitle>
                  <Globe className="h-4 w-4 text-purple-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">67</div>
                  <p className="text-xs text-muted-foreground">Countries served</p>
                </CardContent>
              </Card>
            </div>

            <Card className="mt-6">
              <CardHeader>
                <CardTitle>Quick Start</CardTitle>
                <CardDescription>
                  Get started with the EIQ™ API in minutes
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="bg-slate-900 dark:bg-slate-800 rounded-lg p-4 text-green-400 font-mono text-sm">
                  <div>curl -X POST https://api.eiq.com/v1/assess \</div>
                  <div>&nbsp;&nbsp;-H "Authorization: Bearer YOUR_API_KEY" \</div>
                  <div>&nbsp;&nbsp;-H "Content-Type: application/json" \</div>
                  <div>&nbsp;&nbsp;-d '{`{"userId": "user123", "assessmentType": "comprehensive"}`}'</div>
                </div>
                <div className="flex space-x-2">
                  <Badge variant="secondary">RESTful API</Badge>
                  <Badge variant="secondary">Real-time WebSocket</Badge>
                  <Badge variant="secondary">99.9% Uptime</Badge>
                  <Badge variant="secondary">Global CDN</Badge>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="api-keys">
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Generate New API Key</CardTitle>
                  <CardDescription>Create a new API key for your application</CardDescription>
                </CardHeader>
                <CardContent className="flex space-x-2">
                  <Input 
                    placeholder="Enter key name (e.g., My App Production)"
                    value={newKeyName}
                    onChange={(e) => setNewKeyName(e.target.value)}
                  />
                  <Button onClick={generateNewKey} disabled={!newKeyName.trim()}>
                    <Key className="w-4 h-4 mr-2" />
                    Generate
                  </Button>
                </CardContent>
              </Card>

              <div className="space-y-4">
                {apiKeys.map((key) => (
                  <Card key={key.id}>
                    <CardContent className="pt-6">
                      <div className="flex items-center justify-between">
                        <div className="space-y-1">
                          <div className="flex items-center space-x-2">
                            <h4 className="font-semibold">{key.name}</h4>
                            <Badge variant={key.status === 'active' ? 'default' : 'destructive'}>
                              {key.status}
                            </Badge>
                          </div>
                          <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                            <span>{key.key}</span>
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              onClick={() => copyToClipboard(key.key)}
                            >
                              <Copy className="w-3 h-3" />
                            </Button>
                          </div>
                          <div className="flex space-x-4 text-xs text-muted-foreground">
                            <span>Created: {key.createdAt}</span>
                            <span>Last used: {key.lastUsed}</span>
                            <span>Requests: {key.requests.toLocaleString()}</span>
                            <span>Rate limit: {key.rateLimit}</span>
                          </div>
                        </div>
                        <Button variant="outline" size="sm">
                          Manage
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="documentation">
            <div className="grid gap-6 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <FileText className="w-5 h-5" />
                    <span>Core API Endpoints</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <code className="text-sm bg-slate-100 dark:bg-slate-800 px-2 py-1 rounded">POST /api/eiq/assess</code>
                      <Badge variant="outline">Start Assessment</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <code className="text-sm bg-slate-100 dark:bg-slate-800 px-2 py-1 rounded">GET /api/eiq/assessment/:id</code>
                      <Badge variant="outline">Get Results</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <code className="text-sm bg-slate-100 dark:bg-slate-800 px-2 py-1 rounded">POST /api/viral-challenge/start</code>
                      <Badge variant="outline">15s Challenge</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <code className="text-sm bg-slate-100 dark:bg-slate-800 px-2 py-1 rounded">GET /api/role-models/match</code>
                      <Badge variant="outline">AI Matching</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Code className="w-5 h-5" />
                    <span>Response Format</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="bg-slate-900 dark:bg-slate-800 rounded-lg p-4 text-green-400 font-mono text-xs">
                    <pre>{`{
  "assessmentId": "assess_123",
  "status": "completed",
  "eiqScore": 742,
  "percentile": 88,
  "domains": {
    "verbal": 85,
    "mathematical": 92,
    "spatial": 78,
    "logical": 89,
    "memory": 81,
    "processing": 87
  },
  "insights": [
    "Exceptional logical reasoning",
    "Strong mathematical aptitude"
  ],
  "recommendations": [...],
  "nextSteps": [...]
}`}</pre>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="examples">
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>JavaScript/Node.js Example</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="bg-slate-900 dark:bg-slate-800 rounded-lg p-4 text-green-400 font-mono text-sm">
                    <pre>{`const eiq = require('@eiq/api-client');

const client = new eiq.Client('your_api_key');

// Start a comprehensive assessment
const assessment = await client.assessments.start({
  userId: 'user_123',
  type: 'comprehensive',
  domains: ['verbal', 'mathematical', 'logical']
});

// Get real-time results
const results = await client.assessments.getResults(assessment.id);
console.log(\`EIQ Score: \${results.eiqScore}\`);`}</pre>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Python Example</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="bg-slate-900 dark:bg-slate-800 rounded-lg p-4 text-green-400 font-mono text-sm">
                    <pre>{`import eiq

client = eiq.Client(api_key='your_api_key')

# Start viral 15-second challenge
challenge = client.viral_challenge.start(
    challenge_type='15_second',
    user_id='user_123'
)

# Get leaderboard
leaderboard = client.viral_challenge.leaderboard('15_second')
print(f"Top score: {leaderboard.top_score}")`}</pre>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="analytics">
            <div className="grid gap-6 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>API Usage Overview</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between">
                      <span>Assessment API</span>
                      <span className="font-bold">12,847 requests</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Viral Challenge API</span>
                      <span className="font-bold">4,521 requests</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Role Model Matching</span>
                      <span className="font-bold">1,900 requests</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Rate Limits & Performance</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between">
                      <span>Average Response Time</span>
                      <span className="font-bold text-green-600">247ms</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Success Rate</span>
                      <span className="font-bold text-green-600">99.94%</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Rate Limit Usage</span>
                      <span className="font-bold">68% of 1000/hour</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}