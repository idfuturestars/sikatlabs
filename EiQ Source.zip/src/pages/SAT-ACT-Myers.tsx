import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { 
  Calculator, 
  Brain, 
  Users, 
  Lightbulb, 
  BookOpen,
  Clock,
  Target,
  TrendingUp,
  Award,
  CheckCircle,
  PlayCircle,
  Crown,
  BarChart3,
  User,
  Zap,
  Star,
  Trophy,
  LineChart,
  ChevronRight,
  Download
} from "lucide-react";
import { useState } from "react";

interface TestResult {
  testType: string;
  score: number;
  maxScore: number;
  percentile: number;
  date: string;
  sections: Record<string, number>;
  recommendations: string[];
}

interface PersonalityProfile {
  type: string;
  description: string;
  traits: string[];
  careerMatches: string[];
  strengthAreas: string[];
  developmentAreas: string[];
}

interface RoleModelMatch {
  id: string;
  name: string;
  domain: string;
  matchScore: number;
  matchReason: string;
  imageUrl?: string;
  achievements: string[];
}

interface PrepResource {
  title: string;
  type: string;
  difficulty: string;
  estimatedTime: string;
  completed: boolean;
  category: string;
}

export default function SATACTMyers() {
  const [activeTab, setActiveTab] = useState("overview");
  const queryClient = useQueryClient();

  // Fetch standardized test results
  const { data: testResults } = useQuery<TestResult[]>({
    queryKey: ["/api/analytics/standardized-tests"],
    staleTime: 10 * 60 * 1000, // 10 minutes
  });

  // Fetch personality profiles (Myers-Briggs, DISC, Big Five)
  const { data: personalityData } = useQuery<PersonalityProfile>({
    queryKey: ["/api/analytics/personality-profiles"],
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  // Fetch DSM cognitive profile
  const { data: cognitiveProfile } = useQuery({
    queryKey: ["/api/assessment/dsm/cognitive-profile"],
    staleTime: 10 * 60 * 1000, // 10 minutes
  });

  // Fetch role model matches
  const { data: roleModelMatches } = useQuery<RoleModelMatch[]>({
    queryKey: ["/api/role-models/matches"],
    staleTime: 15 * 60 * 1000, // 15 minutes
  });

  // Fetch preparation resources
  const { data: prepResources } = useQuery<PrepResource[]>({
    queryKey: ["/api/prep-resources"],
    staleTime: 30 * 60 * 1000, // 30 minutes
  });

  // Start new assessment mutation
  const startAssessmentMutation = useMutation({
    mutationFn: async (assessmentType: string) => {
      return await apiRequest(`/api/assessment/${assessmentType}/start`, {
        method: "POST",
        body: { userId: "current" }
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/analytics"] });
    },
  });

  const assessmentTypes = [
    {
      id: "sat",
      title: "SAT Assessment",
      description: "Standardized test for college admissions",
      icon: Calculator,
      sections: ["Math", "Evidence-Based Reading", "Writing"],
      duration: "3 hours",
      status: "Available",
      color: "text-blue-600",
      bgColor: "bg-blue-100",
      results: testResults?.find(r => r.testType === "SAT")
    },
    {
      id: "act",
      title: "ACT Assessment", 
      description: "Alternative college admission test",
      icon: BookOpen,
      sections: ["English", "Math", "Reading", "Science"],
      duration: "2 hours 55 minutes",
      status: "Available",
      color: "text-green-600",
      bgColor: "bg-green-100",
      results: testResults?.find(r => r.testType === "ACT")
    },
    {
      id: "myers-briggs",
      title: "Myers-Briggs Type Indicator",
      description: "Personality assessment for career guidance",
      icon: Brain,
      sections: ["Extraversion/Introversion", "Sensing/Intuition", "Thinking/Feeling", "Judging/Perceiving"],
      duration: "45 minutes",
      status: "Available",
      color: "text-purple-600",
      bgColor: "bg-purple-100",
      results: personalityData
    },
    {
      id: "dsm",
      title: "DSM-5-TR Assessment",
      description: "Clinical diagnostic assessment integration",
      icon: Target,
      sections: ["Cognitive Patterns", "Behavioral Analysis", "Risk Assessment"],
      duration: "60 minutes",
      status: cognitiveProfile ? "Completed" : "Available",
      color: "text-orange-600",
      bgColor: "bg-orange-100",
      results: cognitiveProfile
    }
  ];

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "Completed":
        return <CheckCircle className="w-5 h-5 text-green-500" />;
      case "Available":
        return <PlayCircle className="w-5 h-5 text-blue-500" />;
      default:
        return <Clock className="w-5 h-5 text-muted-foreground" />;
    }
  };

  const completedAssessments = assessmentTypes.filter(a => a.status === "Completed").length;
  const totalAssessments = assessmentTypes.length;
  const overallProgress = (completedAssessments / totalAssessments) * 100;

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-4">
          <h1 className="text-4xl font-bold gradient-text">Assessment Center</h1>
          <p className="text-muted-foreground max-w-3xl mx-auto">
            Comprehensive standardized testing, personality assessments, and clinical evaluations with AI-powered analysis and role model matching
          </p>
        </div>

        {/* Overview Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6 text-center">
              <div className="text-3xl font-bold text-primary mb-2">{completedAssessments}</div>
              <div className="text-sm text-muted-foreground">Completed Assessments</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6 text-center">
              <div className="text-3xl font-bold text-green-600 mb-2">
                {testResults?.reduce((acc, test) => acc + test.percentile, 0) / (testResults?.length || 1) || 0}%
              </div>
              <div className="text-sm text-muted-foreground">Average Percentile</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6 text-center">
              <div className="text-3xl font-bold text-blue-600 mb-2">{roleModelMatches?.length || 0}</div>
              <div className="text-sm text-muted-foreground">Role Model Matches</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6 text-center">
              <div className="text-3xl font-bold text-orange-600 mb-2">
                {prepResources?.filter(r => r.completed).length || 0}
              </div>
              <div className="text-sm text-muted-foreground">Resources Completed</div>
            </CardContent>
          </Card>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="results">Test Results</TabsTrigger>
            <TabsTrigger value="personality">Personality</TabsTrigger>
            <TabsTrigger value="preparation">Preparation</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            {/* Assessment Progress */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="w-5 h-5" />
                  Assessment Progress Overview
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between text-sm">
                    <span>Overall Completion</span>
                    <span>{completedAssessments} of {totalAssessments} assessments completed</span>
                  </div>
                  <Progress value={overallProgress} className="h-3" />
                </div>
              </CardContent>
            </Card>

            {/* Assessment Cards */}
            <div className="grid gap-6 md:grid-cols-2">
              {assessmentTypes.map((assessment) => (
                <Card key={assessment.id} className="relative">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className={`p-2 ${assessment.bgColor} rounded-lg`}>
                          <assessment.icon className={`w-6 h-6 ${assessment.color}`} />
                        </div>
                        <div>
                          <CardTitle className="text-lg">{assessment.title}</CardTitle>
                          <p className="text-sm text-muted-foreground">{assessment.description}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {getStatusIcon(assessment.status)}
                        <Badge className={assessment.status === "Completed" ? "bg-green-100 text-green-800" : 
                                          assessment.status === "Available" ? "bg-blue-100 text-blue-800" : 
                                          "bg-gray-100 text-gray-800"}>
                          {assessment.status}
                        </Badge>
                      </div>
                    </div>
                  </CardHeader>
                  
                  <CardContent className="space-y-4">
                    <div className="flex items-center gap-6 text-sm text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <Clock className="w-4 h-4" />
                        <span>{assessment.duration}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Target className="w-4 h-4" />
                        <span>{assessment.sections.length} sections</span>
                      </div>
                    </div>

                    {assessment.results && assessment.id !== "myers-briggs" && assessment.id !== "dsm" && (
                      <div className="p-3 bg-muted/30 rounded-lg">
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm font-medium">Latest Score</span>
                          <Badge className="bg-green-100 text-green-800">
                            {assessment.results.score}/{assessment.results.maxScore}
                          </Badge>
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {assessment.results.percentile}th percentile • {new Date(assessment.results.date).toLocaleDateString()}
                        </div>
                      </div>
                    )}

                    {assessment.results && assessment.id === "myers-briggs" && personalityData && (
                      <div className="p-3 bg-muted/30 rounded-lg">
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm font-medium">Personality Type</span>
                          <Badge className="bg-purple-100 text-purple-800">
                            {personalityData.type}
                          </Badge>
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {personalityData.description}
                        </div>
                      </div>
                    )}
                    
                    <div className="pt-2">
                      <Button 
                        className="w-full" 
                        variant={assessment.status === "Completed" ? "outline" : "default"}
                        disabled={startAssessmentMutation.isPending}
                        onClick={() => startAssessmentMutation.mutate(assessment.id)}
                      >
                        {assessment.status === "Completed" ? "Retake Assessment" : "Start Assessment"}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="results" className="space-y-6">
            {/* Test Results Dashboard */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Trophy className="w-5 h-5" />
                  Standardized Test Results
                </CardTitle>
                <p className="text-muted-foreground">Comprehensive analysis of your SAT and ACT performance</p>
              </CardHeader>
              <CardContent>
                {testResults && testResults.length > 0 ? (
                  <div className="space-y-6">
                    {testResults.map((result) => (
                      <div key={result.testType} className="border border-border rounded-lg p-6">
                        <div className="flex justify-between items-start mb-4">
                          <div>
                            <h3 className="text-xl font-semibold">{result.testType} Results</h3>
                            <p className="text-muted-foreground">Taken on {new Date(result.date).toLocaleDateString()}</p>
                          </div>
                          <div className="text-right">
                            <div className="text-3xl font-bold">{result.score}</div>
                            <div className="text-sm text-muted-foreground">out of {result.maxScore}</div>
                            <Badge className="mt-1 bg-green-100 text-green-800">
                              {result.percentile}th percentile
                            </Badge>
                          </div>
                        </div>

                        {/* Section Breakdown */}
                        <div className="grid md:grid-cols-3 gap-4 mb-4">
                          {Object.entries(result.sections).map(([section, score]) => (
                            <div key={section} className="text-center p-3 bg-muted/30 rounded">
                              <div className="text-lg font-semibold">{score}</div>
                              <div className="text-xs text-muted-foreground">{section}</div>
                            </div>
                          ))}
                        </div>

                        {/* Recommendations */}
                        {result.recommendations && result.recommendations.length > 0 && (
                          <div className="mt-4 p-4 bg-blue-50 rounded-lg">
                            <h4 className="font-medium mb-2 flex items-center gap-2">
                              <Lightbulb className="w-4 h-4" />
                              Improvement Recommendations
                            </h4>
                            <ul className="space-y-1 text-sm">
                              {result.recommendations.map((rec, i) => (
                                <li key={i} className="flex items-start gap-2">
                                  <ChevronRight className="w-3 h-3 mt-1 text-blue-500 flex-shrink-0" />
                                  <span>{rec}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <Trophy className="w-16 h-16 mx-auto mb-4 text-muted-foreground opacity-50" />
                    <h3 className="text-lg font-medium mb-2">No Test Results Yet</h3>
                    <p className="text-muted-foreground mb-4">Complete your first standardized test to see results here</p>
                    <Button onClick={() => setActiveTab("overview")}>
                      Start an Assessment
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="personality" className="space-y-6">
            {/* Personality Profile & Role Model Matching */}
            <div className="grid lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Brain className="w-5 h-5" />
                    Personality Profile
                  </CardTitle>
                  <p className="text-muted-foreground">Myers-Briggs and cognitive assessment results</p>
                </CardHeader>
                <CardContent>
                  {personalityData ? (
                    <div className="space-y-4">
                      <div className="text-center p-4 bg-purple-50 rounded-lg">
                        <div className="text-2xl font-bold mb-2">{personalityData.type}</div>
                        <p className="text-sm text-muted-foreground">{personalityData.description}</p>
                      </div>

                      <div>
                        <h4 className="font-medium mb-2">Strength Areas</h4>
                        <div className="space-y-1">
                          {personalityData.strengthAreas?.map((area, i) => (
                            <div key={i} className="flex items-center gap-2 text-sm">
                              <Star className="w-3 h-3 text-yellow-500" />
                              <span>{area}</span>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div>
                        <h4 className="font-medium mb-2">Career Matches</h4>
                        <div className="flex flex-wrap gap-2">
                          {personalityData.careerMatches?.map((career, i) => (
                            <Badge key={i} variant="outline" className="text-xs">
                              {career}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <Brain className="w-12 h-12 mx-auto mb-4 text-muted-foreground opacity-50" />
                      <p className="text-muted-foreground">Complete the Myers-Briggs assessment to see your personality profile</p>
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Crown className="w-5 h-5" />
                    Role Model Matches
                  </CardTitle>
                  <p className="text-muted-foreground">AI-powered matching based on your assessments</p>
                </CardHeader>
                <CardContent>
                  {roleModelMatches && roleModelMatches.length > 0 ? (
                    <div className="space-y-4">
                      {roleModelMatches.slice(0, 3).map((match) => (
                        <div key={match.id} className="flex items-center gap-4 p-3 border border-border rounded-lg">
                          <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
                            <User className="w-6 h-6 text-primary" />
                          </div>
                          <div className="flex-1">
                            <div className="font-medium">{match.name}</div>
                            <div className="text-sm text-muted-foreground">{match.domain}</div>
                            <div className="text-xs text-muted-foreground mt-1">{match.matchReason}</div>
                          </div>
                          <div className="text-right">
                            <div className="text-lg font-bold text-green-600">{match.matchScore}%</div>
                            <div className="text-xs text-muted-foreground">match</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <Crown className="w-12 h-12 mx-auto mb-4 text-muted-foreground opacity-50" />
                      <p className="text-muted-foreground">Complete assessments to get AI-powered role model matches</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="preparation" className="space-y-6">
            {/* Preparation Resources */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BookOpen className="w-5 h-5" />
                  Preparation Resources
                </CardTitle>
                <p className="text-muted-foreground">Curated study materials and practice tests</p>
              </CardHeader>
              <CardContent>
                {prepResources && prepResources.length > 0 ? (
                  <div className="space-y-4">
                    {["SAT", "ACT", "Myers-Briggs", "DSM"].map((category) => {
                      const categoryResources = prepResources.filter(r => r.category === category);
                      if (categoryResources.length === 0) return null;

                      return (
                        <div key={category} className="space-y-3">
                          <h3 className="text-lg font-semibold">{category} Preparation</h3>
                          <div className="grid md:grid-cols-2 gap-4">
                            {categoryResources.map((resource, i) => (
                              <div key={i} className="border border-border rounded-lg p-4">
                                <div className="flex justify-between items-start mb-2">
                                  <h4 className="font-medium">{resource.title}</h4>
                                  {resource.completed && (
                                    <CheckCircle className="w-4 h-4 text-green-500" />
                                  )}
                                </div>
                                <div className="flex gap-2 mb-3">
                                  <Badge variant="outline" className="text-xs">{resource.type}</Badge>
                                  <Badge variant="outline" className="text-xs">{resource.difficulty}</Badge>
                                  <Badge variant="outline" className="text-xs">{resource.estimatedTime}</Badge>
                                </div>
                                <Button 
                                  size="sm" 
                                  variant={resource.completed ? "outline" : "default"}
                                  className="w-full"
                                >
                                  {resource.completed ? "Review" : "Start"}
                                </Button>
                              </div>
                            ))}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <BookOpen className="w-16 h-16 mx-auto mb-4 text-muted-foreground opacity-50" />
                    <h3 className="text-lg font-medium mb-2">Preparation Resources Loading</h3>
                    <p className="text-muted-foreground">Curated study materials will appear based on your assessment results</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}