import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, 
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  ScatterChart, Scatter, RadarChart, Radar, PolarGrid, PolarAngleAxis, PolarRadiusAxis
} from 'recharts';
import { 
  Users, TrendingUp, BookOpen, Brain, Target, Clock, 
  Award, AlertTriangle, Download, Filter, RefreshCw,
  GraduationCap, MessageSquare, BarChart3, PieChart as PieChartIcon
} from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { useTranslation } from '@/i18n/i18nContext';

interface StudentMetrics {
  id: string;
  name: string;
  email: string;
  currentEiqScore: number;
  previousEiqScore: number;
  progressRate: number;
  engagementLevel: number;
  timeSpent: number; // hours
  assessmentsCompleted: number;
  skillsMastered: number;
  nextMilestone: string;
  riskLevel: 'low' | 'medium' | 'high';
  lastActive: Date;
}

interface CohortAnalytics {
  cohortId: string;
  cohortName: string;
  totalStudents: number;
  activeStudents: number;
  averageEiqScore: number;
  averageProgressRate: number;
  completionRate: number;
  engagementDistribution: Array<{ level: string; count: number }>;
  skillDistribution: Array<{ skill: string; mastery: number }>;
  performanceTrends: Array<{ date: string; avgScore: number; engagement: number }>;
}

interface InstitutionDashboard {
  totalStudents: number;
  totalEducators: number;
  totalCohorts: number;
  platformUsage: {
    dailyActiveUsers: number;
    weeklyActiveUsers: number;
    monthlyActiveUsers: number;
  };
  performanceMetrics: {
    averageEiqImprovement: number;
    skillMasteryRate: number;
    assessmentCompletionRate: number;
    studentSatisfaction: number;
  };
  aiInsights: Array<{
    type: 'recommendation' | 'alert' | 'achievement';
    title: string;
    description: string;
    priority: 'low' | 'medium' | 'high';
    timestamp: Date;
  }>;
}

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8'];

export default function EducatorAnalytics() {
  const { user, isLoading: authLoading } = useAuth();
  const t = useTranslation();
  const [selectedCohort, setSelectedCohort] = useState<string>('all');
  const [timeRange, setTimeRange] = useState<string>('30d');
  const [activeTab, setActiveTab] = useState<string>('overview');

  // Mock data queries (would be real API calls in production)
  const { data: institutionData, isLoading: institutionLoading } = useQuery({
    queryKey: ['/api/educator/institution-dashboard', timeRange],
    enabled: !!user,
  });

  const { data: cohortsData, isLoading: cohortsLoading } = useQuery({
    queryKey: ['/api/educator/cohorts', selectedCohort, timeRange],
    enabled: !!user,
  });

  const { data: studentsData, isLoading: studentsLoading } = useQuery({
    queryKey: ['/api/educator/students', selectedCohort, timeRange],
    enabled: !!user,
  });

  const { data: analyticsData, isLoading: analyticsLoading } = useQuery({
    queryKey: ['/api/educator/analytics', selectedCohort, timeRange],
    enabled: !!user,
  });

  // Mock data for demonstration
  const mockInstitutionData: InstitutionDashboard = {
    totalStudents: 1247,
    totalEducators: 45,
    totalCohorts: 23,
    platformUsage: {
      dailyActiveUsers: 892,
      weeklyActiveUsers: 1156,
      monthlyActiveUsers: 1247
    },
    performanceMetrics: {
      averageEiqImprovement: 47,
      skillMasteryRate: 73,
      assessmentCompletionRate: 89,
      studentSatisfaction: 4.6
    },
    aiInsights: [
      {
        type: 'alert',
        title: 'Engagement Drop Detected',
        description: 'Cohort CS-101 showing 15% decrease in engagement over past week',
        priority: 'high',
        timestamp: new Date()
      },
      {
        type: 'recommendation',
        title: 'Optimize Study Times',
        description: 'Students show 23% better performance during 9-11 AM sessions',
        priority: 'medium',
        timestamp: new Date()
      },
      {
        type: 'achievement',
        title: 'Milestone Achievement',
        description: '89% of Advanced Math cohort reached proficiency targets',
        priority: 'low',
        timestamp: new Date()
      }
    ]
  };

  const mockStudentsData: StudentMetrics[] = [
    {
      id: '1',
      name: 'Alice Johnson',
      email: 'alice.j@school.edu',
      currentEiqScore: 742,
      previousEiqScore: 698,
      progressRate: 6.3,
      engagementLevel: 85,
      timeSpent: 23.5,
      assessmentsCompleted: 12,
      skillsMastered: 8,
      nextMilestone: 'Advanced Problem Solving',
      riskLevel: 'low',
      lastActive: new Date('2025-01-22')
    },
    {
      id: '2',
      name: 'Bob Chen',
      email: 'bob.c@school.edu',
      currentEiqScore: 689,
      previousEiqScore: 705,
      progressRate: -2.3,
      engagementLevel: 62,
      timeSpent: 18.2,
      assessmentsCompleted: 9,
      skillsMastered: 6,
      nextMilestone: 'Logical Reasoning',
      riskLevel: 'medium',
      lastActive: new Date('2025-01-21')
    },
    {
      id: '3',
      name: 'Carol Martinez',
      email: 'carol.m@school.edu',
      currentEiqScore: 798,
      previousEiqScore: 756,
      progressRate: 5.6,
      engagementLevel: 92,
      timeSpent: 31.8,
      assessmentsCompleted: 15,
      skillsMastered: 11,
      nextMilestone: 'Expert Assessment',
      riskLevel: 'low',
      lastActive: new Date('2025-01-22')
    }
  ];

  const mockCohortAnalytics: CohortAnalytics = {
    cohortId: 'cohort_1',
    cohortName: 'Advanced Mathematics',
    totalStudents: 28,
    activeStudents: 26,
    averageEiqScore: 724,
    averageProgressRate: 4.2,
    completionRate: 89,
    engagementDistribution: [
      { level: 'High (80-100%)', count: 18 },
      { level: 'Medium (60-79%)', count: 7 },
      { level: 'Low (40-59%)', count: 2 },
      { level: 'Very Low (<40%)', count: 1 }
    ],
    skillDistribution: [
      { skill: 'Algebra', mastery: 92 },
      { skill: 'Geometry', mastery: 78 },
      { skill: 'Calculus', mastery: 65 },
      { skill: 'Statistics', mastery: 83 },
      { skill: 'Logic', mastery: 88 }
    ],
    performanceTrends: [
      { date: '2025-01-15', avgScore: 698, engagement: 76 },
      { date: '2025-01-16', avgScore: 705, engagement: 78 },
      { date: '2025-01-17', avgScore: 712, engagement: 81 },
      { date: '2025-01-18', avgScore: 718, engagement: 79 },
      { date: '2025-01-19', avgScore: 724, engagement: 83 },
      { date: '2025-01-20', avgScore: 728, engagement: 85 },
      { date: '2025-01-21', avgScore: 724, engagement: 82 }
    ]
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  const getRiskLevelColor = (risk: string) => {
    switch (risk) {
      case 'high': return 'destructive';
      case 'medium': return 'secondary';
      case 'low': return 'success';
      default: return 'secondary';
    }
  };

  const getInsightIcon = (type: string) => {
    switch (type) {
      case 'alert': return <AlertTriangle className="h-4 w-4" />;
      case 'recommendation': return <Brain className="h-4 w-4" />;
      case 'achievement': return <Award className="h-4 w-4" />;
      default: return <Brain className="h-4 w-4" />;
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold">Educator Analytics Dashboard</h1>
            <p className="text-muted-foreground">
              Comprehensive insights into student performance and learning outcomes
            </p>
          </div>
          
          <div className="flex items-center gap-4">
            <Select value={selectedCohort} onValueChange={setSelectedCohort}>
              <SelectTrigger className="w-[180px]" data-testid="select-cohort">
                <SelectValue placeholder="Select Cohort" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Cohorts</SelectItem>
                <SelectItem value="advanced_math">Advanced Mathematics</SelectItem>
                <SelectItem value="english_lit">English Literature</SelectItem>
                <SelectItem value="computer_sci">Computer Science</SelectItem>
              </SelectContent>
            </Select>

            <Select value={timeRange} onValueChange={setTimeRange}>
              <SelectTrigger className="w-[120px]" data-testid="select-timerange">
                <SelectValue placeholder="Time Range" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="7d">7 Days</SelectItem>
                <SelectItem value="30d">30 Days</SelectItem>
                <SelectItem value="90d">90 Days</SelectItem>
                <SelectItem value="1y">1 Year</SelectItem>
              </SelectContent>
            </Select>

            <Button variant="outline" size="sm" data-testid="button-refresh">
              <RefreshCw className="h-4 w-4 mr-2" />
              Refresh
            </Button>

            <Button variant="outline" size="sm" data-testid="button-export">
              <Download className="h-4 w-4 mr-2" />
              Export
            </Button>
          </div>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card data-testid="card-total-students">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Students</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{mockInstitutionData.totalStudents}</div>
              <p className="text-xs text-muted-foreground">
                <span className="text-green-600">+12</span> from last month
              </p>
            </CardContent>
          </Card>

          <Card data-testid="card-avg-eiq-improvement">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Avg EiQ Improvement</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">+{mockInstitutionData.performanceMetrics.averageEiqImprovement}</div>
              <p className="text-xs text-muted-foreground">
                Points per student this month
              </p>
            </CardContent>
          </Card>

          <Card data-testid="card-skill-mastery-rate">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Skill Mastery Rate</CardTitle>
              <Target className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{mockInstitutionData.performanceMetrics.skillMasteryRate}%</div>
              <p className="text-xs text-muted-foreground">
                <span className="text-green-600">+5%</span> from last month
              </p>
            </CardContent>
          </Card>

          <Card data-testid="card-completion-rate">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Completion Rate</CardTitle>
              <BookOpen className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{mockInstitutionData.performanceMetrics.assessmentCompletionRate}%</div>
              <p className="text-xs text-muted-foreground">
                Assessment completion
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Main Analytics Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="overview" data-testid="tab-overview">Overview</TabsTrigger>
            <TabsTrigger value="students" data-testid="tab-students">Students</TabsTrigger>
            <TabsTrigger value="performance" data-testid="tab-performance">Performance</TabsTrigger>
            <TabsTrigger value="engagement" data-testid="tab-engagement">Engagement</TabsTrigger>
            <TabsTrigger value="insights" data-testid="tab-insights">AI Insights</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Performance Trends */}
              <Card data-testid="chart-performance-trends">
                <CardHeader>
                  <CardTitle>Performance Trends</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <LineChart data={mockCohortAnalytics.performanceTrends}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis />
                      <Tooltip />
                      <Line 
                        type="monotone" 
                        dataKey="avgScore" 
                        stroke="#8884d8" 
                        strokeWidth={2}
                        name="Average EiQ Score"
                      />
                      <Line 
                        type="monotone" 
                        dataKey="engagement" 
                        stroke="#82ca9d" 
                        strokeWidth={2}
                        name="Engagement %"
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              {/* Engagement Distribution */}
              <Card data-testid="chart-engagement-distribution">
                <CardHeader>
                  <CardTitle>Engagement Distribution</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                      <Pie
                        data={mockCohortAnalytics.engagementDistribution}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ level, count }) => `${level}: ${count}`}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="count"
                      >
                        {mockCohortAnalytics.engagementDistribution.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              {/* Skill Mastery Radar */}
              <Card data-testid="chart-skill-mastery">
                <CardHeader>
                  <CardTitle>Skill Mastery Overview</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <RadarChart data={mockCohortAnalytics.skillDistribution}>
                      <PolarGrid />
                      <PolarAngleAxis dataKey="skill" />
                      <PolarRadiusAxis domain={[0, 100]} />
                      <Radar
                        name="Mastery %"
                        dataKey="mastery"
                        stroke="#8884d8"
                        fill="#8884d8"
                        fillOpacity={0.3}
                      />
                      <Tooltip />
                    </RadarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              {/* Active Users */}
              <Card data-testid="card-active-users">
                <CardHeader>
                  <CardTitle>Platform Usage</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Daily Active Users</span>
                    <span className="font-bold">{mockInstitutionData.platformUsage.dailyActiveUsers}</span>
                  </div>
                  <Progress 
                    value={(mockInstitutionData.platformUsage.dailyActiveUsers / mockInstitutionData.totalStudents) * 100} 
                    className="h-2"
                  />
                  
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Weekly Active Users</span>
                    <span className="font-bold">{mockInstitutionData.platformUsage.weeklyActiveUsers}</span>
                  </div>
                  <Progress 
                    value={(mockInstitutionData.platformUsage.weeklyActiveUsers / mockInstitutionData.totalStudents) * 100} 
                    className="h-2"
                  />
                  
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Monthly Active Users</span>
                    <span className="font-bold">{mockInstitutionData.platformUsage.monthlyActiveUsers}</span>
                  </div>
                  <Progress 
                    value={(mockInstitutionData.platformUsage.monthlyActiveUsers / mockInstitutionData.totalStudents) * 100} 
                    className="h-2"
                  />
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="students" className="space-y-6">
            <Card data-testid="table-students">
              <CardHeader>
                <CardTitle>Student Performance Overview</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left p-2">Student</th>
                        <th className="text-left p-2">Current EiQ</th>
                        <th className="text-left p-2">Progress</th>
                        <th className="text-left p-2">Engagement</th>
                        <th className="text-left p-2">Time Spent</th>
                        <th className="text-left p-2">Risk Level</th>
                        <th className="text-left p-2">Last Active</th>
                      </tr>
                    </thead>
                    <tbody>
                      {mockStudentsData.map((student) => (
                        <tr key={student.id} className="border-b hover:bg-muted/50">
                          <td className="p-2">
                            <div>
                              <div className="font-medium">{student.name}</div>
                              <div className="text-sm text-muted-foreground">{student.email}</div>
                            </div>
                          </td>
                          <td className="p-2">
                            <div className="font-bold">{student.currentEiqScore}</div>
                            <div className="text-sm text-muted-foreground">
                              {student.progressRate > 0 ? '+' : ''}{student.progressRate}%
                            </div>
                          </td>
                          <td className="p-2">
                            <Progress value={student.progressRate + 50} className="w-20 h-2" />
                          </td>
                          <td className="p-2">
                            <div className="font-medium">{student.engagementLevel}%</div>
                          </td>
                          <td className="p-2">{student.timeSpent}h</td>
                          <td className="p-2">
                            <Badge variant={getRiskLevelColor(student.riskLevel) as any}>
                              {student.riskLevel}
                            </Badge>
                          </td>
                          <td className="p-2 text-sm">
                            {student.lastActive.toLocaleDateString()}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="performance" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card data-testid="chart-skill-breakdown">
                <CardHeader>
                  <CardTitle>Skill Mastery Breakdown</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={mockCohortAnalytics.skillDistribution}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="skill" />
                      <YAxis domain={[0, 100]} />
                      <Tooltip />
                      <Bar dataKey="mastery" fill="#8884d8" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card data-testid="card-performance-metrics">
                <CardHeader>
                  <CardTitle>Performance Metrics</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center p-4 bg-muted rounded-lg">
                      <div className="text-2xl font-bold text-primary">
                        {mockCohortAnalytics.averageEiqScore}
                      </div>
                      <div className="text-sm text-muted-foreground">Average EiQ Score</div>
                    </div>
                    <div className="text-center p-4 bg-muted rounded-lg">
                      <div className="text-2xl font-bold text-green-600">
                        {mockCohortAnalytics.completionRate}%
                      </div>
                      <div className="text-sm text-muted-foreground">Completion Rate</div>
                    </div>
                    <div className="text-center p-4 bg-muted rounded-lg">
                      <div className="text-2xl font-bold text-blue-600">
                        {mockCohortAnalytics.activeStudents}/{mockCohortAnalytics.totalStudents}
                      </div>
                      <div className="text-sm text-muted-foreground">Active Students</div>
                    </div>
                    <div className="text-center p-4 bg-muted rounded-lg">
                      <div className="text-2xl font-bold text-orange-600">
                        +{mockCohortAnalytics.averageProgressRate}%
                      </div>
                      <div className="text-sm text-muted-foreground">Progress Rate</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="engagement" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card data-testid="chart-engagement-over-time">
                <CardHeader>
                  <CardTitle>Engagement Over Time</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <LineChart data={mockCohortAnalytics.performanceTrends}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis domain={[0, 100]} />
                      <Tooltip />
                      <Line 
                        type="monotone" 
                        dataKey="engagement" 
                        stroke="#82ca9d" 
                        strokeWidth={3}
                        name="Engagement %"
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card data-testid="chart-engagement-scatter">
                <CardHeader>
                  <CardTitle>Engagement vs Performance</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <ScatterChart>
                      <CartesianGrid />
                      <XAxis dataKey="engagementLevel" name="Engagement" unit="%" />
                      <YAxis dataKey="currentEiqScore" name="EiQ Score" />
                      <Tooltip cursor={{ strokeDasharray: '3 3' }} />
                      <Scatter 
                        name="Students" 
                        data={mockStudentsData} 
                        fill="#8884d8" 
                      />
                    </ScatterChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="insights" className="space-y-6">
            <Card data-testid="card-ai-insights">
              <CardHeader>
                <CardTitle>AI-Powered Insights & Recommendations</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {mockInstitutionData.aiInsights.map((insight, index) => (
                    <div 
                      key={index}
                      className={`p-4 rounded-lg border-l-4 ${
                        insight.priority === 'high' ? 'border-red-500 bg-red-50 dark:bg-red-950' :
                        insight.priority === 'medium' ? 'border-yellow-500 bg-yellow-50 dark:bg-yellow-950' :
                        'border-green-500 bg-green-50 dark:bg-green-950'
                      }`}
                    >
                      <div className="flex items-start gap-3">
                        <div className={`p-2 rounded-full ${
                          insight.priority === 'high' ? 'bg-red-100 text-red-600' :
                          insight.priority === 'medium' ? 'bg-yellow-100 text-yellow-600' :
                          'bg-green-100 text-green-600'
                        }`}>
                          {getInsightIcon(insight.type)}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <h4 className="font-semibold">{insight.title}</h4>
                            <Badge variant="outline" className="text-xs">
                              {insight.type}
                            </Badge>
                          </div>
                          <p className="text-sm text-muted-foreground mb-2">
                            {insight.description}
                          </p>
                          <div className="text-xs text-muted-foreground">
                            {insight.timestamp.toLocaleString()}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}