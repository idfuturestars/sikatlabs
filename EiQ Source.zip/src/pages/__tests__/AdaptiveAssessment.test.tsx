import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import AdaptiveAssessment from '../AdaptiveAssessment';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: false,
    },
  },
});

const wrapper = ({ children }: { children: React.ReactNode }) => (
  <QueryClientProvider client={queryClient}>
    {children}
  </QueryClientProvider>
);

describe('AdaptiveAssessment', () => {
  beforeEach(() => {
    queryClient.clear();
  });

  test('renders assessment interface', () => {
    render(<AdaptiveAssessment />, { wrapper });
    
    expect(screen.getByText('Adaptive Assessment')).toBeInTheDocument();
    expect(screen.getByText('EiQ Pathway Evaluation')).toBeInTheDocument();
  });

  test('handleNextQuestion advances through questions without looping', async () => {
    render(<AdaptiveAssessment />, { wrapper });
    
    // Find the first question
    const questionElement = screen.getByText(/If x \+ 5 = 12/);
    expect(questionElement).toBeInTheDocument();
    
    // Answer the first question
    const firstOption = screen.getByText('7');
    fireEvent.click(firstOption);
    
    const submitButton = screen.getByText('Submit Answer');
    fireEvent.click(submitButton);
    
    // Wait for explanation to show
    await waitFor(() => {
      expect(screen.getByText('Next Question')).toBeInTheDocument();
    });
    
    // Click continue to next question
    const continueButton = screen.getByText('Next Question');
    fireEvent.click(continueButton);
    
    // Verify we moved to the second question
    await waitFor(() => {
      expect(screen.getByText(/What will this code output/)).toBeInTheDocument();
    });
    
    // Answer the second question
    const secondOption = screen.getByText('0 2 4');
    fireEvent.click(secondOption);
    
    fireEvent.click(screen.getByText('Submit Answer'));
    
    await waitFor(() => {
      expect(screen.getByText('Next Question')).toBeInTheDocument();
    });
    
    fireEvent.click(screen.getByText('Next Question'));
    
    // Verify we moved to the third question
    await waitFor(() => {
      expect(screen.getByText(/Explain in your own words what machine learning is/)).toBeInTheDocument();
    });
    
    // Answer the third question (open-ended)
    const textArea = screen.getByRole('textbox');
    fireEvent.change(textArea, { 
      target: { value: 'Machine learning is when computers learn from data to make predictions.' } 
    });
    
    fireEvent.click(screen.getByText('Submit Answer'));
    
    await waitFor(() => {
      expect(screen.getByText('Next Question')).toBeInTheDocument();
    });
    
    fireEvent.click(screen.getByText('Next Question'));
    
    // Verify assessment is completed (no more questions)
    await waitFor(() => {
      expect(screen.queryByText(/If x \+ 5 = 12/)).not.toBeInTheDocument();
    });
  });

  test('assessment completes after all questions are answered', async () => {
    render(<AdaptiveAssessment />, { wrapper });
    
    // Go through all three questions rapidly
    for (let i = 0; i < 3; i++) {
      if (i < 2) {
        // Multiple choice questions
        const options = screen.getAllByRole('radio');
        fireEvent.click(options[1]); // Click second option
      } else {
        // Open-ended question
        const textArea = screen.getByRole('textbox');
        fireEvent.change(textArea, { target: { value: 'Test answer' } });
      }
      
      fireEvent.click(screen.getByText('Submit Answer'));
      
      await waitFor(() => {
        expect(screen.getByText('Next Question')).toBeInTheDocument();
      });
      
      fireEvent.click(screen.getByText('Next Question'));
      
      // Small delay to allow state updates
      await new Promise(resolve => setTimeout(resolve, 100));
    }
    
    // After all questions, assessment should be complete
    // This test verifies that we don't loop back to question 1
    expect(screen.queryByText(/If x \+ 5 = 12/)).not.toBeInTheDocument();
  });
});