import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Slider } from "@/components/ui/slider";
import { 
  Brain, 
  Zap,
  Target,
  Star,
  TrendingUp,
  Globe,
  Award,
  BookOpen,
  Lightbulb,
  Rocket,
  Crown,
  Trophy,
  Users,
  ArrowRight,
  CheckCircle,
  Clock,
  BarChart3,
  Sparkles
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { motion, AnimatePresence } from "framer-motion";

interface CognitiveProfile {
  verbal: number;
  mathematical: number;
  spatial: number;
  logical: number;
  memory: number;
  processing: number;
  creativity: number;
  leadership: number;
}

interface RoleModel {
  id: string;
  name: string;
  title: string;
  field: string;
  avatar: string;
  eiqScore: number;
  cognitiveProfile: CognitiveProfile;
  achievements: string[];
  matchScore: number;
  keyTraits: string[];
  learningPath: LearningStep[];
  timelineYears: number;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced' | 'Expert';
  description: string;
  quote: string;
}

interface LearningStep {
  id: string;
  title: string;
  description: string;
  timeframe: string;
  skills: string[];
  resources: string[];
  milestone: string;
  completed: boolean;
  difficulty: number;
  priority: 'High' | 'Medium' | 'Low';
}

const ROLE_MODELS: RoleModel[] = [
  {
    id: "einstein",
    name: "Albert Einstein",
    title: "Theoretical Physicist",
    field: "Physics & Mathematics",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=einstein",
    eiqScore: 850,
    cognitiveProfile: {
      verbal: 92,
      mathematical: 98,
      spatial: 96,
      logical: 95,
      memory: 88,
      processing: 89,
      creativity: 97,
      leadership: 85
    },
    achievements: ["Theory of Relativity", "Nobel Prize in Physics", "E=mc²", "Quantum Theory"],
    matchScore: 94,
    keyTraits: ["Abstract Thinking", "Mathematical Intuition", "Creative Problem Solving", "Pattern Recognition"],
    learningPath: [
      {
        id: "step1",
        title: "Master Advanced Mathematics",
        description: "Build strong foundation in calculus, linear algebra, and differential equations",
        timeframe: "6-12 months",
        skills: ["Calculus", "Linear Algebra", "Differential Equations", "Complex Analysis"],
        resources: ["Khan Academy Advanced Math", "MIT OpenCourseWare", "Wolfram Alpha"],
        milestone: "Complete advanced calculus course with 90%+ grade",
        completed: false,
        difficulty: 8,
        priority: "High"
      },
      {
        id: "step2", 
        title: "Study Theoretical Physics",
        description: "Dive deep into classical mechanics, electromagnetism, and thermodynamics",
        timeframe: "12-18 months",
        skills: ["Classical Mechanics", "Electromagnetism", "Thermodynamics", "Wave Theory"],
        resources: ["Feynman Lectures", "Griffiths Physics", "Physics Forums"],
        milestone: "Solve 100+ advanced physics problems",
        completed: false,
        difficulty: 9,
        priority: "High"
      },
      {
        id: "step3",
        title: "Develop Research Skills",
        description: "Learn to conduct original research and formulate hypotheses",
        timeframe: "6-9 months",
        skills: ["Research Methodology", "Hypothesis Formation", "Data Analysis", "Scientific Writing"],
        resources: ["Research University Programs", "Scientific Journals", "Academic Mentors"],
        milestone: "Publish first research paper",
        completed: false,
        difficulty: 7,
        priority: "Medium"
      }
    ],
    timelineYears: 8,
    difficulty: "Expert",
    description: "Known for revolutionary theories that changed our understanding of space, time, and reality itself.",
    quote: "Imagination is more important than knowledge. Knowledge is limited; imagination embraces the entire world."
  },
  {
    id: "curie",
    name: "Marie Curie",
    title: "Physicist & Chemist",
    field: "Chemistry & Physics",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=curie",
    eiqScore: 825,
    cognitiveProfile: {
      verbal: 89,
      mathematical: 91,
      spatial: 85,
      logical: 94,
      memory: 92,
      processing: 88,
      creativity: 86,
      leadership: 90
    },
    achievements: ["Two Nobel Prizes", "Discovered Polonium & Radium", "Pioneered Radioactivity Research"],
    matchScore: 87,
    keyTraits: ["Persistence", "Analytical Thinking", "Experimental Design", "Scientific Rigor"],
    learningPath: [
      {
        id: "step1",
        title: "Chemistry Fundamentals",
        description: "Master atomic theory, chemical bonding, and periodic trends",
        timeframe: "4-6 months",
        skills: ["Atomic Structure", "Chemical Bonding", "Periodic Table", "Stoichiometry"],
        resources: ["Chemistry Textbooks", "Lab Experiments", "Online Simulations"],
        milestone: "Score 95%+ on comprehensive chemistry exam",
        completed: false,
        difficulty: 6,
        priority: "High"
      },
      {
        id: "step2",
        title: "Advanced Laboratory Techniques",
        description: "Learn precision measurement and experimental methodology",
        timeframe: "6-8 months",
        skills: ["Lab Safety", "Precision Measurement", "Data Collection", "Error Analysis"],
        resources: ["University Labs", "Research Internships", "Scientific Equipment"],
        milestone: "Complete 50+ precise chemical analyses",
        completed: false,
        difficulty: 7,
        priority: "High"
      }
    ],
    timelineYears: 6,
    difficulty: "Advanced",
    description: "Groundbreaking scientist who opened new fields of study and broke gender barriers in science.",
    quote: "Nothing in life is to be feared, it is only to be understood."
  },
  {
    id: "jobs",
    name: "Steve Jobs",
    title: "Technology Innovator",
    field: "Technology & Design",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=jobs", 
    eiqScore: 790,
    cognitiveProfile: {
      verbal: 94,
      mathematical: 78,
      spatial: 92,
      logical: 88,
      memory: 85,
      processing: 89,
      creativity: 96,
      leadership: 95
    },
    achievements: ["Co-founded Apple", "iPhone Revolution", "Pixar Animation", "Design Philosophy"],
    matchScore: 82,
    keyTraits: ["Visionary Thinking", "Design Intuition", "Strategic Leadership", "Innovation Drive"],
    learningPath: [
      {
        id: "step1",
        title: "Design Thinking Mastery",
        description: "Develop user-centered design and aesthetic sensibility",
        timeframe: "3-4 months",
        skills: ["User Experience", "Visual Design", "Prototyping", "Design Psychology"],
        resources: ["Design Courses", "Portfolio Projects", "User Research"],
        milestone: "Create award-winning product design",
        completed: false,
        difficulty: 6,
        priority: "High"
      },
      {
        id: "step2",
        title: "Technology Business Strategy",
        description: "Learn to identify market opportunities and build technology companies",
        timeframe: "8-12 months",
        skills: ["Market Analysis", "Product Strategy", "Team Building", "Brand Development"],
        resources: ["Business Cases", "Startup Accelerators", "Industry Reports"],
        milestone: "Launch successful technology product",
        completed: false,
        difficulty: 8,
        priority: "High"
      }
    ],
    timelineYears: 5,
    difficulty: "Advanced",
    description: "Revolutionary leader who transformed multiple industries through innovative design and technology.",
    quote: "Innovation distinguishes between a leader and a follower."
  },
  {
    id: "kalam",
    name: "A.P.J. Abdul Kalam",
    title: "Aerospace Engineer & President",
    field: "Aerospace Engineering",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=kalam",
    eiqScore: 810,
    cognitiveProfile: {
      verbal: 91,
      mathematical: 94,
      spatial: 96,
      logical: 92,
      memory: 89,
      processing: 88,
      creativity: 87,
      leadership: 93
    },
    achievements: ["India's Missile Program", "President of India", "People's President", "Space Technology"],
    matchScore: 89,
    keyTraits: ["Systematic Thinking", "Engineering Excellence", "Public Service", "Educational Vision"],
    learningPath: [
      {
        id: "step1",
        title: "Engineering Fundamentals",
        description: "Master mechanical and aerospace engineering principles",
        timeframe: "12-18 months",
        skills: ["Mechanics", "Thermodynamics", "Fluid Dynamics", "Materials Science"],
        resources: ["Engineering Textbooks", "CAD Software", "Simulation Tools"],
        milestone: "Design and build working aircraft model",
        completed: false,
        difficulty: 7,
        priority: "High"
      },
      {
        id: "step2",
        title: "Project Leadership",
        description: "Learn to manage complex technical projects and teams",
        timeframe: "6-9 months",
        skills: ["Project Management", "Team Leadership", "Technical Communication", "Quality Control"],
        resources: ["Leadership Programs", "Technical Projects", "Mentorship"],
        milestone: "Successfully lead technical team of 10+ people",
        completed: false,
        difficulty: 6,
        priority: "Medium"
      }
    ],
    timelineYears: 7,
    difficulty: "Advanced",
    description: "Visionary engineer and leader who combined technical excellence with dedication to education and public service.",
    quote: "Dream, dream, dream. Dreams transform into thoughts and thoughts result in action."
  }
];

export default function EnhancedRoleModelMatching() {
  const { toast } = useToast();
  const [userProfile, setUserProfile] = useState<CognitiveProfile>({
    verbal: 75,
    mathematical: 82,
    spatial: 78,
    logical: 85,
    memory: 73,
    processing: 80,
    creativity: 88,
    leadership: 70
  });
  const [selectedModel, setSelectedModel] = useState<RoleModel | null>(null);
  const [matchingMode, setMatchingMode] = useState<'ml' | 'rules'>('ml');
  const [showPathway, setShowPathway] = useState(false);
  const [completedSteps, setCompletedSteps] = useState<Set<string>>(new Set());

  // Calculate ML-based matching score
  const calculateMLMatchScore = (model: RoleModel): number => {
    const weights = {
      verbal: 0.15,
      mathematical: 0.20,
      spatial: 0.15,
      logical: 0.20,
      memory: 0.10,
      processing: 0.10,
      creativity: 0.05,
      leadership: 0.05
    };

    let totalScore = 0;
    let totalWeight = 0;

    Object.entries(weights).forEach(([key, weight]) => {
      const userScore = userProfile[key as keyof CognitiveProfile];
      const modelScore = model.cognitiveProfile[key as keyof CognitiveProfile];
      
      // Cosine similarity with penalty for large differences
      const similarity = 1 - Math.abs(userScore - modelScore) / 100;
      const adjustedSimilarity = Math.pow(similarity, 1.5); // Emphasize closer matches
      
      totalScore += adjustedSimilarity * weight * 100;
      totalWeight += weight;
    });

    return Math.round(totalScore / totalWeight);
  };

  // Calculate rules-based matching score
  const calculateRulesMatchScore = (model: RoleModel): number => {
    const strengthThreshold = 80;
    const userStrengths = Object.entries(userProfile)
      .filter(([_, score]) => score >= strengthThreshold)
      .map(([domain, _]) => domain);

    const modelStrengths = Object.entries(model.cognitiveProfile)
      .filter(([_, score]) => score >= strengthThreshold)
      .map(([domain, _]) => domain);

    const commonStrengths = userStrengths.filter(strength => 
      modelStrengths.includes(strength)
    );

    const baseScore = (commonStrengths.length / Math.max(userStrengths.length, 1)) * 70;
    const profileSimilarity = calculateMLMatchScore(model) * 0.3;
    
    return Math.round(baseScore + profileSimilarity);
  };

  const getMatchedModels = () => {
    return ROLE_MODELS.map(model => ({
      ...model,
      matchScore: matchingMode === 'ml' 
        ? calculateMLMatchScore(model)
        : calculateRulesMatchScore(model)
    })).sort((a, b) => b.matchScore - a.matchScore);
  };

  const toggleStepCompletion = (stepId: string) => {
    const newCompleted = new Set(completedSteps);
    if (newCompleted.has(stepId)) {
      newCompleted.delete(stepId);
    } else {
      newCompleted.add(stepId);
      toast({
        title: "Step Completed!",
        description: "Great progress on your learning pathway!"
      });
    }
    setCompletedSteps(newCompleted);
  };

  const generatePersonalizedPath = (model: RoleModel) => {
    const userWeaknesses = Object.entries(userProfile)
      .filter(([_, score]) => score < 75)
      .map(([domain, _]) => domain);

    const modelStrengths = Object.entries(model.cognitiveProfile)
      .filter(([_, score]) => score >= 85)
      .map(([domain, _]) => domain);

    const focusAreas = Array.from(new Set([...userWeaknesses, ...modelStrengths]));
    
    return model.learningPath.map(step => ({
      ...step,
      priority: focusAreas.some(area => 
        step.skills.some(skill => 
          skill.toLowerCase().includes(area.toLowerCase())
        )
      ) ? 'High' : step.priority
    }));
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Beginner': return 'text-green-600 bg-green-100 dark:bg-green-900 dark:text-green-200';
      case 'Intermediate': return 'text-blue-600 bg-blue-100 dark:bg-blue-900 dark:text-blue-200';
      case 'Advanced': return 'text-orange-600 bg-orange-100 dark:bg-orange-900 dark:text-orange-200';
      case 'Expert': return 'text-red-600 bg-red-100 dark:bg-red-900 dark:text-red-200';
      default: return 'text-gray-600 bg-gray-100 dark:bg-gray-900 dark:text-gray-200';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'High': return 'text-red-600 bg-red-100 dark:bg-red-900 dark:text-red-200';
      case 'Medium': return 'text-yellow-600 bg-yellow-100 dark:bg-yellow-900 dark:text-yellow-200';
      case 'Low': return 'text-green-600 bg-green-100 dark:bg-green-900 dark:text-green-200';
      default: return 'text-gray-600 bg-gray-100 dark:bg-gray-900 dark:text-gray-200';
    }
  };

  const matchedModels = getMatchedModels();

  return (
    <div className="min-h-screen bg-gradient-to-br from-violet-50 to-purple-100 dark:from-slate-900 dark:to-slate-800 p-6">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="text-center space-y-4">
          <h1 className="text-4xl font-bold text-slate-900 dark:text-white flex items-center justify-center space-x-3">
            <Sparkles className="w-8 h-8 text-purple-500" />
            <span>AI Role Model Matching & Pathways</span>
          </h1>
          <p className="text-xl text-slate-600 dark:text-slate-300 max-w-4xl mx-auto">
            Discover your cognitive twins among history's greatest minds. Get personalized learning pathways 
            powered by advanced ML algorithms and clear roadmaps to achieve your intellectual potential.
          </p>
        </div>

        <Tabs defaultValue="matching" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="matching">AI Matching</TabsTrigger>
            <TabsTrigger value="profile">Your Profile</TabsTrigger>
            <TabsTrigger value="pathways">Learning Paths</TabsTrigger>
            <TabsTrigger value="analytics">Progress Analytics</TabsTrigger>
          </TabsList>

          {/* AI Matching Tab */}
          <TabsContent value="matching" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center space-x-2">
                    <Brain className="w-5 h-5 text-purple-500" />
                    <span>Cognitive Matching Algorithm</span>
                  </CardTitle>
                  <div className="flex items-center space-x-2">
                    <Badge variant={matchingMode === 'ml' ? 'default' : 'outline'}>
                      ML-Based
                    </Badge>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setMatchingMode(matchingMode === 'ml' ? 'rules' : 'ml')}
                    >
                      Switch to {matchingMode === 'ml' ? 'Rules' : 'ML'} Mode
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                  {matchedModels.map((model) => (
                    <motion.div
                      key={model.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      whileHover={{ scale: 1.02 }}
                      className="h-full"
                    >
                      <Card className="h-full cursor-pointer hover:shadow-lg transition-shadow">
                        <CardContent className="pt-6">
                          <div className="space-y-4">
                            <div className="flex items-center space-x-3">
                              <Avatar className="w-16 h-16">
                                <AvatarImage src={model.avatar} />
                                <AvatarFallback>{model.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                              </Avatar>
                              <div className="flex-1">
                                <h3 className="font-bold text-lg">{model.name}</h3>
                                <p className="text-sm text-muted-foreground">{model.title}</p>
                                <Badge className={getDifficultyColor(model.difficulty)}>
                                  {model.difficulty}
                                </Badge>
                              </div>
                            </div>

                            <div className="space-y-2">
                              <div className="flex items-center justify-between">
                                <span className="text-sm font-medium">Match Score</span>
                                <Badge variant="secondary" className="font-bold">
                                  {model.matchScore}%
                                </Badge>
                              </div>
                              <Progress value={model.matchScore} className="h-2" />
                            </div>

                            <div className="space-y-2">
                              <p className="text-sm font-medium">Key Traits:</p>
                              <div className="flex flex-wrap gap-1">
                                {model.keyTraits.slice(0, 3).map((trait) => (
                                  <Badge key={trait} variant="outline" className="text-xs">
                                    {trait}
                                  </Badge>
                                ))}
                              </div>
                            </div>

                            <div className="space-y-2">
                              <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                                <Trophy className="w-4 h-4" />
                                <span>EIQ: {model.eiqScore}</span>
                              </div>
                              <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                                <Clock className="w-4 h-4" />
                                <span>{model.timelineYears} year pathway</span>
                              </div>
                            </div>

                            <blockquote className="italic text-sm text-muted-foreground border-l-2 border-purple-300 pl-2">
                              "{model.quote}"
                            </blockquote>

                            <Button 
                              onClick={() => {
                                setSelectedModel(model);
                                setShowPathway(true);
                              }}
                              className="w-full"
                            >
                              <ArrowRight className="w-4 h-4 mr-2" />
                              View Learning Path
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    </motion.div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Profile Tab */}
          <TabsContent value="profile" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <BarChart3 className="w-5 h-5 text-blue-500" />
                  <span>Your Cognitive Profile</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {Object.entries(userProfile).map(([domain, score]) => (
                    <div key={domain} className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="font-medium capitalize">{domain}</span>
                        <span className="font-bold">{score}</span>
                      </div>
                      <div className="space-y-1">
                        <Slider
                          value={[score]}
                          onValueChange={(value) => {
                            setUserProfile(prev => ({
                              ...prev,
                              [domain]: value[0]
                            }));
                          }}
                          max={100}
                          min={0}
                          step={1}
                          className="w-full"
                        />
                        <div className="flex justify-between text-xs text-muted-foreground">
                          <span>Beginner</span>
                          <span>Expert</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Learning Pathways Tab */}
          <TabsContent value="pathways" className="space-y-6">
            <AnimatePresence>
              {selectedModel && showPathway && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                >
                  <Card>
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <CardTitle className="flex items-center space-x-3">
                          <Avatar className="w-12 h-12">
                            <AvatarImage src={selectedModel.avatar} />
                            <AvatarFallback>{selectedModel.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                          </Avatar>
                          <div>
                            <span>Path to {selectedModel.name}</span>
                            <p className="text-sm text-muted-foreground font-normal">
                              {selectedModel.field} • {selectedModel.timelineYears} year journey
                            </p>
                          </div>
                        </CardTitle>
                        <Badge className={getDifficultyColor(selectedModel.difficulty)}>
                          {selectedModel.difficulty} Level
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-6">
                        {generatePersonalizedPath(selectedModel).map((step, index) => (
                          <Card key={step.id} className="relative">
                            <CardContent className="pt-6">
                              <div className="flex items-start space-x-4">
                                <div className="flex-shrink-0">
                                  <div className={`
                                    w-10 h-10 rounded-full border-4 flex items-center justify-center font-bold
                                    ${completedSteps.has(step.id) 
                                      ? 'bg-green-500 border-green-300 text-white' 
                                      : 'bg-white border-slate-300 text-slate-600 dark:bg-slate-700 dark:border-slate-600 dark:text-slate-300'
                                    }
                                  `}>
                                    {completedSteps.has(step.id) ? (
                                      <CheckCircle className="w-5 h-5" />
                                    ) : (
                                      <span>{index + 1}</span>
                                    )}
                                  </div>
                                  {index < generatePersonalizedPath(selectedModel).length - 1 && (
                                    <div className="w-1 h-16 bg-slate-200 dark:bg-slate-600 mx-auto mt-2" />
                                  )}
                                </div>
                                
                                <div className="flex-1 space-y-3">
                                  <div className="flex items-start justify-between">
                                    <div>
                                      <h3 className="font-bold text-lg">{step.title}</h3>
                                      <p className="text-muted-foreground">{step.description}</p>
                                    </div>
                                    <div className="flex space-x-2">
                                      <Badge className={getPriorityColor(step.priority)}>
                                        {step.priority}
                                      </Badge>
                                      <Badge variant="outline">
                                        Level {step.difficulty}
                                      </Badge>
                                    </div>
                                  </div>

                                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                                    <div>
                                      <p className="font-medium mb-1">⏱️ Timeframe</p>
                                      <p className="text-muted-foreground">{step.timeframe}</p>
                                    </div>
                                    <div>
                                      <p className="font-medium mb-1">🎯 Milestone</p>
                                      <p className="text-muted-foreground">{step.milestone}</p>
                                    </div>
                                    <div>
                                      <p className="font-medium mb-1">📚 Resources</p>
                                      <div className="space-y-1">
                                        {step.resources.slice(0, 2).map((resource) => (
                                          <Badge key={resource} variant="secondary" className="text-xs mr-1">
                                            {resource}
                                          </Badge>
                                        ))}
                                      </div>
                                    </div>
                                  </div>

                                  <div>
                                    <p className="font-medium mb-2">🧠 Skills to Develop</p>
                                    <div className="flex flex-wrap gap-1">
                                      {step.skills.map((skill) => (
                                        <Badge key={skill} variant="outline" className="text-xs">
                                          {skill}
                                        </Badge>
                                      ))}
                                    </div>
                                  </div>

                                  <div className="flex space-x-2">
                                    <Button
                                      onClick={() => toggleStepCompletion(step.id)}
                                      variant={completedSteps.has(step.id) ? "default" : "outline"}
                                      size="sm"
                                    >
                                      {completedSteps.has(step.id) ? "Completed" : "Mark Complete"}
                                    </Button>
                                    <Button variant="ghost" size="sm">
                                      <BookOpen className="w-4 h-4 mr-2" />
                                      Resources
                                    </Button>
                                  </div>
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              )}
            </AnimatePresence>
          </TabsContent>

          {/* Progress Analytics Tab */}
          <TabsContent value="analytics" className="space-y-6">
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Learning Progress</CardTitle>
                  <TrendingUp className="h-4 w-4 text-green-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {Math.round((completedSteps.size / (selectedModel?.learningPath.length || 1)) * 100)}%
                  </div>
                  <p className="text-xs text-muted-foreground">
                    {completedSteps.size} of {selectedModel?.learningPath.length || 0} steps completed
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Best Match Score</CardTitle>
                  <Star className="h-4 w-4 text-yellow-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{matchedModels[0]?.matchScore || 0}%</div>
                  <p className="text-xs text-muted-foreground">
                    with {matchedModels[0]?.name}
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Estimated Timeline</CardTitle>
                  <Clock className="h-4 w-4 text-blue-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {selectedModel?.timelineYears || 0}
                    <span className="text-sm font-normal"> years</span>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    to reach expert level
                  </p>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Cognitive Growth Projection</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64 bg-slate-100 dark:bg-slate-800 rounded-lg flex items-center justify-center">
                  <div className="text-center space-y-2">
                    <BarChart3 className="w-12 h-12 text-muted-foreground mx-auto" />
                    <p className="text-muted-foreground">Interactive growth chart showing projected cognitive development</p>
                    <Badge variant="outline">Based on IRT modeling & historical data</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}