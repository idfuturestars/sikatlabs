import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  BarChart3, 
  TrendingUp, 
  TrendingDown,
  Target,
  Brain,
  Zap,
  Clock,
  Award
} from "lucide-react";

export default function FICOScoring() {
  const eiqScore = 685;
  const scoreRange = { min: 300, max: 850 };
  const scoreLevel = eiqScore >= 700 ? "Elite" : eiqScore >= 600 ? "Excellent" : eiqScore >= 500 ? "Good" : "Developing";
  
  const scoreFactors = [
    {
      category: "Cognitive Assessment Performance",
      weight: 35,
      score: 92,
      trend: "up",
      description: "IQ, reasoning, and problem-solving abilities"
    },
    {
      category: "Learning Velocity",
      weight: 25,
      score: 88,
      trend: "up", 
      description: "Speed of knowledge acquisition and skill development"
    },
    {
      category: "Adaptive Intelligence",
      weight: 20,
      score: 85,
      trend: "stable",
      description: "Ability to adapt learning strategies and approaches"
    },
    {
      category: "Knowledge Retention",
      weight: 15,
      score: 79,
      trend: "down",
      description: "Long-term retention and application of learned concepts"
    },
    {
      category: "Meta-Learning Skills", 
      weight: 5,
      score: 94,
      trend: "up",
      description: "Learning how to learn effectively"
    }
  ];

  const monthlyTrends = [
    { month: "Jan", score: 645 },
    { month: "Feb", score: 658 },
    { month: "Mar", score: 662 },
    { month: "Apr", score: 671 },
    { month: "May", score: 679 },
    { month: "Jun", score: 685 },
  ];

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case "up":
        return <TrendingUp className="w-4 h-4 text-green-500" />;
      case "down":
        return <TrendingDown className="w-4 h-4 text-red-500" />;
      default:
        return <Target className="w-4 h-4 text-yellow-500" />;
    }
  };

  const getScoreColor = (score: number) => {
    if (score >= 700) return "text-purple-600";
    if (score >= 600) return "text-green-600";
    if (score >= 500) return "text-blue-600";
    return "text-orange-600";
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center gap-3">
        <BarChart3 className="w-8 h-8 text-primary" />
        <div>
          <h1 className="text-2xl font-bold">FICO-like EiQ™ Scoring Dashboard</h1>
          <p className="text-muted-foreground">Educational Intelligence Quotient scoring system (300-850 scale)</p>
        </div>
      </div>

      {/* Current Score Display */}
      <Card className="bg-gradient-to-r from-primary/10 to-purple-500/10">
        <CardHeader>
          <CardTitle className="text-center">Your Current EiQ™ Score</CardTitle>
        </CardHeader>
        <CardContent className="text-center space-y-4">
          <div className={`text-6xl font-bold ${getScoreColor(eiqScore)}`}>
            {eiqScore}
          </div>
          <Badge variant="secondary" className="text-lg px-4 py-2">
            {scoreLevel} Range
          </Badge>
          <div className="flex justify-between text-sm text-muted-foreground">
            <span>Poor (300-499)</span>
            <span>Good (500-599)</span>
            <span>Excellent (600-699)</span>
            <span>Elite (700-850)</span>
          </div>
          <Progress 
            value={((eiqScore - scoreRange.min) / (scoreRange.max - scoreRange.min)) * 100} 
            className="h-3"
          />
        </CardContent>
      </Card>

      {/* Score Factors Breakdown */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="w-5 h-5" />
            Score Factors Breakdown
          </CardTitle>
          <p className="text-muted-foreground">
            Weighted components that contribute to your overall EiQ™ score
          </p>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {scoreFactors.map((factor) => (
              <div key={factor.category} className="border rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <h4 className="font-medium">{factor.category}</h4>
                    {getTrendIcon(factor.trend)}
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-sm text-muted-foreground">{factor.weight}% weight</span>
                    <span className="font-bold text-lg">{factor.score}</span>
                  </div>
                </div>
                <p className="text-sm text-muted-foreground mb-3">{factor.description}</p>
                <Progress value={factor.score} className="h-2" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Score History */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5" />
            6-Month Score Trend
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-6 gap-4 text-center">
            {monthlyTrends.map((month) => (
              <div key={month.month} className="space-y-2">
                <div className="text-sm text-muted-foreground">{month.month}</div>
                <div className={`text-xl font-bold ${getScoreColor(month.score)}`}>
                  {month.score}
                </div>
                <div className="h-20 bg-muted rounded flex items-end">
                  <div 
                    className="w-full bg-primary rounded"
                    style={{ 
                      height: `${((month.score - 600) / 150) * 100}%`,
                      minHeight: '8px'
                    }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-4 p-4 bg-green-50 rounded-lg">
            <div className="flex items-center gap-2 text-green-700">
              <TrendingUp className="w-4 h-4" />
              <span className="font-medium">+40 points increase over 6 months</span>
            </div>
            <p className="text-sm text-green-600 mt-1">
              Excellent progress! You're on track to reach Elite status.
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Improvement Recommendations */}
      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Target className="w-5 h-5" />
              Score Improvement Actions
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="p-3 bg-red-50 rounded-lg">
                <h4 className="font-medium text-red-700">Priority: Knowledge Retention</h4>
                <p className="text-sm text-red-600">Score: 79 (-15% below average)</p>
                <p className="text-xs text-muted-foreground mt-1">
                  Focus on spaced repetition and active recall techniques
                </p>
              </div>
              <div className="p-3 bg-yellow-50 rounded-lg">
                <h4 className="font-medium text-yellow-700">Opportunity: Adaptive Intelligence</h4>
                <p className="text-sm text-yellow-600">Score: 85 (Room for growth)</p>
                <p className="text-xs text-muted-foreground mt-1">
                  Practice switching between different learning strategies
                </p>
              </div>
              <div className="p-3 bg-green-50 rounded-lg">
                <h4 className="font-medium text-green-700">Strength: Meta-Learning</h4>
                <p className="text-sm text-green-600">Score: 94 (Top 5%)</p>
                <p className="text-xs text-muted-foreground mt-1">
                  Continue leveraging your learning strategy skills
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Award className="w-5 h-5" />
              Score Milestones
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-3 bg-muted/50 rounded">
                <span>Reach Elite Status (700+)</span>
                <Badge variant="outline">15 points to go</Badge>
              </div>
              <div className="flex items-center justify-between p-3 bg-green-50 rounded">
                <span>Excellent Range Achieved ✓</span>
                <Badge className="bg-green-100 text-green-800">Completed</Badge>
              </div>
              <div className="flex items-center justify-between p-3 bg-green-50 rounded">
                <span>Good Range Achieved ✓</span>
                <Badge className="bg-green-100 text-green-800">Completed</Badge>
              </div>
              
              <div className="mt-4">
                <h4 className="font-medium mb-2">Projected Timeline</h4>
                <div className="text-sm text-muted-foreground space-y-1">
                  <div>• Elite status (700+): 2-3 months at current pace</div>
                  <div>• Peak performance (750+): 6-8 months</div>
                  <div>• Top percentile (800+): 12+ months</div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}