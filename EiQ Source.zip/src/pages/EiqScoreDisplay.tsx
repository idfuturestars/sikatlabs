/**
 * EiQ™ Score Display Component
 * Comprehensive FICO-like 300-850 EiQ™ score visualization with detailed breakdowns
 */

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  TrendingUp, 
  TrendingDown, 
  Brain, 
  Target, 
  Calendar, 
  Award,
  BarChart3,
  Star,
  Clock,
  CheckCircle,
  AlertCircle,
  BookOpen,
  Lightbulb
} from 'lucide-react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

interface EiqScoreData {
  scoreId: string;
  overallEiq: number;
  components: {
    traditionalIq: number;
    emotionalIq: number;
    alternativeIq: number;
    strategicIq: number;
    technicalIq: number;
    creativeIq: number;
    socialIq: number;
    adaptabilityIq: number;
  };
  combinedScore: number;
  accuracy: number;
  scoreBreakdown: {
    rawScore: number;
    scaledScore: number;
    percentile: number;
    gradeEquivalent: string;
  };
  recommendations: string[];
  improvementAreas: string[];
  strengths: string[];
  nextTestDate: string;
  improvement?: {
    previousScore?: number;
    currentScore: number;
    pointChange: number;
    percentageChange: string;
  };
  createdAt: string;
}

interface ScoreHistory {
  scores: EiqScoreData[];
  trends: {
    trend: string;
    message: string;
    averageImprovement: number;
    improvementRatio: number;
    dataPoints: number;
  };
  summary: {
    totalTests: number;
    averageScore: number;
    bestScore: number;
    totalImprovement: number;
  };
}

const getScoreBand = (score: number) => {
  if (score >= 800) return { 
    level: 'Exceptional', 
    description: 'Outstanding educational intelligence', 
    color: 'text-purple-600 dark:text-purple-400',
    bgColor: 'bg-purple-50 dark:bg-purple-900/20',
    range: '800-850'
  };
  if (score >= 740) return { 
    level: 'Excellent', 
    description: 'Very high educational intelligence', 
    color: 'text-blue-600 dark:text-blue-400',
    bgColor: 'bg-blue-50 dark:bg-blue-900/20',
    range: '740-799'
  };
  if (score >= 670) return { 
    level: 'Good', 
    description: 'Above average educational intelligence', 
    color: 'text-green-600 dark:text-green-400',
    bgColor: 'bg-green-50 dark:bg-green-900/20',
    range: '670-739'
  };
  if (score >= 580) return { 
    level: 'Fair', 
    description: 'Average educational intelligence', 
    color: 'text-yellow-600 dark:text-yellow-400',
    bgColor: 'bg-yellow-50 dark:bg-yellow-900/20',
    range: '580-669'
  };
  return { 
    level: 'Poor', 
    description: 'Below average educational intelligence', 
    color: 'text-red-600 dark:text-red-400',
    bgColor: 'bg-red-50 dark:bg-red-900/20',
    range: '300-579'
  };
};

const getComponentName = (key: string): string => {
  const names: Record<string, string> = {
    traditionalIq: 'Traditional Intelligence',
    emotionalIq: 'Emotional Intelligence',
    alternativeIq: 'Alternative Thinking',
    strategicIq: 'Strategic Thinking',
    technicalIq: 'Technical Problem Solving',
    creativeIq: 'Creative Thinking',
    socialIq: 'Social Intelligence',
    adaptabilityIq: 'Adaptability'
  };
  return names[key] || key;
};

export default function EiqScoreDisplay() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedTab, setSelectedTab] = useState('overview');

  // Get current EiQ score
  const { 
    data: currentScore, 
    isLoading: isLoadingCurrent, 
    error: currentError 
  } = useQuery<{ success: boolean; data: EiqScoreData }>({
    queryKey: ['/api/eiq/scoring/current'],
    retry: false
  });

  // Get EiQ score history
  const { 
    data: scoreHistory, 
    isLoading: isLoadingHistory 
  } = useQuery<{ success: boolean; data: ScoreHistory }>({
    queryKey: ['/api/eiq/scoring/history'],
    retry: false
  });

  if (isLoadingCurrent) {
    return (
      <div className="min-h-screen bg-background">
        <div className="container mx-auto py-8">
          <div className="flex items-center justify-center h-64">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          </div>
        </div>
      </div>
    );
  }

  if (currentError || !currentScore?.success || !currentScore?.data) {
    return (
      <div className="min-h-screen bg-background">
        <div className="container mx-auto py-8">
          <Alert className="max-w-md mx-auto">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              No EiQ scores found. Complete an assessment to get your first EiQ score.
            </AlertDescription>
          </Alert>
          <div className="text-center mt-6">
            <Button onClick={() => window.location.href = '/assessment-center'}>
              Take Assessment
            </Button>
          </div>
        </div>
      </div>
    );
  }

  const score = currentScore.data;
  const scoreBand = getScoreBand(score.overallEiq);
  const history = scoreHistory?.data;

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto py-8 space-y-6">
        
        {/* Header Section */}
        <div className="text-center space-y-4">
          <h1 className="text-4xl font-bold gradient-text">Your EiQ™ Score</h1>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Educational Intelligence Quotient - FICO-like scoring from 300-850 measuring your complete intellectual capacity
          </p>
        </div>

        {/* Main Score Display */}
        <Card className="max-w-4xl mx-auto">
          <CardHeader className="text-center">
            <div className="space-y-4">
              <div className={`inline-block px-6 py-3 rounded-full ${scoreBand.bgColor}`}>
                <div className="text-6xl font-bold mb-2">{score.overallEiq}</div>
                <Badge variant="secondary" className={`${scoreBand.color} text-sm font-medium`}>
                  {scoreBand.level} ({scoreBand.range})
                </Badge>
              </div>
              <div className="space-y-1">
                <p className="text-lg text-muted-foreground">{scoreBand.description}</p>
                <p className="text-sm text-muted-foreground">
                  {score.scoreBreakdown.percentile}th percentile • Grade equivalent: {score.scoreBreakdown.gradeEquivalent}
                </p>
              </div>
              
              {/* Progress Bar */}
              <div className="max-w-md mx-auto space-y-2">
                <Progress value={(score.overallEiq - 300) / 550 * 100} className="h-2" />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>300</span>
                  <span>575</span>
                  <span>850</span>
                </div>
              </div>

              {/* Improvement Display */}
              {score.improvement && score.improvement.previousScore && (
                <div className="flex items-center justify-center gap-2 text-sm">
                  {score.improvement.pointChange > 0 ? (
                    <TrendingUp className="h-4 w-4 text-green-500" />
                  ) : (
                    <TrendingDown className="h-4 w-4 text-red-500" />
                  )}
                  <span className={score.improvement.pointChange > 0 ? 'text-green-600' : 'text-red-600'}>
                    {score.improvement.pointChange > 0 ? '+' : ''}{score.improvement.pointChange} points 
                    ({score.improvement.percentageChange}%) from last test
                  </span>
                </div>
              )}
            </div>
          </CardHeader>

          <CardContent>
            <Tabs value={selectedTab} onValueChange={setSelectedTab} className="w-full">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="components">Components</TabsTrigger>
                <TabsTrigger value="recommendations">Insights</TabsTrigger>
                <TabsTrigger value="history">History</TabsTrigger>
              </TabsList>

              {/* Overview Tab */}
              <TabsContent value="overview" className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm font-medium flex items-center gap-2">
                        <Target className="h-4 w-4" />
                        Performance Metrics
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">Accuracy</span>
                        <span className="font-medium">{Math.round(score.accuracy * 100)}%</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">Combined Score</span>
                        <span className="font-medium">{score.combinedScore}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">Raw Score</span>
                        <span className="font-medium">{score.scoreBreakdown.rawScore}</span>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm font-medium flex items-center gap-2">
                        <Calendar className="h-4 w-4" />
                        Test Information
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">Test Date</span>
                        <span className="font-medium">
                          {new Date(score.createdAt).toLocaleDateString()}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">Next Test</span>
                        <span className="font-medium">
                          {new Date(score.nextTestDate).toLocaleDateString()}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">Retest Eligible</span>
                        <span className="font-medium">
                          {new Date() >= new Date(score.nextTestDate) ? (
                            <CheckCircle className="h-4 w-4 text-green-500" />
                          ) : (
                            <Clock className="h-4 w-4 text-yellow-500" />
                          )}
                        </span>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Strengths and Areas for Improvement */}
                <div className="grid md:grid-cols-2 gap-4">
                  {score.strengths.length > 0 && (
                    <Card>
                      <CardHeader className="pb-3">
                        <CardTitle className="text-sm font-medium flex items-center gap-2 text-green-600">
                          <Award className="h-4 w-4" />
                          Your Strengths
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-2">
                          {score.strengths.map((strength, index) => (
                            <div key={index} className="flex items-center gap-2">
                              <Star className="h-3 w-3 text-green-500" />
                              <span className="text-sm">{strength}</span>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  )}

                  {score.improvementAreas.length > 0 && (
                    <Card>
                      <CardHeader className="pb-3">
                        <CardTitle className="text-sm font-medium flex items-center gap-2 text-orange-600">
                          <Target className="h-4 w-4" />
                          Growth Areas
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-2">
                          {score.improvementAreas.map((area, index) => (
                            <div key={index} className="flex items-center gap-2">
                              <TrendingUp className="h-3 w-3 text-orange-500" />
                              <span className="text-sm">{area}</span>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  )}
                </div>
              </TabsContent>

              {/* Components Tab */}
              <TabsContent value="components" className="space-y-4">
                <div className="grid gap-3">
                  {Object.entries(score.components).map(([key, value]) => {
                    const componentName = getComponentName(key);
                    const isStrength = value >= 115;
                    const needsImprovement = value < 95;
                    
                    return (
                      <Card key={key}>
                        <CardContent className="pt-4">
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center gap-2">
                              <Brain className="h-4 w-4 text-primary" />
                              <span className="font-medium">{componentName}</span>
                              {isStrength && <Star className="h-3 w-3 text-yellow-500" />}
                              {needsImprovement && <Target className="h-3 w-3 text-orange-500" />}
                            </div>
                            <div className="text-right">
                              <div className="font-bold text-lg">{value}</div>
                              <div className="text-xs text-muted-foreground">
                                {isStrength ? 'Strength' : needsImprovement ? 'Growth Area' : 'Average'}
                              </div>
                            </div>
                          </div>
                          <Progress value={((value - 70) / 100) * 100} className="h-1" />
                          <div className="flex justify-between text-xs text-muted-foreground mt-1">
                            <span>70</span>
                            <span>100</span>
                            <span>130</span>
                            <span>170</span>
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </TabsContent>

              {/* Recommendations Tab */}
              <TabsContent value="recommendations" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Lightbulb className="h-5 w-5" />
                      Personalized Recommendations
                    </CardTitle>
                    <CardDescription>
                      AI-powered insights to improve your EiQ score
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {score.recommendations.map((recommendation, index) => (
                        <div key={index} className="flex items-start gap-3 p-3 rounded-lg bg-muted/50">
                          <BookOpen className="h-4 w-4 text-primary mt-0.5" />
                          <span className="text-sm">{recommendation}</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <div className="text-center">
                  <Button 
                    onClick={() => window.location.href = '/assessment-center'}
                    disabled={new Date() < new Date(score.nextTestDate)}
                  >
                    {new Date() >= new Date(score.nextTestDate) ? (
                      'Take New Assessment'
                    ) : (
                      `Next Test Available ${new Date(score.nextTestDate).toLocaleDateString()}`
                    )}
                  </Button>
                </div>
              </TabsContent>

              {/* History Tab */}
              <TabsContent value="history" className="space-y-4">
                {isLoadingHistory ? (
                  <div className="text-center py-8">
                    <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary mx-auto"></div>
                  </div>
                ) : history ? (
                  <>
                    {/* Trends Summary */}
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          <BarChart3 className="h-5 w-5" />
                          Performance Trends
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="grid md:grid-cols-4 gap-4 text-center">
                          <div>
                            <div className="text-2xl font-bold">{history.summary.totalTests}</div>
                            <div className="text-sm text-muted-foreground">Total Tests</div>
                          </div>
                          <div>
                            <div className="text-2xl font-bold">{history.summary.averageScore}</div>
                            <div className="text-sm text-muted-foreground">Average Score</div>
                          </div>
                          <div>
                            <div className="text-2xl font-bold">{history.summary.bestScore}</div>
                            <div className="text-sm text-muted-foreground">Best Score</div>
                          </div>
                          <div>
                            <div className={`text-2xl font-bold ${history.summary.totalImprovement > 0 ? 'text-green-600' : 'text-red-600'}`}>
                              {history.summary.totalImprovement > 0 ? '+' : ''}{history.summary.totalImprovement}
                            </div>
                            <div className="text-sm text-muted-foreground">Total Improvement</div>
                          </div>
                        </div>
                        
                        <div className="mt-4 p-3 rounded-lg bg-muted/50">
                          <div className="flex items-center gap-2 mb-1">
                            {history.trends.trend === 'improving' || history.trends.trend === 'strong_improvement' ? (
                              <TrendingUp className="h-4 w-4 text-green-500" />
                            ) : history.trends.trend === 'declining' ? (
                              <TrendingDown className="h-4 w-4 text-red-500" />
                            ) : (
                              <BarChart3 className="h-4 w-4 text-blue-500" />
                            )}
                            <span className="font-medium">Trend Analysis</span>
                          </div>
                          <p className="text-sm text-muted-foreground">{history.trends.message}</p>
                        </div>
                      </CardContent>
                    </Card>

                    {/* Score History */}
                    <Card>
                      <CardHeader>
                        <CardTitle>Recent Scores</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-3">
                          {history.scores.map((historicalScore, index) => (
                            <div key={historicalScore.scoreId} className="flex items-center justify-between p-3 rounded-lg border">
                              <div>
                                <div className="font-medium">{historicalScore.overallEiq}</div>
                                <div className="text-sm text-muted-foreground">
                                  {new Date(historicalScore.createdAt).toLocaleDateString()}
                                </div>
                              </div>
                              <div className="text-right">
                                {historicalScore.improvement !== null && historicalScore.improvement !== undefined && index > 0 && (
                                  <div className={`text-sm flex items-center gap-1 ${
                                    historicalScore.improvement.pointChange > 0 ? 'text-green-600' : 'text-red-600'
                                  }`}>
                                    {historicalScore.improvement.pointChange > 0 ? (
                                      <TrendingUp className="h-3 w-3" />
                                    ) : (
                                      <TrendingDown className="h-3 w-3" />
                                    )}
                                    {historicalScore.improvement.pointChange > 0 ? '+' : ''}{historicalScore.improvement.pointChange}
                                  </div>
                                )}
                                <div className="text-xs text-muted-foreground">
                                  {Math.round(historicalScore.accuracy * 100)}% accuracy
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  </>
                ) : (
                  <div className="text-center py-8 text-muted-foreground">
                    <BarChart3 className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>Complete more assessments to see your progress history</p>
                  </div>
                )}
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}