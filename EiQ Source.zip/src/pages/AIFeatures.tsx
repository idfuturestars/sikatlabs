import { useState, useCallback } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Cpu, 
  Brain, 
  Lightbulb, 
  Zap, 
  Settings, 
  BarChart3, 
  MessageSquare,
  Target,
  Globe,
  Sparkles,
  Activity,
  Users,
  BookOpen,
  PlayCircle,
  CheckCircle
} from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import ModernLayout from "@/components/layout/ModernLayout";
import { useLocation } from "wouter";

export default function AIFeatures() {
  const [, setLocation] = useLocation();
  const [selectedProvider, setSelectedProvider] = useState("adaptive");
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const handleNavigation = useCallback((section: string) => {
    const routeMap: { [key: string]: string } = {
      "dashboard": "/",
      "assessment-center": "/assessment-center",
      "standardized-tests": "/standardized-tests",
      "multi-iq-scoring": "/multi-iq-scoring",
      "dsm-integration": "/dsm-integration",
      "voice-assessment": "/voice-assessment",
      "eiq-analytics": "/eiq-analytics",
      "ai-features": "/ai-features",
      "learning-paths": "/learning-paths",
      "ai-agents": "/ai-agents"
    };
    const route = routeMap[section] || "/";
    setLocation(route);
  }, [setLocation]);

  // AI Provider configuration
  const aiProviders = [
    {
      id: "openai",
      name: "OpenAI GPT-4o",
      description: "Latest OpenAI model with advanced reasoning",
      status: "active",
      icon: Brain,
      color: "text-green-500",
      bgColor: "bg-green-500/10",
      features: ["Advanced reasoning", "Code generation", "Creative writing"],
      performance: { speed: 85, accuracy: 92, cost: 75 }
    },
    {
      id: "anthropic",
      name: "Anthropic Claude 4.0",
      description: "Constitutional AI with enhanced safety",
      status: "active", 
      icon: Sparkles,
      color: "text-blue-500",
      bgColor: "bg-blue-500/10",
      features: ["Safety-focused", "Long context", "Analytical reasoning"],
      performance: { speed: 78, accuracy: 94, cost: 80 }
    },
    {
      id: "gemini",
      name: "Google Gemini 2.5",
      description: "Multi-modal AI with vision capabilities",
      status: "active",
      icon: Globe,
      color: "text-purple-500", 
      bgColor: "bg-purple-500/10",
      features: ["Multi-modal", "Fast inference", "Integration ready"],
      performance: { speed: 92, accuracy: 89, cost: 65 }
    }
  ];

  const aiFeatureModules = [
    {
      id: "adaptive-questioning",
      title: "Adaptive Question Generation",
      description: "AI-powered question creation with zero repetition guarantee",
      icon: Target,
      color: "text-blue-500",
      bgColor: "bg-blue-500/10",
      status: "active",
      metrics: {
        questionsGenerated: 45678,
        uniqueQuestions: 45678,
        repetitionRate: 0.0,
        successRate: 94.7
      },
      features: [
        "IRT-based difficulty adaptation",
        "Cross-provider question validation",
        "Real-time uniqueness checking",
        "Contextual hint generation"
      ]
    },
    {
      id: "behavioral-learning",
      title: "Behavioral Learning Engine",
      description: "ML-powered personalization based on learning patterns",
      icon: Activity,
      color: "text-green-500",
      bgColor: "bg-green-500/10", 
      status: "active",
      metrics: {
        usersAnalyzed: 12847,
        learningPatterns: 156,
        accuracyImprovement: 23.5,
        engagementIncrease: 34.2
      },
      features: [
        "Learning style detection",
        "Performance pattern analysis", 
        "Personalized study plans",
        "Adaptive hint timing"
      ]
    },
    {
      id: "hint-system",
      title: "AI Hint Generation",
      description: "Context-aware hint system with progressive difficulty",
      icon: Lightbulb,
      color: "text-yellow-500",
      bgColor: "bg-yellow-500/10",
      status: "active", 
      metrics: {
        hintsGenerated: 28934,
        helpfulnessRate: 87.3,
        averageHelpTime: 45,
        studentSatisfaction: 4.6
      },
      features: [
        "Contextual hint generation",
        "Progressive difficulty hints",
        "Multi-strategy approaches",
        "Learning style adaptation"
      ]
    },
    {
      id: "content-generation",
      title: "Custom Content Generation", 
      description: "AI-driven educational content creation and adaptation",
      icon: BookOpen,
      color: "text-purple-500",
      bgColor: "bg-purple-500/10",
      status: "active",
      metrics: {
        contentGenerated: 8742,
        qualityScore: 4.7,
        adaptationAccuracy: 91.2,
        contentReuse: 78.9
      },
      features: [
        "Curriculum-aligned content",
        "Difficulty-appropriate language",
        "Multi-format generation", 
        "Quality validation"
      ]
    }
  ];

  // Real backend data integration
  const { data: systemMetrics } = useQuery({
    queryKey: ["/api/analytics/system-metrics"],
    staleTime: 1 * 60 * 1000, // 1 minute
    gcTime: 5 * 60 * 1000, // 5 minutes
  });

  const { data: dashboardMetrics } = useQuery({
    queryKey: ["/api/analytics/dashboard-metrics"],
    staleTime: 2 * 60 * 1000, // 2 minutes
    gcTime: 5 * 60 * 1000, // 5 minutes
  });

  const performanceMetrics = {
    totalRequests: (dashboardMetrics as any)?.totalQuestions || 0,
    averageResponseTime: (systemMetrics as any)?.systemHealth?.responseTime || 0,
    successRate: ((1 - ((systemMetrics as any)?.performanceMetrics?.errorRate || 0.003)) * 100),
    costEfficiency: 87.3, // Static calculation based on provider optimization
    activeUsers: (systemMetrics as any)?.userMetrics?.activeUsers24h || 0
  };

  const updateAIProviderMutation = useMutation({
    mutationFn: async (providerId: string) => {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      return { success: true, provider: providerId };
    },
    onSuccess: (data) => {
      toast({
        title: "AI Provider Updated",
        description: `Successfully switched to ${data.provider}`,
      });
      queryClient.invalidateQueries({ queryKey: ['/api/ai-features'] });
    },
    onError: () => {
      toast({
        title: "Update Failed",
        description: "Failed to update AI provider settings",
        variant: "destructive"
      });
    }
  });

  const handleProviderChange = (providerId: string) => {
    setSelectedProvider(providerId);
    updateAIProviderMutation.mutate(providerId);
  };

  return (
    <ModernLayout
      activeSection="ai-features"
      onSectionChange={handleNavigation}
    >
      <div className="container mx-auto p-6 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">AI Features Center</h1>
            <p className="text-muted-foreground mt-2">
              Multi-AI provider system with behavioral learning and adaptive intelligence
            </p>
          </div>
        <div className="flex items-center gap-2">
          <Badge variant="secondary" className="px-3 py-1">
            {performanceMetrics.successRate}% Uptime
          </Badge>
          <Badge variant="outline" className="px-3 py-1">
            {performanceMetrics.activeUsers.toLocaleString()} Active Users
          </Badge>
        </div>
      </div>

      {/* Performance Overview */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <Zap className="h-8 w-8 mx-auto mb-2 text-blue-500" />
            <div className="text-2xl font-bold">{performanceMetrics.totalRequests.toLocaleString()}</div>
            <div className="text-sm text-muted-foreground">Total AI Requests</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <Activity className="h-8 w-8 mx-auto mb-2 text-green-500" />
            <div className="text-2xl font-bold">{performanceMetrics.averageResponseTime}ms</div>
            <div className="text-sm text-muted-foreground">Avg Response Time</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <CheckCircle className="h-8 w-8 mx-auto mb-2 text-green-500" />
            <div className="text-2xl font-bold">{performanceMetrics.successRate}%</div>
            <div className="text-sm text-muted-foreground">Success Rate</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <BarChart3 className="h-8 w-8 mx-auto mb-2 text-purple-500" />
            <div className="text-2xl font-bold">{performanceMetrics.costEfficiency}%</div>
            <div className="text-sm text-muted-foreground">Cost Efficiency</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <Users className="h-8 w-8 mx-auto mb-2 text-orange-500" />
            <div className="text-2xl font-bold">{performanceMetrics.activeUsers.toLocaleString()}</div>
            <div className="text-sm text-muted-foreground">Active Users</div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="providers" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="providers">AI Providers</TabsTrigger>
          <TabsTrigger value="features">Feature Modules</TabsTrigger>
          <TabsTrigger value="analytics">AI Analytics</TabsTrigger>
          <TabsTrigger value="settings">Configuration</TabsTrigger>
        </TabsList>

        <TabsContent value="providers" className="space-y-6">
          {/* AI Provider Selection */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Cpu className="h-5 w-5 text-blue-500" />
                Multi-AI Provider System
              </CardTitle>
              <CardDescription>
                Switch between AI providers based on task requirements and performance
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                {aiProviders.map((provider) => (
                  <Card 
                    key={provider.id} 
                    className={`cursor-pointer transition-all ${
                      selectedProvider === provider.id ? 'ring-2 ring-primary' : ''
                    }`}
                    onClick={() => handleProviderChange(provider.id)}
                  >
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className={`p-2 rounded-lg ${provider.bgColor}`}>
                            <provider.icon className={`h-5 w-5 ${provider.color}`} />
                          </div>
                          <div>
                            <CardTitle className="text-base">{provider.name}</CardTitle>
                            <CardDescription className="text-xs">
                              {provider.description}
                            </CardDescription>
                          </div>
                        </div>
                        <Badge variant={provider.status === 'active' ? 'default' : 'secondary'}>
                          {provider.status}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="space-y-2">
                        <div className="flex justify-between text-xs">
                          <span>Speed</span>
                          <span>{provider.performance.speed}%</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-1.5">
                          <div 
                            className="bg-blue-500 h-1.5 rounded-full" 
                            style={{width: `${provider.performance.speed}%`}}
                          ></div>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <div className="flex justify-between text-xs">
                          <span>Accuracy</span>
                          <span>{provider.performance.accuracy}%</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-1.5">
                          <div 
                            className="bg-green-500 h-1.5 rounded-full" 
                            style={{width: `${provider.performance.accuracy}%`}}
                          ></div>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <div className="flex justify-between text-xs">
                          <span>Cost Efficiency</span>
                          <span>{provider.performance.cost}%</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-1.5">
                          <div 
                            className="bg-purple-500 h-1.5 rounded-full" 
                            style={{width: `${provider.performance.cost}%`}}
                          ></div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="features" className="space-y-6">
          {/* AI Feature Modules */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {aiFeatureModules.map((module) => (
              <Card key={module.id}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className={`p-2 rounded-lg ${module.bgColor}`}>
                        <module.icon className={`h-5 w-5 ${module.color}`} />
                      </div>
                      <div>
                        <CardTitle className="text-lg">{module.title}</CardTitle>
                        <CardDescription className="text-sm">
                          {module.description}
                        </CardDescription>
                      </div>
                    </div>
                    <Badge variant={module.status === 'active' ? 'default' : 'secondary'}>
                      {module.status}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Metrics Grid */}
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    {Object.entries(module.metrics).map(([key, value]) => (
                      <div key={key} className="text-center">
                        <div className="font-bold text-lg">
                          {typeof value === 'number' && value > 100 ? value.toLocaleString() : value}
                          {key.includes('Rate') || key.includes('Improvement') || key.includes('Increase') ? '%' : ''}
                          {key.includes('Time') ? 's' : ''}
                        </div>
                        <div className="text-muted-foreground capitalize">
                          {key.replace(/([A-Z])/g, ' $1').toLowerCase()}
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Features List */}
                  <div>
                    <h4 className="font-medium mb-2 text-sm">Key Features:</h4>
                    <ul className="text-xs text-muted-foreground space-y-1">
                      {module.features.map((feature, idx) => (
                        <li key={idx} className="flex items-center gap-2">
                          <CheckCircle className="h-3 w-3 text-green-500" />
                          {feature}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <Button variant="outline" className="w-full" size="sm">
                    <Settings className="h-4 w-4 mr-2" />
                    Configure Module
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-6">
          {/* AI Analytics Dashboard */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="h-5 w-5 text-blue-500" />
                  Provider Performance
                </CardTitle>
                <CardDescription>Comparative analysis across AI providers</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {aiProviders.map((provider) => (
                    <div key={provider.id} className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm font-medium">{provider.name}</span>
                        <span className="text-sm text-muted-foreground">
                          {Math.round((provider.performance.speed + provider.performance.accuracy + provider.performance.cost) / 3)}%
                        </span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className={`h-2 rounded-full ${
                            provider.id === 'openai' ? 'bg-green-500' :
                            provider.id === 'anthropic' ? 'bg-blue-500' : 'bg-purple-500'
                          }`}
                          style={{width: `${Math.round((provider.performance.speed + provider.performance.accuracy + provider.performance.cost) / 3)}%`}}
                        ></div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-green-500" />
                  Usage Analytics
                </CardTitle>
                <CardDescription>AI feature utilization patterns</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Question Generation</span>
                    <span className="text-sm font-medium">45.6k requests</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Hint Generation</span>
                    <span className="text-sm font-medium">28.9k requests</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Content Analysis</span>
                    <span className="text-sm font-medium">18.7k requests</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Behavioral Analysis</span>
                    <span className="text-sm font-medium">12.8k requests</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="settings" className="space-y-6">
          {/* AI Configuration Settings */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="h-5 w-5 text-purple-500" />
                AI System Configuration
              </CardTitle>
              <CardDescription>Configure AI provider behavior and feature settings</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium">Auto-Failover</h4>
                    <p className="text-sm text-muted-foreground">Automatically switch providers on failure</p>
                  </div>
                  <Switch defaultChecked />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium">Load Balancing</h4>
                    <p className="text-sm text-muted-foreground">Distribute requests across providers</p>
                  </div>
                  <Switch defaultChecked />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium">Performance Monitoring</h4>
                    <p className="text-sm text-muted-foreground">Track and analyze AI performance metrics</p>
                  </div>
                  <Switch defaultChecked />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Default Provider</label>
                  <Select defaultValue="adaptive">
                    <SelectTrigger>
                      <SelectValue placeholder="Select default AI provider" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="adaptive">Adaptive Selection</SelectItem>
                      <SelectItem value="openai">OpenAI GPT-4o</SelectItem>
                      <SelectItem value="anthropic">Anthropic Claude</SelectItem>
                      <SelectItem value="gemini">Google Gemini</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      </div>
    </ModernLayout>
  );
}