import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { translations, SupportedLanguage, Translation } from './translations';

interface I18nContextType {
  language: SupportedLanguage;
  setLanguage: (lang: SupportedLanguage) => void;
  t: Translation;
  availableLanguages: { code: SupportedLanguage; name: string; nativeName: string }[];
}

const I18nContext = createContext<I18nContextType | undefined>(undefined);

const availableLanguages = [
  { code: 'en' as SupportedLanguage, name: 'English', nativeName: 'English' },
  { code: 'es' as SupportedLanguage, name: 'Spanish', nativeName: 'Español' },
  { code: 'fr' as SupportedLanguage, name: 'French', nativeName: 'Français' },
  { code: 'de' as SupportedLanguage, name: 'German', nativeName: 'Deutsch' },
  { code: 'ja' as SupportedLanguage, name: 'Japanese', nativeName: '日本語' }
];

// Detect browser language
function detectBrowserLanguage(): SupportedLanguage {
  const browserLang = navigator.language.slice(0, 2) as SupportedLanguage;
  return translations[browserLang] ? browserLang : 'en';
}

export function I18nProvider({ children }: { children: ReactNode }) {
  const [language, setLanguageState] = useState<SupportedLanguage>(() => {
    // Try to get saved language from localStorage first
    const saved = localStorage.getItem('eiq-language') as SupportedLanguage;
    if (saved && translations[saved]) {
      return saved;
    }
    // Fall back to browser detection
    return detectBrowserLanguage();
  });

  const setLanguage = (lang: SupportedLanguage) => {
    setLanguageState(lang);
    localStorage.setItem('eiq-language', lang);
    
    // Update document language for accessibility
    document.documentElement.lang = lang;
    
    // Update page title with localized text
    document.title = `${translations[lang].branding.platformName} - ${translations[lang].branding.tagline}`;
  };

  useEffect(() => {
    // Set initial document language
    document.documentElement.lang = language;
    document.title = `${translations[language].branding.platformName} - ${translations[language].branding.tagline}`;
  }, [language]);

  const value: I18nContextType = {
    language,
    setLanguage,
    t: translations[language],
    availableLanguages
  };

  return (
    <I18nContext.Provider value={value}>
      {children}
    </I18nContext.Provider>
  );
}

export function useI18n() {
  const context = useContext(I18nContext);
  if (context === undefined) {
    throw new Error('useI18n must be used within an I18nProvider');
  }
  return context;
}

// Helper hook for easy translation access
export function useTranslation() {
  const { t } = useI18n();
  return t;
}