// Translation resources for the EiQ™ platform
export const translations = {
  en: {
    common: {
      nav: { 
        dashboard: "Dashboard", 
        assessments: "Assessment Center",
        analytics: "Analytics",
        math: "Math Testing",
        voice: "Voice Assessment"
      },
      titles: { 
        eiq: "EiQ™ Scoring", 
        behavioral: "Behavioral Analytics",
        platform: "EiQ™ Powered by SikatLabs™"
      },
      actions: {
        start: "Start Assessment",
        continue: "Continue",
        submit: "Submit",
        retry: "Try Again"
      },
      accessibility: {
        skipToContent: "Skip to main content",
        skipToNavigation: "Skip to navigation",
        closeDialog: "Close dialog",
        openMenu: "Open menu",
        menuToggle: "Toggle navigation menu"
      }
    },
    branding: {
      platformName: "EiQ™ Powered by SikatLabs™",
      tagline: "AI-Powered Educational Intelligence Platform"
    }
  },
  es: {
    common: {
      nav: { 
        dashboard: "Tablero", 
        assessments: "Centro de Evaluación",
        analytics: "Análisis",
        math: "Pruebas Matemáticas", 
        voice: "Evaluación de Voz"
      },
      titles: { 
        eiq: "Puntuación EiQ™", 
        behavioral: "Análisis Conductual",
        platform: "EiQ™ Powered by SikatLabs™"
      },
      actions: {
        start: "Iniciar Evaluación",
        continue: "Continuar",
        submit: "Enviar",
        retry: "Intentar de Nuevo"
      },
      accessibility: {
        skipToContent: "Saltar al contenido principal",
        skipToNavigation: "Saltar a la navegación",
        closeDialog: "Cerrar diálogo",
        openMenu: "Abrir menú",
        menuToggle: "Alternar menú de navegación"
      }
    },
    branding: {
      platformName: "EiQ™ Powered by SikatLabs™",
      tagline: "Plataforma de Inteligencia Educativa con IA"
    }
  },
  fr: {
    common: {
      nav: { 
        dashboard: "Tableau de Bord", 
        assessments: "Centre d'Évaluation",
        analytics: "Analytique",
        math: "Tests Mathématiques",
        voice: "Évaluation Vocale"
      },
      titles: { 
        eiq: "Score EiQ™", 
        behavioral: "Analyse Comportementale",
        platform: "EiQ™ Powered by SikatLabs™"
      },
      actions: {
        start: "Commencer l'Évaluation",
        continue: "Continuer",
        submit: "Soumettre",
        retry: "Réessayer"
      },
      accessibility: {
        skipToContent: "Aller au contenu principal",
        skipToNavigation: "Aller à la navigation",
        closeDialog: "Fermer la boîte de dialogue",
        openMenu: "Ouvrir le menu",
        menuToggle: "Basculer le menu de navigation"
      }
    },
    branding: {
      platformName: "EiQ™ Powered by SikatLabs™",
      tagline: "Plateforme d'Intelligence Éducative alimentée par l'IA"
    }
  },
  de: {
    common: {
      nav: { 
        dashboard: "Dashboard", 
        assessments: "Bewertungszentrum",
        analytics: "Analytik",
        math: "Mathematik-Tests",
        voice: "Sprachbewertung"
      },
      titles: { 
        eiq: "EiQ™-Bewertung", 
        behavioral: "Verhaltensanalyse",
        platform: "EiQ™ Powered by SikatLabs™"
      },
      actions: {
        start: "Bewertung Starten",
        continue: "Fortfahren",
        submit: "Einreichen",
        retry: "Erneut Versuchen"
      },
      accessibility: {
        skipToContent: "Zum Hauptinhalt springen",
        skipToNavigation: "Zur Navigation springen",
        closeDialog: "Dialog schließen",
        openMenu: "Menü öffnen",
        menuToggle: "Navigationsmenü umschalten"
      }
    },
    branding: {
      platformName: "EiQ™ Powered by SikatLabs™",
      tagline: "KI-gestützte Bildungsintelligenz-Plattform"
    }
  },
  ja: {
    common: {
      nav: { 
        dashboard: "ダッシュボード", 
        assessments: "評価センター",
        analytics: "分析",
        math: "数学テスト",
        voice: "音声評価"
      },
      titles: { 
        eiq: "EiQ™スコア", 
        behavioral: "行動分析",
        platform: "EiQ™ Powered by SikatLabs™"
      },
      actions: {
        start: "評価を開始",
        continue: "続行",
        submit: "送信",
        retry: "再試行"
      },
      accessibility: {
        skipToContent: "メインコンテンツへスキップ",
        skipToNavigation: "ナビゲーションへスキップ",
        closeDialog: "ダイアログを閉じる",
        openMenu: "メニューを開く",
        menuToggle: "ナビゲーションメニューを切り替え"
      }
    },
    branding: {
      platformName: "EiQ™ Powered by SikatLabs™",
      tagline: "AI搭載教育インテリジェンスプラットフォーム"
    }
  }
};

export type SupportedLanguage = keyof typeof translations;
export type Translation = typeof translations.en;