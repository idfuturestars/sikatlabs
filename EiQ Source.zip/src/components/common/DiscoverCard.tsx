import { ReactNode } from "react";
import { cn } from "@/lib/utils";
import { LucideIcon } from "lucide-react";

interface DiscoverCardProps {
  title: string;
  description: string;
  icon: LucideIcon;
  gradient?: string;
  onClick?: () => void;
  badge?: string;
  badgeColor?: string;
  children?: ReactNode;
  className?: string;
}

export default function DiscoverCard({
  title,
  description,
  icon: Icon,
  gradient = "from-blue-500/10 to-purple-500/10",
  onClick,
  badge,
  badgeColor = "bg-primary",
  children,
  className
}: DiscoverCardProps) {
  return (
    <div
      onClick={onClick}
      className={cn(
        "group relative overflow-hidden rounded-xl border border-border bg-gradient-to-br",
        gradient,
        onClick && "cursor-pointer hover:scale-[1.02] transition-transform duration-200",
        className
      )}
    >
      <div className="p-6">
        <div className="flex items-start gap-4">
          <div className="flex-shrink-0">
            <div className="w-12 h-12 rounded-lg bg-background/50 flex items-center justify-center">
              <Icon className="w-6 h-6 text-primary" />
            </div>
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-2">
              <h3 className="font-semibold text-foreground group-hover:text-primary transition-colors">
                {title}
              </h3>
              {badge && (
                <span className={cn(
                  "px-2 py-1 text-xs font-medium rounded-full text-white",
                  badgeColor
                )}>
                  {badge}
                </span>
              )}
            </div>
            <p className="text-sm text-muted-foreground leading-relaxed">
              {description}
            </p>
            {children}
          </div>
        </div>
      </div>
      
      {/* Hover effect overlay */}
      {onClick && (
        <div className="absolute inset-0 bg-primary/5 opacity-0 group-hover:opacity-100 transition-opacity duration-200" />
      )}
    </div>
  );
}