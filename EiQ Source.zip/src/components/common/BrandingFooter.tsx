import { cn } from "@/lib/utils";

interface BrandingFooterProps {
  className?: string;
  variant?: "compact" | "full";
}

export default function BrandingFooter({ className, variant = "full" }: BrandingFooterProps) {
  if (variant === "compact") {
    return (
      <div className={cn("text-xs text-center text-muted-foreground", className)}>
        EiQ ™ powered by SikatLabs™|IDFS Pathway™|Alteria™ ©2025. All rights reserved.
      </div>
    );
  }

  return (
    <div className={cn("text-xs text-center text-muted-foreground space-y-1", className)}>
      <div>EiQ ™ powered by SikatLabs™|IDFS Pathway™|Alteria™</div>
      <div>©2025. All rights reserved.</div>
    </div>
  );
}