import { LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";
import { Progress } from "@/components/ui/progress";

interface StatItem {
  label: string;
  value: string | number;
  icon: LucideIcon;
  color?: string;
  progress?: number;
  trend?: "up" | "down" | "neutral";
  trendValue?: string;
}

interface StatsGridProps {
  stats: StatItem[];
  columns?: number;
  className?: string;
}

export default function StatsGrid({ stats, columns = 4, className }: StatsGridProps) {
  return (
    <div className={cn(
      "grid gap-4",
      columns === 2 && "grid-cols-1 sm:grid-cols-2",
      columns === 3 && "grid-cols-1 sm:grid-cols-2 lg:grid-cols-3",
      columns === 4 && "grid-cols-1 sm:grid-cols-2 lg:grid-cols-4",
      className
    )}>
      {stats.map((stat, index) => (
        <div
          key={index}
          className="p-6 bg-card border border-border rounded-xl hover:border-primary/20 transition-colors"
        >
          <div className="flex items-center gap-3 mb-3">
            <div className={cn(
              "w-10 h-10 rounded-lg flex items-center justify-center",
              stat.color || "bg-primary/10"
            )}>
              <stat.icon className={cn(
                "w-5 h-5",
                stat.color ? "text-current" : "text-primary"
              )} />
            </div>
            <div className="flex-1">
              <div className="text-2xl font-bold text-foreground">
                {stat.value}
              </div>
              {stat.trend && stat.trendValue && (
                <div className={cn(
                  "text-xs flex items-center gap-1",
                  stat.trend === "up" && "text-green-500",
                  stat.trend === "down" && "text-red-500",
                  stat.trend === "neutral" && "text-muted-foreground"
                )}>
                  {stat.trend === "up" && "↗"}
                  {stat.trend === "down" && "↘"}
                  {stat.trend === "neutral" && "→"}
                  {stat.trendValue}
                </div>
              )}
            </div>
          </div>
          
          <div className="space-y-2">
            <div className="text-sm text-muted-foreground">{stat.label}</div>
            {typeof stat.progress === "number" && (
              <Progress value={stat.progress} className="h-2" />
            )}
          </div>
        </div>
      ))}
    </div>
  );
}