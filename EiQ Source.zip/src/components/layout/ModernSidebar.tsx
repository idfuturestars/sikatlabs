import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { 
  Brain, 
  Calculator, 
  Target, 
  BarChart3, 
  Bot, 
  BookOpen, 
  Award, 
  Lightbulb,
  Mic,
  PieChart,
  Cpu,
  Settings,
  ChevronDown,
  ChevronRight,
  Home,
  Zap,
  Users,
  MessageSquare,
  Clock,
  Crown,
  Rocket,
  Sprout
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Progress } from "@/components/ui/progress";

interface ModernSidebarProps {
  activeSection: string;
  onSectionChange: (section: string) => void;
}

export default function ModernSidebar({ activeSection, onSectionChange }: ModernSidebarProps) {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [expandedSections, setExpandedSections] = useState<string[]>(["core", "assessment_center", "eiq_analytics", "ai_features"]);

  const toggleSection = (section: string) => {
    setExpandedSections(prev => 
      prev.includes(section) 
        ? prev.filter(s => s !== section)
        : [...prev, section]
    );
  };

  const navigationSections = {
    core: [
      { id: "dashboard", icon: Home, label: "Dashboard", route: "/" },
    ],
    assessment_center: {
      main: { id: "assessment-center", icon: Target, label: "Assessment Center", route: "/assessment-center" },
      items: [
        { id: "sat-act-myers", icon: Calculator, label: "SAT/ACT/Myers-Briggs/DSM", route: "/sat-act-myers" },
        { id: "ai-immersion-assessment", icon: Clock, label: "AI Immersion Assessment", route: "/ai-immersion-assessment" },
        { id: "role-model-matching", icon: Crown, label: "Role-Model Matching", route: "/role-model-matching-new" },
      ]
    },
    eiq_analytics: {
      main: { id: "eiq-analytics", icon: PieChart, label: "EiQ™ Analytics", route: "/eiq-analytics" },
      items: [
        { id: "fico-scoring", icon: BarChart3, label: "FICO-like Scoring Dashboard", route: "/fico-scoring" },
        { id: "behavioral-analytics", icon: Brain, label: "Behavioral Learning Analytics", route: "/behavioral-analytics" },
      ]
    },
    ai_features: {
      main: { id: "ai-features", icon: Cpu, label: "AI Features", route: "/ai-features" },
      items: [
        { id: "multi-ai-providers", icon: Bot, label: "Multi-AI Provider Controls", route: "/multi-ai-providers" },
        { id: "advanced-voice", icon: Mic, label: "Advanced Voice Assessment", route: "/advanced-voice" },
        { id: "turing-test", icon: Zap, label: "Turing Test Platform", route: "/turing-test" },
      ]
    },
    assessments: [
      { id: "idfs-assessment", icon: Clock, label: "AI Immersion (IDFS)", route: "/idfs-assessment" },
      { id: "standardized-tests", icon: Calculator, label: "SAT/ACT/Myers Briggs", route: "/standardized-tests" },
      { id: "multi-iq-scoring", icon: Brain, label: "Multi-IQ Scoring", route: "/multi-iq-scoring" },
      { id: "dsm-integration", icon: Lightbulb, label: "DSM Integration", route: "/dsm-integration" },
      { id: "voice-assessment", icon: Mic, label: "Voice Assessment", route: "/voice-assessment" },
      { id: "multi-modal", icon: Cpu, label: "Multi-Modal", route: "/multi-modal" },
      { id: "personality-assessment", icon: Users, label: "Personality Test", route: "/personality-assessment" },
    ],
    learning: [
      { id: "learning-paths", icon: BookOpen, label: "Learning Paths", route: "/learning-paths" },
      { id: "quiz-rooms-ai", icon: Users, label: "Quiz Rooms AI", route: "/quiz-rooms-ai" },
      { id: "collaboration", icon: MessageSquare, label: "Real-time Collab", route: "/collaboration" },
      { id: "study-cohorts", icon: Users, label: "Study Cohorts", route: "/study-cohorts" },
    ],
    tools: [
      { id: "challenge", icon: Rocket, label: "Viral Challenge", route: "/challenge" },
      { id: "enhanced-challenge", icon: Zap, label: "Enhanced Challenge", route: "/enhanced-challenge" },
      { id: "social", icon: Users, label: "Social EiQ", route: "/social" },
      { id: "developer-portal", icon: Settings, label: "Developer Portal", route: "/developer-portal" },
    ]
  };

  const eiqDomains = [
    { id: "logical", icon: Brain, label: "Logical Reasoning", score: 142 },
    { id: "memory", icon: Zap, label: "Working Memory", score: 156 },
    { id: "verbal", icon: MessageSquare, label: "Verbal", score: 134 },
    { id: "perceptual", icon: Calculator, label: "Perceptual", score: 148 },
    { id: "speed", icon: Clock, label: "Processing Speed", score: 163 },
    { id: "emotional", icon: Users, label: "Emotional IQ", score: 145 },
  ];

  const scoreTargets = [
    { id: "good", icon: Sprout, label: "Good (500-600)", color: "text-white/60" },
    { id: "excellent", icon: Rocket, label: "Excellent (600-700)", color: "text-white/80" },
    { id: "elite", icon: Crown, label: "Elite (700+)", color: "text-white" },
  ];

  const NavItem = ({ item, isActive = false }: { item: any; isActive?: boolean }) => (
    <button
      onClick={() => {
        if (item.route) {
          setLocation(item.route);
        }
        onSectionChange(item.id);
      }}
      className={cn(
        "flex items-center gap-3 px-3 py-2 rounded-lg transition-all duration-200 w-full text-left",
        isActive
          ? "bg-primary/10 text-primary font-medium"
          : "text-muted-foreground hover:text-foreground hover:bg-muted/50"
      )}
    >
      <item.icon className="w-4 h-4 flex-shrink-0" />
      <span className="text-sm">{item.label}</span>
      {item.score && (
        <span className="ml-auto text-xs bg-primary/10 text-primary px-2 py-0.5 rounded-full">
          {item.score}
        </span>
      )}
    </button>
  );

  const SectionHeader = ({ title, section, expandable = false }: { title: string; section?: string; expandable?: boolean }) => (
    <div 
      className={cn(
        "flex items-center gap-2 px-3 py-2 text-xs font-semibold text-muted-foreground uppercase tracking-wider",
        expandable && "cursor-pointer hover:text-foreground"
      )}
      onClick={expandable && section ? () => toggleSection(section) : undefined}
    >
      <span>{title}</span>
      {expandable && section && (
        expandedSections.includes(section) ? 
          <ChevronDown className="w-3 h-3" /> : 
          <ChevronRight className="w-3 h-3" />
      )}
    </div>
  );

  return (
    <aside className="w-64 bg-card border-r border-border flex flex-col h-screen">
      {/* Header */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
            <Brain className="w-5 h-5 text-primary-foreground" />
          </div>
          <div>
            <h1 className="font-semibold text-foreground">EiQ★</h1>
            <p className="text-xs text-muted-foreground">SikatLabs</p>
          </div>
        </div>
        
        {/* User Profile */}
        <div className="flex items-center gap-3 p-3 bg-muted/30 rounded-lg">
          <Avatar className="w-8 h-8">
            <AvatarImage src={user?.profileImageUrl} />
            <AvatarFallback className="bg-primary text-primary-foreground text-xs">
              {user?.firstName?.[0] || user?.first_name?.[0] || 'U'}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-foreground truncate">
              {user?.firstName || user?.first_name || 'Student'}
            </p>
            <p className="text-xs text-muted-foreground">EiQ★ Score: 645</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <div className="flex-1 overflow-y-auto p-4 space-y-6">
        {/* Core Navigation */}
        <div>
          <SectionHeader title="Core" section="core" expandable />
          {expandedSections.includes("core") && (
            <div className="space-y-1 mt-2">
              {navigationSections.core.map((item) => (
                <NavItem 
                  key={item.id} 
                  item={item} 
                  isActive={activeSection === item.id} 
                />
              ))}
            </div>
          )}
        </div>

        {/* Assessment Suite */}
        <div>
          <SectionHeader title="Assessment Suite" section="assessments" expandable />
          {expandedSections.includes("assessments") && (
            <div className="space-y-1 mt-2">
              {navigationSections.assessments.map((item) => (
                <NavItem 
                  key={item.id} 
                  item={item} 
                  isActive={activeSection === item.id} 
                />
              ))}
            </div>
          )}
        </div>

        {/* Assessment Center with sub-sections */}
        <div>
          <SectionHeader title="Assessment Center" section="assessment_center" expandable />
          {expandedSections.includes("assessment_center") && (
            <div className="space-y-1 mt-2">
              {/* Main Assessment Center link */}
              <NavItem 
                key={navigationSections.assessment_center.main.id} 
                item={navigationSections.assessment_center.main} 
                isActive={activeSection === navigationSections.assessment_center.main.id}
              />
              {/* Sub-sections */}
              <div className="ml-4 space-y-1 border-l border-border pl-3">
                {navigationSections.assessment_center.items.map((item) => (
                  <NavItem 
                    key={item.id} 
                    item={item} 
                    isActive={activeSection === item.id}
                  />
                ))}
              </div>
            </div>
          )}
        </div>

        {/* EiQ Analytics with sub-sections */}
        <div>
          <SectionHeader title="EiQ Analytics" section="eiq_analytics" expandable />
          {expandedSections.includes("eiq_analytics") && (
            <div className="space-y-1 mt-2">
              {/* Main EiQ Analytics link */}
              <NavItem 
                key={navigationSections.eiq_analytics.main.id} 
                item={navigationSections.eiq_analytics.main} 
                isActive={activeSection === navigationSections.eiq_analytics.main.id}
              />
              {/* Sub-sections */}
              <div className="ml-4 space-y-1 border-l border-border pl-3">
                {navigationSections.eiq_analytics.items.map((item) => (
                  <NavItem 
                    key={item.id} 
                    item={item} 
                    isActive={activeSection === item.id}
                  />
                ))}
              </div>
            </div>
          )}
        </div>

        {/* AI Features with sub-sections */}
        <div>
          <SectionHeader title="AI Features" section="ai_features" expandable />
          {expandedSections.includes("ai_features") && (
            <div className="space-y-1 mt-2">
              {/* Main AI Features link */}
              <NavItem 
                key={navigationSections.ai_features.main.id} 
                item={navigationSections.ai_features.main} 
                isActive={activeSection === navigationSections.ai_features.main.id}
              />
              {/* Sub-sections */}
              <div className="ml-4 space-y-1 border-l border-border pl-3">
                {navigationSections.ai_features.items.map((item) => (
                  <NavItem 
                    key={item.id} 
                    item={item} 
                    isActive={activeSection === item.id}
                  />
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Learning & Collaboration */}
        <div>
          <SectionHeader title="Learning & Collaboration" section="learning" expandable />
          {expandedSections.includes("learning") && (
            <div className="space-y-1 mt-2">
              {navigationSections.learning.map((item) => (
                <NavItem 
                  key={item.id} 
                  item={item} 
                  isActive={activeSection === item.id} 
                />
              ))}
            </div>
          )}
        </div>

        {/* Tools & Challenges */}
        <div>
          <SectionHeader title="Tools & Challenges" section="tools" expandable />
          {expandedSections.includes("tools") && (
            <div className="space-y-1 mt-2">
              {navigationSections.tools.map((item) => (
                <NavItem 
                  key={item.id} 
                  item={item} 
                  isActive={activeSection === item.id} 
                />
              ))}
            </div>
          )}
        </div>

        {/* EiQ★ Domains */}
        <div>
          <SectionHeader title="EiQ★ Domains" section="domains" expandable />
          {expandedSections.includes("domains") && (
            <div className="space-y-1 mt-2">
              {eiqDomains.map((item) => (
                <NavItem key={item.id} item={item} />
              ))}
            </div>
          )}
        </div>

        {/* Score Targets */}
        <div>
          <SectionHeader title="Score Targets" />
          <div className="space-y-1 mt-2">
            {scoreTargets.map((item) => (
              <div key={item.id} className="flex items-center gap-3 px-3 py-2 text-muted-foreground">
                <item.icon className={cn("w-4 h-4", item.color)} />
                <span className="text-sm">{item.label}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Progress Overview */}
        <div className="p-3 bg-muted/30 rounded-lg">
          <div className="text-sm font-medium text-foreground mb-2">Overall Progress</div>
          <Progress value={72} className="h-2 mb-2" />
          <div className="text-xs text-muted-foreground">72% Complete</div>
        </div>
      </div>

      {/* Footer */}
      <div className="p-4 border-t border-border">
        <Button 
          variant="ghost" 
          size="sm" 
          onClick={() => onSectionChange("settings")}
          className="w-full justify-start"
        >
          <Settings className="w-4 h-4 mr-2" />
          Settings
        </Button>
      </div>
    </aside>
  );
}