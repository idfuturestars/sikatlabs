import { ReactNode } from "react";
import ModernSidebar from "./ModernSidebar";
import { cn } from "@/lib/utils";

interface ModernLayoutProps {
  children: ReactNode;
  activeSection: string;
  onSectionChange: (section: string) => void;
  className?: string;
}

export default function ModernLayout({ 
  children, 
  activeSection, 
  onSectionChange, 
  className 
}: ModernLayoutProps) {
  return (
    <div className="flex h-screen bg-background">
      <ModernSidebar 
        activeSection={activeSection}
        onSectionChange={onSectionChange}
      />
      <main className={cn("flex-1 overflow-y-auto", className)}>
        {children}
      </main>
    </div>
  );
}