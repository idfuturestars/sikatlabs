// Assessment.test.tsx
//
// This test uses React Testing Library to verify that the assessment
// component advances to the next question when the "Next" button is
// clicked. It assumes your project uses React and has an Assessment
// component at the given import path. Adjust the import path to
// reflect your actual file structure.

import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';

// Import the actual assessment components
import AssessmentEngine from '../AssessmentEngine';
import InteractiveAssessment from '../InteractiveAssessment';

// Mock useLocation from wouter
const mockSetLocation = jest.fn();
jest.mock('wouter', () => ({
  useLocation: () => ['/assessment', mockSetLocation]
}));

// Create a test wrapper with QueryClient
const createTestWrapper = () => {
  const queryClient = new QueryClient({
    defaultOptions: {
      queries: { retry: false },
      mutations: { retry: false },
    },
  });
  
  return ({ children }: { children: React.ReactNode }) => (
    <QueryClientProvider client={queryClient}>
      {children}
    </QueryClientProvider>
  );
};

describe('Assessment Components', () => {
  test('AssessmentEngine renders start button', async () => {
    const TestWrapper = createTestWrapper();
    
    render(
      <TestWrapper>
        <AssessmentEngine userId="test-user" />
      </TestWrapper>
    );

    // Ensure the Start Assessment button is present
    const startButton = screen.getByRole('button', { name: /start assessment/i });
    expect(startButton).toBeInTheDocument();
  });

  test('AssessmentEngine has Continue buttons for each section', async () => {
    const TestWrapper = createTestWrapper();
    
    render(
      <TestWrapper>
        <AssessmentEngine userId="test-user" />
      </TestWrapper>
    );

    // Wait for the component to render assessment cards
    await waitFor(() => {
      const continueButtons = screen.getAllByRole('button', { name: /continue/i });
      expect(continueButtons.length).toBeGreaterThan(0);
    });
  });

  test('InteractiveAssessment advances through questions', async () => {
    const mockOnComplete = jest.fn() as jest.MockedFunction<(score: number, results: any) => void>;
    
    const TestWrapper = createTestWrapper();
    
    render(
      <TestWrapper>
        <InteractiveAssessment type="baseline" onComplete={mockOnComplete} />
      </TestWrapper>
    );

    // Find and select an answer option first
    const radioOption = screen.getAllByRole('radio')[0];
    fireEvent.click(radioOption);

    // Find the Next/Complete button
    const nextButton = screen.getByRole('button', { name: /next|complete/i });
    expect(nextButton).toBeInTheDocument();
    
    // Button should be enabled after selecting an answer
    expect(nextButton).not.toBeDisabled();

    // Click the button to advance
    fireEvent.click(nextButton);

    // Verify the component updates (question index should change)
    await waitFor(() => {
      // The button text or question content should update
      expect(screen.getByText(/question \d+ of/i)).toBeInTheDocument();
    });
  });

  test('InteractiveAssessment displays AI hints', async () => {
    const mockOnComplete = jest.fn() as jest.MockedFunction<(score: number, results: any) => void>;
    
    const TestWrapper = createTestWrapper();
    
    render(
      <TestWrapper>
        <InteractiveAssessment type="baseline" onComplete={mockOnComplete} />
      </TestWrapper>
    );

    // Find the AI hint button
    const hintButton = screen.getByRole('button', { name: /get ai hint/i });
    expect(hintButton).toBeInTheDocument();

    // Click to show hint
    fireEvent.click(hintButton);

    // Verify hint appears
    await waitFor(() => {
      expect(screen.getByText(/ai hint:/i)).toBeInTheDocument();
    });
  });
});