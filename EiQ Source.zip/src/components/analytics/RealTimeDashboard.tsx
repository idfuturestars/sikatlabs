import { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Users,
  TrendingUp,
  Activity,
  Brain,
  Zap,
  Monitor,
  AlertTriangle,
  CheckCircle,
  Clock,
  RefreshCw,
  BarChart3,
  LineChart,
  Database,
  Wifi,
  WifiOff
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { LineChart as RechartsLineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Area, AreaChart, BarChart, Bar, PieChart, Pie, Cell } from 'recharts';

// Real-time Dashboard Component for Live Analytics
// Implements WebSocket connections, live metrics, streaming updates

interface LiveMetric {
  id: string;
  name: string;
  value: number;
  unit: string;
  change: number;
  changePercent: number;
  status: 'healthy' | 'warning' | 'critical';
  timestamp: Date;
}

interface DashboardData {
  timestamp: Date;
  userMetrics: {
    totalUsers: number;
    activeUsers: number;
    newUsersToday: number;
    userGrowthRate: number;
  };
  performanceMetrics: {
    avgEiqScore: number;
    assessmentCompletions: number;
    learningVelocity: number;
    engagementScore: number;
  };
  systemMetrics: {
    responseTime: number;
    errorRate: number;
    uptime: number;
    concurrentSessions: number;
  };
  alertMetrics: {
    activeAlerts: number;
    criticalAlerts: number;
    resolvedToday: number;
  };
}

interface StreamingEvent {
  type: 'metric_update' | 'user_action' | 'system_alert' | 'assessment_completed';
  data: any;
  timestamp: Date;
  userId?: string;
}

interface HistoricalDataPoint {
  timestamp: Date;
  userCount: number;
  avgScore: number;
  assessments: number;
  responseTime: number;
}

const CHART_COLORS = ['#22c55e', '#3b82f6', '#f59e0b', '#ef4444', '#8b5cf6'];

export default function RealTimeDashboard() {
  const [isConnected, setIsConnected] = useState(false);
  const [dashboardData, setDashboardData] = useState<DashboardData | null>(null);
  const [liveMetrics, setLiveMetrics] = useState<LiveMetric[]>([]);
  const [streamingEvents, setStreamingEvents] = useState<StreamingEvent[]>([]);
  const [historicalData, setHistoricalData] = useState<HistoricalDataPoint[]>([]);
  const [selectedTimeRange, setSelectedTimeRange] = useState<'1h' | '24h' | '7d' | '30d'>('24h');
  const [autoRefresh, setAutoRefresh] = useState(true);
  const wsRef = useRef<WebSocket | null>(null);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // WebSocket connection management
  useEffect(() => {
    connectWebSocket();

    return () => {
      if (wsRef.current) {
        wsRef.current.close();
      }
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
      }
    };
  }, []);

  const connectWebSocket = () => {
    try {
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}/analytics-ws`;
      
      wsRef.current = new WebSocket(wsUrl);

      wsRef.current.onopen = () => {
        console.log('[REAL-TIME DASHBOARD] WebSocket connected');
        setIsConnected(true);
        
        // Request historical data
        if (wsRef.current) {
          wsRef.current.send(JSON.stringify({
            type: 'request_historical',
            timeRange: selectedTimeRange
          }));
        }
      };

      wsRef.current.onmessage = (event) => {
        try {
          const message = JSON.parse(event.data);
          handleWebSocketMessage(message);
        } catch (error) {
          console.error('[REAL-TIME DASHBOARD] Error parsing WebSocket message:', error);
        }
      };

      wsRef.current.onclose = () => {
        console.log('[REAL-TIME DASHBOARD] WebSocket disconnected');
        setIsConnected(false);
        
        // Attempt to reconnect after 5 seconds
        reconnectTimeoutRef.current = setTimeout(() => {
          connectWebSocket();
        }, 5000);
      };

      wsRef.current.onerror = (error) => {
        console.error('[REAL-TIME DASHBOARD] WebSocket error:', error);
        setIsConnected(false);
      };

    } catch (error) {
      console.error('[REAL-TIME DASHBOARD] Error connecting WebSocket:', error);
      setIsConnected(false);
    }
  };

  const handleWebSocketMessage = (message: any) => {
    switch (message.type) {
      case 'initial_data':
      case 'dashboard_update':
        setDashboardData(message.data);
        break;
        
      case 'metrics_update':
        setLiveMetrics(message.data);
        break;
        
      case 'streaming_event':
        setStreamingEvents(prev => [message.data, ...prev.slice(0, 49)]); // Keep last 50 events
        break;
        
      case 'historical_data':
        setHistoricalData(message.data);
        break;
        
      default:
        console.log('[REAL-TIME DASHBOARD] Unknown message type:', message.type);
    }
  };

  // Request specific metrics
  const requestMetrics = (metrics: string[]) => {
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({
        type: 'request_metrics',
        metrics
      }));
    }
  };

  // Change time range and request new historical data
  const changeTimeRange = (range: typeof selectedTimeRange) => {
    setSelectedTimeRange(range);
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({
        type: 'request_historical',
        timeRange: range
      }));
    }
  };

  // Format numbers for display
  const formatNumber = (value: number, unit: string) => {
    if (unit === '%') return `${value.toFixed(1)}%`;
    if (unit === 'ms') return `${value.toFixed(0)}ms`;
    if (value >= 1000000) return `${(value / 1000000).toFixed(1)}M`;
    if (value >= 1000) return `${(value / 1000).toFixed(1)}K`;
    return value.toFixed(0);
  };

  // Get status color
  const getStatusColor = (status: LiveMetric['status']) => {
    switch (status) {
      case 'healthy': return 'text-green-600';
      case 'warning': return 'text-yellow-600';
      case 'critical': return 'text-red-600';
      default: return 'text-gray-600';
    }
  };

  // Get trend icon
  const getTrendIcon = (change: number) => {
    if (change > 0) return <TrendingUp className="w-4 h-4 text-green-600" />;
    if (change < 0) return <TrendingUp className="w-4 h-4 text-red-600 transform rotate-180" />;
    return <Activity className="w-4 h-4 text-gray-400" />;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800" data-testid="realtime-dashboard">
      <div className="container mx-auto px-4 py-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
              Real-Time Analytics
            </h1>
            <p className="text-gray-600 dark:text-gray-400 mt-1">
              Live platform monitoring and insights
            </p>
          </div>
          
          <div className="flex items-center space-x-3">
            {/* Connection Status */}
            <div className={`flex items-center space-x-2 px-3 py-2 rounded-lg ${isConnected 
              ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200' 
              : 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'
            }`}>
              {isConnected ? <Wifi className="w-4 h-4" /> : <WifiOff className="w-4 h-4" />}
              <span className="text-sm font-medium">
                {isConnected ? 'Connected' : 'Disconnected'}
              </span>
            </div>

            {/* Auto Refresh Toggle */}
            <Button
              variant={autoRefresh ? "default" : "outline"}
              size="sm"
              onClick={() => setAutoRefresh(!autoRefresh)}
              data-testid="toggle-autorefresh"
            >
              <RefreshCw className={`w-4 h-4 mr-2 ${autoRefresh ? 'animate-spin' : ''}`} />
              Auto Refresh
            </Button>
          </div>
        </div>

        {/* Live Metrics Grid */}
        {liveMetrics.length > 0 && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {liveMetrics.map((metric) => (
              <motion.div
                key={metric.id}
                initial={{ scale: 0.95, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ duration: 0.2 }}
              >
                <Card className="hover:shadow-lg transition-shadow">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-gray-600 dark:text-gray-400">
                          {metric.name}
                        </p>
                        <p className="text-2xl font-bold text-gray-900 dark:text-white">
                          {formatNumber(metric.value, metric.unit)}
                        </p>
                        <div className="flex items-center space-x-1 mt-1">
                          {getTrendIcon(metric.change)}
                          <span className={`text-sm ${metric.change >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                            {metric.changePercent > 0 ? '+' : ''}{metric.changePercent.toFixed(1)}%
                          </span>
                        </div>
                      </div>
                      <div className={`w-3 h-3 rounded-full ${
                        metric.status === 'healthy' ? 'bg-green-500' :
                        metric.status === 'warning' ? 'bg-yellow-500' : 'bg-red-500'
                      }`} />
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        )}

        {/* Main Dashboard Content */}
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="performance">Performance</TabsTrigger>
            <TabsTrigger value="users">Users</TabsTrigger>
            <TabsTrigger value="system">System</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* User Growth Chart */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Users className="w-5 h-5" />
                    <span>User Growth Trend</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {historicalData.length > 0 ? (
                    <ResponsiveContainer width="100%" height={300}>
                      <AreaChart data={historicalData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis 
                          dataKey="timestamp" 
                          tickFormatter={(value) => new Date(value).toLocaleDateString()}
                        />
                        <YAxis />
                        <Tooltip 
                          labelFormatter={(value) => new Date(value).toLocaleString()}
                          formatter={(value: number) => [value, 'Users']}
                        />
                        <Area 
                          type="monotone" 
                          dataKey="userCount" 
                          stroke="#22c55e" 
                          fill="#22c55e" 
                          fillOpacity={0.3}
                        />
                      </AreaChart>
                    </ResponsiveContainer>
                  ) : (
                    <div className="h-300 flex items-center justify-center text-gray-500">
                      Loading historical data...
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Performance Chart */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Brain className="w-5 h-5" />
                    <span>Average EiQ Score</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {historicalData.length > 0 ? (
                    <ResponsiveContainer width="100%" height={300}>
                      <RechartsLineChart data={historicalData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis 
                          dataKey="timestamp"
                          tickFormatter={(value) => new Date(value).toLocaleDateString()}
                        />
                        <YAxis domain={[400, 800]} />
                        <Tooltip 
                          labelFormatter={(value) => new Date(value).toLocaleString()}
                          formatter={(value: number) => [value, 'EiQ Score']}
                        />
                        <Line 
                          type="monotone" 
                          dataKey="avgScore" 
                          stroke="#3b82f6" 
                          strokeWidth={2}
                          dot={{ fill: '#3b82f6' }}
                        />
                      </RechartsLineChart>
                    </ResponsiveContainer>
                  ) : (
                    <div className="h-300 flex items-center justify-center text-gray-500">
                      Loading performance data...
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Dashboard Summary Cards */}
            {dashboardData && (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-3">
                      <Users className="w-8 h-8 text-blue-600" />
                      <div>
                        <p className="text-sm text-gray-600">Total Users</p>
                        <p className="text-2xl font-bold">{dashboardData.userMetrics.totalUsers.toLocaleString()}</p>
                        <p className="text-xs text-green-600">+{dashboardData.userMetrics.newUsersToday} today</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-3">
                      <Activity className="w-8 h-8 text-green-600" />
                      <div>
                        <p className="text-sm text-gray-600">Active Users</p>
                        <p className="text-2xl font-bold">{dashboardData.userMetrics.activeUsers.toLocaleString()}</p>
                        <p className="text-xs text-blue-600">{dashboardData.performanceMetrics.engagementScore.toFixed(1)}% engagement</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-3">
                      <Brain className="w-8 h-8 text-purple-600" />
                      <div>
                        <p className="text-sm text-gray-600">Avg EiQ Score</p>
                        <p className="text-2xl font-bold">{dashboardData.performanceMetrics.avgEiqScore}</p>
                        <p className="text-xs text-green-600">+{dashboardData.performanceMetrics.learningVelocity.toFixed(1)} velocity</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-3">
                      <Monitor className="w-8 h-8 text-orange-600" />
                      <div>
                        <p className="text-sm text-gray-600">Response Time</p>
                        <p className="text-2xl font-bold">{dashboardData.systemMetrics.responseTime.toFixed(0)}ms</p>
                        <p className={`text-xs ${dashboardData.systemMetrics.uptime > 99.5 ? 'text-green-600' : 'text-yellow-600'}`}>
                          {dashboardData.systemMetrics.uptime.toFixed(2)}% uptime
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}
          </TabsContent>

          {/* Performance Tab */}
          <TabsContent value="performance" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Assessment Completions</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={historicalData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="timestamp" tickFormatter={(value) => new Date(value).toLocaleDateString()} />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="assessments" fill="#22c55e" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>System Response Time</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <RechartsLineChart data={historicalData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="timestamp" tickFormatter={(value) => new Date(value).toLocaleDateString()} />
                      <YAxis />
                      <Tooltip />
                      <Line type="monotone" dataKey="responseTime" stroke="#f59e0b" strokeWidth={2} />
                    </RechartsLineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Users Tab */}
          <TabsContent value="users" className="space-y-6">
            {/* User analytics and demographics would go here */}
            <Card>
              <CardHeader>
                <CardTitle>User Analytics</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">Comprehensive user analytics coming soon...</p>
              </CardContent>
            </Card>
          </TabsContent>

          {/* System Tab */}
          <TabsContent value="system" className="space-y-6">
            {/* Live Event Stream */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Zap className="w-5 h-5" />
                  <span>Live Event Stream</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-400">
                  <div className="space-y-2">
                    <AnimatePresence>
                      {streamingEvents.map((event, index) => (
                        <motion.div
                          key={`${event.timestamp}-${index}`}
                          initial={{ opacity: 0, y: -10 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: -10 }}
                          className="flex items-center space-x-3 p-2 bg-gray-50 dark:bg-gray-800 rounded-lg"
                        >
                          <div className={`w-2 h-2 rounded-full ${
                            event.type === 'system_alert' ? 'bg-red-500' :
                            event.type === 'assessment_completed' ? 'bg-green-500' :
                            event.type === 'user_action' ? 'bg-blue-500' : 'bg-gray-500'
                          }`} />
                          <div className="flex-1">
                            <div className="flex items-center space-x-2">
                              <Badge variant="outline" className="text-xs">
                                {event.type.replace('_', ' ')}
                              </Badge>
                              <span className="text-xs text-gray-500">
                                {new Date(event.timestamp).toLocaleTimeString()}
                              </span>
                            </div>
                            <p className="text-sm text-gray-700 dark:text-gray-300 mt-1">
                              {event.data.message || JSON.stringify(event.data).slice(0, 100)}
                            </p>
                          </div>
                        </motion.div>
                      ))}
                    </AnimatePresence>
                    {streamingEvents.length === 0 && (
                      <div className="text-center py-8 text-gray-500">
                        Waiting for live events...
                      </div>
                    )}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Time Range Selector */}
        <div className="flex justify-center">
          <div className="flex space-x-1 bg-white dark:bg-gray-800 p-1 rounded-lg shadow">
            {(['1h', '24h', '7d', '30d'] as const).map((range) => (
              <Button
                key={range}
                variant={selectedTimeRange === range ? 'default' : 'ghost'}
                size="sm"
                onClick={() => changeTimeRange(range)}
                data-testid={`timerange-${range}`}
              >
                {range}
              </Button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}