import React from 'react';
import { Link, useLocation } from 'wouter';
const Item = ({href, children}:{href:string, children:React.ReactNode})=>{
  const [loc] = useLocation();
  const active = loc === href ? 'font-semibold underline' : '';
  return <li className={`px-2 py-1 ${active}`}><Link href={href}>{children}</Link></li>;
};
export default function NavMenu(){
  return (
    <nav aria-label="Main">
      <ul className="flex flex-wrap gap-2">
        <Item href="/">Dashboard</Item>
        <Item href="/assessments">Assessment Center</Item>
        <Item href="/analytics/eiq">FICO-like EiQ Scoring</Item>
        <Item href="/analytics/behavioral">Behavioral Analytics</Item>
        <Item href="/ai/providers">Multi‑AI Provider Controls</Item>
        <Item href="/assessments/voice">Advanced Voice Assessment</Item>
        <Item href="/role-models">Role‑Model Matching</Item>
        <Item href="/ai/turing">Turing Test Platform</Item>
      </ul>
    </nav>
  );
}