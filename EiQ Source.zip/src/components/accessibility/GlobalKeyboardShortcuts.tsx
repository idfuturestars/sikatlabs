import React, { useEffect, useCallback } from 'react';
import { useLocation } from 'wouter';
import { useTranslation } from '@/i18n/i18nContext';
import { useAnnouncer } from './AccessibilityAnnouncer';

interface KeyboardShortcut {
  key: string;
  ctrlKey?: boolean;
  altKey?: boolean;
  shiftKey?: boolean;
  action: () => void;
  description: string;
  category: string;
}

export function GlobalKeyboardShortcuts() {
  const [, setLocation] = useLocation();
  const t = useTranslation();
  const announce = useAnnouncer();

  const handleFocusMain = useCallback(() => {
    const main = document.getElementById('main-content');
    if (main) {
      main.focus();
      announce(t.a11y.skipToContent);
    }
  }, [announce, t]);

  const handleToggleSidebar = useCallback(() => {
    const sidebarToggle = document.querySelector('[data-testid="sidebar-toggle"]') as HTMLButtonElement;
    if (sidebarToggle) {
      sidebarToggle.click();
      announce(t.a11y.menuToggle);
    }
  }, [announce, t]);

  const handleGoHome = useCallback(() => {
    setLocation('/');
    announce('Navigating to Dashboard');
  }, [setLocation, announce]);

  const handleGoAssessments = useCallback(() => {
    setLocation('/assessment-center');
    announce('Navigating to Assessment Center');
  }, [setLocation, announce]);

  const handleGoAnalytics = useCallback(() => {
    setLocation('/eiq-analytics');
    announce('Navigating to Analytics');
  }, [setLocation, announce]);

  const handleShowHelp = useCallback(() => {
    const helpButton = document.querySelector('[data-testid="help-button"]') as HTMLButtonElement;
    if (helpButton) {
      helpButton.click();
    } else {
      announce('Keyboard shortcuts: Alt+M for menu, Ctrl+H for home, Ctrl+A for assessments, Ctrl+E for analytics, F1 for help');
    }
  }, [announce]);

  const shortcuts: KeyboardShortcut[] = [
    {
      key: 'm',
      altKey: true,
      action: handleFocusMain,
      description: 'Skip to main content',
      category: 'Navigation'
    },
    {
      key: 's',
      altKey: true,
      action: handleToggleSidebar,
      description: 'Toggle sidebar menu',
      category: 'Navigation'
    },
    {
      key: 'h',
      ctrlKey: true,
      action: handleGoHome,
      description: 'Go to dashboard',
      category: 'Navigation'
    },
    {
      key: 'a',
      ctrlKey: true,
      action: handleGoAssessments,
      description: 'Go to assessments',
      category: 'Navigation'
    },
    {
      key: 'e',
      ctrlKey: true,
      action: handleGoAnalytics,
      description: 'Go to analytics',
      category: 'Navigation'
    },
    {
      key: 'F1',
      action: handleShowHelp,
      description: 'Show keyboard shortcuts help',
      category: 'Help'
    },
    {
      key: '?',
      shiftKey: true,
      action: handleShowHelp,
      description: 'Show keyboard shortcuts help',
      category: 'Help'
    }
  ];

  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      // Skip if user is typing in input fields
      const target = event.target as HTMLElement;
      if (target && (
        target.tagName === 'INPUT' || 
        target.tagName === 'TEXTAREA' || 
        target.contentEditable === 'true'
      )) {
        return;
      }

      for (const shortcut of shortcuts) {
        const matches = (
          event.key === shortcut.key &&
          !!event.ctrlKey === !!shortcut.ctrlKey &&
          !!event.altKey === !!shortcut.altKey &&
          !!event.shiftKey === !!shortcut.shiftKey
        );

        if (matches) {
          event.preventDefault();
          event.stopPropagation();
          shortcut.action();
          break;
        }
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [shortcuts]);

  return null;
}

// Export shortcuts for help display
export function useKeyboardShortcuts() {
  const t = useTranslation();
  
  return [
    {
      key: 'Alt + M',
      description: t.a11y.skipToContent,
      category: 'Navigation'
    },
    {
      key: 'Alt + S',
      description: t.a11y.menuToggle,
      category: 'Navigation'
    },
    {
      key: 'Ctrl + H',
      description: t.nav.dashboard,
      category: 'Navigation'
    },
    {
      key: 'Ctrl + A',
      description: t.nav.assessments,
      category: 'Navigation'
    },
    {
      key: 'Ctrl + E',
      description: t.nav.analytics,
      category: 'Navigation'
    },
    {
      key: 'F1 or Shift + ?',
      description: 'Show keyboard shortcuts help',
      category: 'Help'
    }
  ];
}