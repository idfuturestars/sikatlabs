import React from 'react';
import { useTranslation } from '@/i18n/i18nContext';

export function SkipLink() {
  const t = useTranslation();

  return (
    <a
      href="#main-content"
      className="sr-only focus:not-sr-only focus:absolute focus:top-4 focus:left-4 focus:z-50 focus:px-4 focus:py-2 focus:bg-primary focus:text-primary-foreground focus:rounded-md focus:font-medium focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2"
      data-testid="skip-link"
    >
      {t.common.accessibility.skipToContent}
    </a>
  );
}