import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { AccessibilityAnnouncer } from './AccessibilityAnnouncer';
import { GlobalKeyboardShortcuts } from './GlobalKeyboardShortcuts';
import { SkipLink } from './SkipLink';

interface AccessibilityContextType {
  announceMessage: (message: string, priority?: 'polite' | 'assertive') => void;
  highContrast: boolean;
  setHighContrast: (enabled: boolean) => void;
  reducedMotion: boolean;
  setReducedMotion: (enabled: boolean) => void;
  fontSize: 'normal' | 'large' | 'extra-large';
  setFontSize: (size: 'normal' | 'large' | 'extra-large') => void;
}

const AccessibilityContext = createContext<AccessibilityContextType | undefined>(undefined);

export function AccessibilityProvider({ children }: { children: ReactNode }) {
  const [announceMessage, setAnnounceMessage] = useState<string>('');
  const [announcePriority, setAnnouncePriority] = useState<'polite' | 'assertive'>('polite');
  const [highContrast, setHighContrast] = useState(false);
  const [reducedMotion, setReducedMotion] = useState(false);
  const [fontSize, setFontSize] = useState<'normal' | 'large' | 'extra-large'>('normal');

  // Load accessibility preferences from localStorage
  useEffect(() => {
    const savedHighContrast = localStorage.getItem('eiq-high-contrast') === 'true';
    const savedReducedMotion = localStorage.getItem('eiq-reduced-motion') === 'true';
    const savedFontSize = localStorage.getItem('eiq-font-size') as 'normal' | 'large' | 'extra-large' || 'normal';
    
    setHighContrast(savedHighContrast);
    setReducedMotion(savedReducedMotion);
    setFontSize(savedFontSize);

    // Respect user's system preferences
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const prefersHighContrast = window.matchMedia('(prefers-contrast: high)').matches;
    
    if (prefersReducedMotion && !savedReducedMotion) {
      setReducedMotion(true);
    }
    if (prefersHighContrast && !savedHighContrast) {
      setHighContrast(true);
    }
  }, []);

  // Apply accessibility settings to document
  useEffect(() => {
    document.documentElement.classList.toggle('high-contrast', highContrast);
    document.documentElement.classList.toggle('reduced-motion', reducedMotion);
    document.documentElement.classList.remove('font-normal', 'font-large', 'font-extra-large');
    document.documentElement.classList.add(`font-${fontSize}`);

    localStorage.setItem('eiq-high-contrast', highContrast.toString());
    localStorage.setItem('eiq-reduced-motion', reducedMotion.toString());
    localStorage.setItem('eiq-font-size', fontSize);
  }, [highContrast, reducedMotion, fontSize]);

  const handleAnnounceMessage = (message: string, priority: 'polite' | 'assertive' = 'polite') => {
    setAnnounceMessage(''); // Clear previous message
    setTimeout(() => {
      setAnnounceMessage(message);
      setAnnouncePriority(priority);
    }, 100);
  };

  const value: AccessibilityContextType = {
    announceMessage: handleAnnounceMessage,
    highContrast,
    setHighContrast,
    reducedMotion,
    setReducedMotion,
    fontSize,
    setFontSize
  };

  return (
    <AccessibilityContext.Provider value={value}>
      <SkipLink />
      <GlobalKeyboardShortcuts />
      <AccessibilityAnnouncer 
        message={announceMessage} 
        priority={announcePriority}
        clearAfter={5000}
      />
      {children}
    </AccessibilityContext.Provider>
  );
}

export function useAccessibility() {
  const context = useContext(AccessibilityContext);
  if (context === undefined) {
    throw new Error('useAccessibility must be used within an AccessibilityProvider');
  }
  return context;
}