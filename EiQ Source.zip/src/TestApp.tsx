import { Router, Route, Switch } from "wouter";

export default function TestApp() {
  return (
    <div className="min-h-screen bg-gray-900 text-white p-8">
      <h1 className="text-4xl font-bold mb-8">EiQ™ Platform Test</h1>
      <Router>
        <Switch>
          <Route path="/" component={() => <div>Home - Navigation Test</div>} />
          <Route component={() => <div>404 Not Found</div>} />
        </Switch>
      </Router>
    </div>
  );
}