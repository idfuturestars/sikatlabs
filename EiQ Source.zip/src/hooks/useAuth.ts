import { useQuery } from "@tanstack/react-query";

export function useAuth() {
  const { data: user, isLoading, error } = useQuery({
    queryKey: ["/api/auth/user"],
    retry: false,
    refetchOnMount: false,
    refetchOnWindowFocus: false,
    refetchOnReconnect: false,
    staleTime: Infinity,
    // Circuit breaker: if we get 401, consider it resolved (not authenticated)
    queryFn: async () => {
      try {
        // Check for JWT token in localStorage
        const token = localStorage.getItem('auth_token');
        
        const headers: HeadersInit = {
          'Content-Type': 'application/json',
        };
        
        // Add Authorization header if token exists
        if (token) {
          headers['Authorization'] = `Bearer ${token}`;
        }
        
        const response = await fetch("/api/auth/user", {
          credentials: "include",
          headers,
        });
        
        // If 401, user is not authenticated - return null instead of throwing
        if (response.status === 401) {
          // Remove invalid token
          localStorage.removeItem('auth_token');
          return null;
        }
        
        if (!response.ok) {
          throw new Error(`${response.status}: ${response.statusText}`);
        }
        
        const data = await response.json();
        // Handle the API response structure {success: true, user: {...}}
        return data.success ? data.user : null;
      } catch (error) {
        // Handle network errors gracefully
        console.error('Auth check failed:', error);
        // Clean up invalid tokens
        localStorage.removeItem('auth_token');
        return null;
      }
    },
  });

  return {
    user,
    isLoading,
    isAuthenticated: !!user && !error,
  };
}