/**
 * ES Module Wouter Router Mocks
 * Proper ES module exports for wouter router components
 */

import { ReactNode } from 'react';

export const useLocation = jest.fn(() => ['/', jest.fn()]);
export const useRoute = jest.fn(() => [true, {}]);
export const useRouter = jest.fn(() => ({ 
  navigate: jest.fn(),
  location: '/' 
}));

export const Link = ({ 
  children, 
  to, 
  href, 
  ...props 
}: { 
  children: ReactNode;
  to?: string; 
  href?: string;
  [key: string]: any;
}) => (
  <a href={to || href} {...props} data-testid="router-link">
    {children}
  </a>
);

export const Route = ({ 
  path,
  component: Component, 
  children 
}: { 
  path?: string;
  component?: any;
  children?: ReactNode;
}) => {
  if (Component) {
    return <Component data-testid="router-route" />;
  }
  return <div data-testid="router-route">{children}</div>;
};

export const Switch = ({ children }: { children: ReactNode }) => (
  <div data-testid="router-switch">{children}</div>
);

export const Router = ({ 
  children, 
  base 
}: { 
  children: ReactNode; 
  base?: string;
}) => (
  <div data-testid="router-wrapper" data-base={base}>
    {children}
  </div>
);

export const Redirect = ({ to }: { to: string }) => (
  <div data-testid="router-redirect" data-to={to} />
);

// Default export for backward compatibility
export default {
  useLocation,
  useRoute,
  useRouter,
  Link,
  Route,
  Switch,
  Router,
  Redirect
};