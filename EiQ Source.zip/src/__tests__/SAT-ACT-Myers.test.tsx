import { render, screen, waitFor } from '@testing-library/react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import SATACTMyers from '../pages/SAT-ACT-Myers';

// Mock the useAuth hook
const mockUseAuth = jest.fn();
jest.mock('../hooks/useAuth', () => ({
  useAuth: () => mockUseAuth()
}));

// Mock useQuery hook for assessment data
const mockUseQuery = jest.fn();
jest.mock('@tanstack/react-query', () => ({
  ...jest.requireActual('@tanstack/react-query'),
  useQuery: () => mockUseQuery(),
  useMutation: () => ({
    mutate: jest.fn(),
    isPending: false,
    isSuccess: false,
    error: null
  })
}));

// Mock wouter
jest.mock('wouter', () => ({
  useLocation: () => ['/', jest.fn()],
  Link: ({ children, ...props }: any) => <a {...props}>{children}</a>
}));

// Mock chart components
jest.mock('recharts', () => ({
  PieChart: ({ children }: any) => <div data-testid="pie-chart">{children}</div>,
  Pie: () => <div data-testid="pie" />,
  Cell: () => <div data-testid="cell" />,
  BarChart: ({ children }: any) => <div data-testid="bar-chart">{children}</div>,
  Bar: () => <div data-testid="bar" />,
  XAxis: () => <div data-testid="x-axis" />,
  YAxis: () => <div data-testid="y-axis" />,
  CartesianGrid: () => <div data-testid="cartesian-grid" />,
  Tooltip: () => <div data-testid="tooltip" />,
  ResponsiveContainer: ({ children }: any) => <div data-testid="responsive-container">{children}</div>
}));

const createTestQueryClient = () => {
  return new QueryClient({
    defaultOptions: {
      queries: {
        retry: false,
        staleTime: Infinity,
      },
    },
  });
};

describe('SAT/ACT/Myers Assessment Dashboard', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    
    mockUseAuth.mockReturnValue({
      user: { id: '1', email: 'test@example.com', username: 'testuser' },
      isLoading: false,
      isAuthenticated: true
    });
    
    mockUseQuery.mockReturnValue({
      data: {
        satScore: 1450,
        actScore: 32,
        myersType: 'INTJ',
        recentTests: [
          { id: 1, type: 'SAT', score: 1450, date: '2025-01-15' },
          { id: 2, type: 'ACT', score: 32, date: '2025-01-14' }
        ],
        personalityTraits: {
          extraversion: 45,
          agreeableness: 78,
          conscientiousness: 89,
          neuroticism: 23,
          openness: 92
        }
      },
      isLoading: false,
      error: null,
      refetch: jest.fn()
    });
  });

  test('renders assessment center with SAT/ACT scores', async () => {
    const queryClient = createTestQueryClient();
    
    render(
      <QueryClientProvider client={queryClient}>
        <SATACTMyers />
      </QueryClientProvider>
    );
    
    await waitFor(() => {
      expect(screen.getByText(/Assessment.*Center/i)).toBeInTheDocument();
    });
    
    // Check for SAT score display
    expect(screen.getByText(/1450/)).toBeInTheDocument();
    // Check for ACT score display
    expect(screen.getByText(/32/)).toBeInTheDocument();
  });

  test('displays Myers-Briggs personality type', async () => {
    const queryClient = createTestQueryClient();
    
    render(
      <QueryClientProvider client={queryClient}>
        <SATACTMyers />
      </QueryClientProvider>
    );
    
    await waitFor(() => {
      expect(screen.getByText(/INTJ/i)).toBeInTheDocument();
    });
  });

  test('shows loading state appropriately', async () => {
    const queryClient = createTestQueryClient();
    
    mockUseQuery.mockReturnValue({
      data: null,
      isLoading: true,
      error: null,
      refetch: jest.fn()
    });

    render(
      <QueryClientProvider client={queryClient}>
        <SATACTMyers />
      </QueryClientProvider>
    );
    
    expect(document.querySelectorAll('.animate-pulse, .animate-spin').length).toBeGreaterThan(0);
  });
});