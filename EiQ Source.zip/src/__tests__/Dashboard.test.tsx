import { render, screen, waitFor } from '@testing-library/react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import AIImmersionAssessment from '../pages/AI-Immersion-Assessment';
import { useQuery } from '@tanstack/react-query';

// Mock the useAuth hook with more comprehensive mocking
const mockUseAuth = jest.fn();
jest.mock('../hooks/useAuth', () => ({
  useAuth: () => mockUseAuth()
}));

// Mock useQuery hook for better async testing
const mockUseQuery = jest.fn();
jest.mock('@tanstack/react-query', () => ({
  ...jest.requireActual('@tanstack/react-query'),
  useQuery: () => mockUseQuery(),
  useMutation: () => ({
    mutate: jest.fn(),
    isPending: false,
    isSuccess: false,
    error: null
  })
}));

// Mock the specific queries we need

// Mock wouter
jest.mock('wouter', () => ({
  useLocation: () => ['/', jest.fn()],
  Link: ({ children, ...props }: any) => <a {...props}>{children}</a>
}));

// Mock various chart components that might cause issues
jest.mock('recharts', () => ({
  LineChart: ({ children }: any) => <div data-testid="line-chart">{children}</div>,
  Line: () => <div data-testid="line" />,
  XAxis: () => <div data-testid="x-axis" />,
  YAxis: () => <div data-testid="y-axis" />,
  CartesianGrid: () => <div data-testid="cartesian-grid" />,
  Tooltip: () => <div data-testid="tooltip" />,
  ResponsiveContainer: ({ children }: any) => <div data-testid="responsive-container">{children}</div>
}));

// Enhanced fetch mock with realistic API responses
global.fetch = jest.fn(() =>
  Promise.resolve({
    ok: true,
    status: 200,
    json: () => Promise.resolve({
      success: true,
      data: {
        eiqScore: 785,
        assessmentProgress: 75,
        recentAssessments: [
          { id: 1, type: 'IQ Assessment', score: 85, date: '2025-01-15' },
          { id: 2, type: 'Personality Assessment', score: 78, date: '2025-01-14' }
        ],
        learningPath: { currentLevel: 'Advanced', nextMilestone: 'Expert' }
      }
    }),
  } as Response)
);

const createTestQueryClient = () => {
  return new QueryClient({
    defaultOptions: {
      queries: {
        retry: false,
        staleTime: Infinity,
      },
    },
  });
};

describe('AI Immersion Assessment Dashboard', () => {
  beforeEach(() => {
    // Reset all mocks before each test
    jest.clearAllMocks();
    
    // Default auth state
    mockUseAuth.mockReturnValue({
      user: { id: '1', email: 'test@example.com', username: 'testuser' },
      isLoading: false,
      isAuthenticated: true
    });
    
    // Default query state
    mockUseQuery.mockReturnValue({
      data: {
        eiqScore: 785,
        assessmentProgress: 75,
        recentAssessments: [
          { id: 1, type: 'IQ Assessment', score: 85, date: '2025-01-15' }
        ]
      },
      isLoading: false,
      error: null,
      refetch: jest.fn()
    });
  });

  test('renders dashboard with EIQ score and assessment data', async () => {
    const queryClient = createTestQueryClient();
    
    render(
      <QueryClientProvider client={queryClient}>
        <AIImmersionAssessment />
      </QueryClientProvider>
    );
    
    // Wait for component to load and check for key elements
    await waitFor(() => {
      expect(screen.getByText(/EIQ.*Score/i)).toBeInTheDocument();
    }, { timeout: 3000 });
    
    // Verify EIQ score is displayed
    expect(screen.getByText(/785/)).toBeInTheDocument();
  });

  test('shows loading state when auth is loading', async () => {
    const queryClient = createTestQueryClient();
    
    // Mock loading auth state
    mockUseAuth.mockReturnValue({
      user: null,
      isLoading: true,
      isAuthenticated: false
    });

    render(
      <QueryClientProvider client={queryClient}>
        <AIImmersionAssessment />
      </QueryClientProvider>
    );
    
    // Should show loading spinner
    expect(document.querySelector('.animate-spin')).toBeInTheDocument();
  });

  test('shows loading state when queries are loading', async () => {
    const queryClient = createTestQueryClient();
    
    // Mock loading query state
    mockUseQuery.mockReturnValue({
      data: null,
      isLoading: true,
      error: null,
      refetch: jest.fn()
    });

    render(
      <QueryClientProvider client={queryClient}>
        <AIImmersionAssessment />
      </QueryClientProvider>
    );
    
    // Should show loading indicators
    expect(document.querySelectorAll('.animate-pulse').length).toBeGreaterThan(0);
  });

  test('handles error states gracefully', async () => {
    const queryClient = createTestQueryClient();
    
    // Mock error state
    mockUseQuery.mockReturnValue({
      data: null,
      isLoading: false,
      error: new Error('Failed to fetch assessment data'),
      refetch: jest.fn()
    });

    render(
      <QueryClientProvider client={queryClient}>
        <AIImmersionAssessment />
      </QueryClientProvider>
    );
    
    // Should show error message or fallback content
    await waitFor(() => {
      expect(screen.getByText(/error/i) || screen.getByText(/failed/i) || screen.getByText(/unavailable/i)).toBeInTheDocument();
    });
  });
});