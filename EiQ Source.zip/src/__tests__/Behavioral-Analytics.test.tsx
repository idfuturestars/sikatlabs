import { render, screen, waitFor } from '@testing-library/react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import BehavioralAnalytics from '../pages/Behavioral-Analytics';

const mockUseAuth = jest.fn();
jest.mock('../hooks/useAuth', () => ({
  useAuth: () => mockUseAuth()
}));

const mockUseQuery = jest.fn();
jest.mock('@tanstack/react-query', () => ({
  ...jest.requireActual('@tanstack/react-query'),
  useQuery: () => mockUseQuery(),
  useMutation: () => ({
    mutate: jest.fn(),
    isPending: false,
    isSuccess: false,
    error: null
  })
}));

jest.mock('wouter', () => ({
  useLocation: () => ['/', jest.fn()],
  Link: ({ children, ...props }: any) => <a {...props}>{children}</a>
}));

jest.mock('recharts', () => ({
  LineChart: ({ children }: any) => <div data-testid="line-chart">{children}</div>,
  Line: () => <div data-testid="line" />,
  AreaChart: ({ children }: any) => <div data-testid="area-chart">{children}</div>,
  Area: () => <div data-testid="area" />,
  ScatterChart: ({ children }: any) => <div data-testid="scatter-chart">{children}</div>,
  Scatter: () => <div data-testid="scatter" />,
  XAxis: () => <div data-testid="x-axis" />,
  YAxis: () => <div data-testid="y-axis" />,
  CartesianGrid: () => <div data-testid="cartesian-grid" />,
  Tooltip: () => <div data-testid="tooltip" />,
  ResponsiveContainer: ({ children }: any) => <div data-testid="responsive-container">{children}</div>
}));

const createTestQueryClient = () => {
  return new QueryClient({
    defaultOptions: {
      queries: {
        retry: false,
        staleTime: Infinity,
      },
    },
  });
};

describe('Behavioral Analytics Dashboard', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    
    mockUseAuth.mockReturnValue({
      user: { id: '1', email: 'test@example.com', username: 'testuser' },
      isLoading: false,
      isAuthenticated: true
    });
    
    mockUseQuery.mockReturnValue({
      data: {
        behavioralPatterns: {
          learningStyle: 'Visual-Kinesthetic',
          engagementLevel: 78,
          preferredDifficulty: 'Advanced',
          averageSessionTime: 45
        },
        predictiveModels: {
          nextSkillPrediction: 'Advanced Mathematics',
          improvementAreas: ['Time Management', 'Critical Thinking'],
          learningVelocity: 1.2,
          masteryProbability: 85
        },
        mlInsights: [
          {
            category: 'Learning Patterns',
            insight: 'User shows strong visual learning preference',
            confidence: 92,
            recommendation: 'Increase visual content by 25%'
          }
        ],
        analytics: {
          sessionsCompleted: 156,
          averageAccuracy: 84,
          timeSpentLearning: 2340,
          skillsImproved: 23
        }
      },
      isLoading: false,
      error: null,
      refetch: jest.fn()
    });
  });

  test('renders behavioral analytics dashboard', async () => {
    const queryClient = createTestQueryClient();
    
    render(
      <QueryClientProvider client={queryClient}>
        <BehavioralAnalytics />
      </QueryClientProvider>
    );
    
    await waitFor(() => {
      expect(screen.getByText(/Behavioral.*Analytics/i)).toBeInTheDocument();
    });
  });

  test('displays learning patterns and insights', async () => {
    const queryClient = createTestQueryClient();
    
    render(
      <QueryClientProvider client={queryClient}>
        <BehavioralAnalytics />
      </QueryClientProvider>
    );
    
    await waitFor(() => {
      expect(screen.getByText(/Visual-Kinesthetic/i)).toBeInTheDocument();
      expect(screen.getByText(/78/)).toBeInTheDocument(); // Engagement level
    });
  });

  test('shows ML-powered predictions', async () => {
    const queryClient = createTestQueryClient();
    
    render(
      <QueryClientProvider client={queryClient}>
        <BehavioralAnalytics />
      </QueryClientProvider>
    );
    
    await waitFor(() => {
      expect(screen.getByText(/Advanced Mathematics/i)).toBeInTheDocument();
      expect(screen.getByText(/85/)).toBeInTheDocument(); // Mastery probability
    });
  });

  test('displays analytics metrics', async () => {
    const queryClient = createTestQueryClient();
    
    render(
      <QueryClientProvider client={queryClient}>
        <BehavioralAnalytics />
      </QueryClientProvider>
    );
    
    await waitFor(() => {
      expect(screen.getByText(/156/)).toBeInTheDocument(); // Sessions completed
      expect(screen.getByText(/84/)).toBeInTheDocument(); // Average accuracy
    });
  });

  test('handles loading states for ML analytics', async () => {
    const queryClient = createTestQueryClient();
    
    mockUseQuery.mockReturnValue({
      data: null,
      isLoading: true,
      error: null,
      refetch: jest.fn()
    });

    render(
      <QueryClientProvider client={queryClient}>
        <BehavioralAnalytics />
      </QueryClientProvider>
    );
    
    expect(document.querySelectorAll('.animate-pulse, .animate-spin').length).toBeGreaterThan(0);
  });
});