import { render, screen } from '@testing-library/react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import Dashboard from '../pages/dashboard';

// Mock useQuery to return non-loading state
jest.mock('@tanstack/react-query', () => ({
  ...jest.requireActual('@tanstack/react-query'),
  useQuery: () => ({
    data: { completed: true }, // Mock onboarding as completed
    isLoading: false,
    error: null
  })
}));

// Mock the useAuth hook
jest.mock('../hooks/useAuth', () => ({
  useAuth: () => ({
    user: { id: '1', email: 'test@example.com', username: 'testuser' },
    isLoading: false,
    isAuthenticated: true
  })
}));

// Mock all the heavy dashboard components that might cause issues
jest.mock('../components/assessment/AssessmentEngine', () => () => <div data-testid="assessment-engine">Assessment Engine</div>);
jest.mock('../components/ai/AIAssistant', () => () => <div data-testid="ai-assistant">AI Assistant</div>);
jest.mock('../components/analytics/Analytics', () => () => <div data-testid="analytics">Analytics</div>);

const createTestQueryClient = () => {
  return new QueryClient({
    defaultOptions: {
      queries: {
        retry: false,
      },
    },
  });
};

describe('Dashboard Component', () => {
  test('renders dashboard without crashing', () => {
    const queryClient = createTestQueryClient();
    
    expect(() => {
      render(
        <QueryClientProvider client={queryClient}>
          <Dashboard />
        </QueryClientProvider>
      );
    }).not.toThrow();
    
    // Check that some element is rendered (even if loading)
    expect(document.body).toBeInTheDocument();
  });

  test('renders without errors', () => {
    const queryClient = createTestQueryClient();
    
    expect(() => {
      render(
        <QueryClientProvider client={queryClient}>
          <Dashboard />
        </QueryClientProvider>
      );
    }).not.toThrow();
  });
});