import { render, screen, waitFor } from '@testing-library/react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import AdvancedVoice from '../pages/Advanced-Voice';

const mockUseAuth = jest.fn();
jest.mock('../hooks/useAuth', () => ({
  useAuth: () => mockUseAuth()
}));

const mockUseQuery = jest.fn();
jest.mock('@tanstack/react-query', () => ({
  ...jest.requireActual('@tanstack/react-query'),
  useQuery: () => mockUseQuery(),
  useMutation: () => ({
    mutate: jest.fn(),
    isPending: false,
    isSuccess: false,
    error: null
  })
}));

jest.mock('wouter', () => ({
  useLocation: () => ['/', jest.fn()],
  Link: ({ children, ...props }: any) => <a {...props}>{children}</a>
}));

jest.mock('recharts', () => ({
  BarChart: ({ children }: any) => <div data-testid="bar-chart">{children}</div>,
  Bar: () => <div data-testid="bar" />,
  RadarChart: ({ children }: any) => <div data-testid="radar-chart">{children}</div>,
  Radar: () => <div data-testid="radar" />,
  PolarGrid: () => <div data-testid="polar-grid" />,
  PolarAngleAxis: () => <div data-testid="polar-angle-axis" />,
  PolarRadiusAxis: () => <div data-testid="polar-radius-axis" />,
  XAxis: () => <div data-testid="x-axis" />,
  YAxis: () => <div data-testid="y-axis" />,
  CartesianGrid: () => <div data-testid="cartesian-grid" />,
  Tooltip: () => <div data-testid="tooltip" />,
  ResponsiveContainer: ({ children }: any) => <div data-testid="responsive-container">{children}</div>
}));

// Mock Web APIs that don't exist in test environment
Object.defineProperty(window, 'MediaRecorder', {
  writable: true,
  value: jest.fn().mockImplementation(() => ({
    start: jest.fn(),
    stop: jest.fn(),
    addEventListener: jest.fn(),
    removeEventListener: jest.fn(),
    state: 'inactive'
  }))
});

Object.defineProperty(navigator, 'mediaDevices', {
  writable: true,
  value: {
    getUserMedia: jest.fn().mockResolvedValue({
      getTracks: () => [{ stop: jest.fn() }]
    })
  }
});

const createTestQueryClient = () => {
  return new QueryClient({
    defaultOptions: {
      queries: {
        retry: false,
        staleTime: Infinity,
      },
    },
  });
};

describe('Advanced Voice & Turing Test Dashboard', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    
    mockUseAuth.mockReturnValue({
      user: { id: '1', email: 'test@example.com', username: 'testuser' },
      isLoading: false,
      isAuthenticated: true
    });
    
    mockUseQuery.mockReturnValue({
      data: {
        voiceAnalysis: [
          {
            id: '1',
            transcript: 'This is a test recording for voice analysis',
            confidence: 92,
            duration: 45,
            aiAnalysis: {
              clarity: 85,
              pace: 78,
              vocabulary: 90,
              grammar: 88,
              overallScore: 85
            }
          }
        ],
        turingResults: [
          {
            id: '1',
            testType: 'Generation',
            score: 78,
            accuracy: 82,
            completionTime: 180
          }
        ],
        languageSupport: ['English', 'Spanish', 'French', 'German', 'Japanese']
      },
      isLoading: false,
      error: null,
      refetch: jest.fn()
    });
  });

  test('renders voice analysis interface', async () => {
    const queryClient = createTestQueryClient();
    
    render(
      <QueryClientProvider client={queryClient}>
        <AdvancedVoice />
      </QueryClientProvider>
    );
    
    await waitFor(() => {
      expect(screen.getByText(/Voice.*Analysis/i)).toBeInTheDocument();
    });
    
    // Check for recording interface elements
    expect(screen.getByText(/Start Recording/i) || screen.getByRole('button', { name: /record/i })).toBeInTheDocument();
  });

  test('displays Turing test results', async () => {
    const queryClient = createTestQueryClient();
    
    render(
      <QueryClientProvider client={queryClient}>
        <AdvancedVoice />
      </QueryClientProvider>
    );
    
    await waitFor(() => {
      expect(screen.getByText(/Turing.*Test/i)).toBeInTheDocument();
    });
    
    // Check for test results
    expect(screen.getByText(/78/)).toBeInTheDocument(); // Score
  });

  test('shows multi-language support', async () => {
    const queryClient = createTestQueryClient();
    
    render(
      <QueryClientProvider client={queryClient}>
        <AdvancedVoice />
      </QueryClientProvider>
    );
    
    await waitFor(() => {
      expect(screen.getByText(/Language/i)).toBeInTheDocument();
    });
    
    // Check for language options
    expect(screen.getByText(/English/i)).toBeInTheDocument();
  });

  test('handles recording state management', async () => {
    const queryClient = createTestQueryClient();
    
    render(
      <QueryClientProvider client={queryClient}>
        <AdvancedVoice />
      </QueryClientProvider>
    );
    
    // Component should render without MediaRecorder errors
    await waitFor(() => {
      expect(screen.getByText(/Voice.*Analysis/i)).toBeInTheDocument();
    });
  });
});