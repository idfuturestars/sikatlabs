import { render, screen, waitFor } from '@testing-library/react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import MultiAIProviders from '../pages/Multi-AI-Providers';

const mockUseAuth = jest.fn();
jest.mock('../hooks/useAuth', () => ({
  useAuth: () => mockUseAuth()
}));

const mockUseQuery = jest.fn();
jest.mock('@tanstack/react-query', () => ({
  ...jest.requireActual('@tanstack/react-query'),
  useQuery: () => mockUseQuery(),
  useMutation: () => ({
    mutate: jest.fn(),
    isPending: false,
    isSuccess: false,
    error: null
  })
}));

jest.mock('wouter', () => ({
  useLocation: () => ['/', jest.fn()],
  Link: ({ children, ...props }: any) => <a {...props}>{children}</a>
}));

jest.mock('recharts', () => ({
  LineChart: ({ children }: any) => <div data-testid="line-chart">{children}</div>,
  Line: () => <div data-testid="line" />,
  AreaChart: ({ children }: any) => <div data-testid="area-chart">{children}</div>,
  Area: () => <div data-testid="area" />,
  XAxis: () => <div data-testid="x-axis" />,
  YAxis: () => <div data-testid="y-axis" />,
  CartesianGrid: () => <div data-testid="cartesian-grid" />,
  Tooltip: () => <div data-testid="tooltip" />,
  ResponsiveContainer: ({ children }: any) => <div data-testid="responsive-container">{children}</div>
}));

const createTestQueryClient = () => {
  return new QueryClient({
    defaultOptions: {
      queries: {
        retry: false,
        staleTime: Infinity,
      },
    },
  });
};

describe('Multi-AI Providers Dashboard', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    
    mockUseAuth.mockReturnValue({
      user: { id: '1', email: 'test@example.com', username: 'testuser' },
      isLoading: false,
      isAuthenticated: true
    });
    
    mockUseQuery.mockReturnValue({
      data: {
        providers: [
          { name: 'OpenAI', status: 'active', usage: 85, cost: 125.50 },
          { name: 'Anthropic', status: 'active', usage: 72, cost: 98.25 },
          { name: 'Gemini', status: 'active', usage: 63, cost: 76.80 }
        ],
        usage: {
          daily: [
            { date: '2025-01-20', openai: 45, anthropic: 32, gemini: 28 },
            { date: '2025-01-21', openai: 52, anthropic: 38, gemini: 31 }
          ]
        },
        performance: {
          responseTime: 1250,
          successRate: 99.2,
          totalRequests: 15420
        }
      },
      isLoading: false,
      error: null,
      refetch: jest.fn()
    });
  });

  test('renders AI providers analytics dashboard', async () => {
    const queryClient = createTestQueryClient();
    
    render(
      <QueryClientProvider client={queryClient}>
        <MultiAIProviders />
      </QueryClientProvider>
    );
    
    await waitFor(() => {
      expect(screen.getByText(/AI.*Provider.*Analytics/i)).toBeInTheDocument();
    });
    
    // Check for provider names
    expect(screen.getByText(/OpenAI/i)).toBeInTheDocument();
    expect(screen.getByText(/Anthropic/i)).toBeInTheDocument();
    expect(screen.getByText(/Gemini/i)).toBeInTheDocument();
  });

  test('displays usage and cost metrics', async () => {
    const queryClient = createTestQueryClient();
    
    render(
      <QueryClientProvider client={queryClient}>
        <MultiAIProviders />
      </QueryClientProvider>
    );
    
    await waitFor(() => {
      // Check for cost display
      expect(screen.getByText(/125\.50/)).toBeInTheDocument();
      // Check for usage percentages
      expect(screen.getByText(/85/)).toBeInTheDocument();
    });
  });

  test('shows provider status indicators', async () => {
    const queryClient = createTestQueryClient();
    
    render(
      <QueryClientProvider client={queryClient}>
        <MultiAIProviders />
      </QueryClientProvider>
    );
    
    await waitFor(() => {
      expect(screen.getAllByText(/active/i).length).toBeGreaterThan(0);
    });
  });
});