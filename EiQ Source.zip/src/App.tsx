import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { I18nProvider } from "@/i18n/i18nContext";
import { AccessibilityProvider } from "@/components/accessibility/AccessibilityProvider";
import Dashboard from "@/pages/dashboard";
import NotFound from "@/pages/not-found";
import OnboardingWizard from "@/components/onboarding/OnboardingWizard";
import { LiveTrackingProvider } from "@/components/common/LiveTrackingProvider";
import PersonalizedWelcome from "@/components/onboarding/PersonalizedWelcome";
import K12Dashboard from "@/pages/K12Dashboard";
import HigherEducationDashboard from "@/pages/HigherEducationDashboard";
import EducationLevelSelector from "@/components/navigation/EducationLevelSelector";
import StudyCohorts from "@/pages/StudyGroups";
import AdaptiveAssessment from "@/pages/AdaptiveAssessment";
import AITutor from "@/pages/AITutor";
import SkillRecommendations from "@/pages/SkillRecommendations";
import SkillRecommendationEngine from "@/pages/SkillRecommendationEngine";
import VoiceAssessment from "@/pages/VoiceAssessment";
import IDFSAssessment from "@/pages/IDFSAssessment";
import MLAnalytics from "@/pages/MLAnalytics";
import RealTimeCollaboration from "@/pages/RealTimeCollaboration";
import AchievementsPage from "@/components/achievements/AchievementsPage";
import TracksPage from "@/pages/tracks-page";
import DemoLogin from "@/pages/demo-login";
import HintDemo from "@/pages/hint-demo";
import ChatPage from "@/pages/chat";
import StaffDashboard from "@/pages/staff-dashboard";
import AdminDashboard from "@/pages/admin-dashboard";
import PublicAPIPage from "@/pages/PublicAPIPage";
import ViralChallengePage from "@/pages/ViralChallengePage";
import MultiModalAssessment from "@/pages/multi-modal-assessment";
import SocialEIQPage from "@/pages/social-eiq";
import DeveloperPortal from "@/pages/developer-portal";
import EnhancedViralChallenge from "@/pages/enhanced-viral-challenge";
import SocialCollaboration from "@/pages/social-collaboration";
import EnhancedRoleModelMatching from "@/pages/enhanced-role-model-matching";
import AIMetaLearning from "@/pages/ai-meta-learning";
import AdminAnalyticsPage from "@/pages/admin-analytics";
import EnterpriseDashboard from "@/pages/enterprise-dashboard";
import RoleModelMatching from "@/pages/Role-Model-Matching";
import CustomQuestionsStaff from "@/pages/custom-questions-staff";
import CustomQuestionsStudent from "@/pages/custom-questions-student";
import UsernameSetup from "@/pages/username-setup";
import CheckUsername from "@/pages/check-username";
import PersonalityAssessment from "@/pages/PersonalityAssessment";
import AIAgentManagement from "@/pages/AIAgentManagement";
import TestAIImmersion from "@/pages/test-ai-immersion";
import AssessmentCenter from "@/pages/AssessmentCenter";
import EiQAnalytics from "@/pages/EiQAnalytics";
import AIFeatures from "@/pages/AIFeatures";
import LearningPaths from "@/pages/LearningPaths";
import StandardizedTests from "@/pages/StandardizedTests";
import MultiIQScoring from "@/pages/MultiIQScoring";
import DSMIntegration from "@/pages/DSMIntegration";
import QuizRoomsAI from "@/pages/QuizRoomsAI";
import EiqScoreDisplay from "@/pages/EiqScoreDisplay";
import MathTesting from "@/pages/MathTesting";

// Assessment Center Sub-sections
import SATACTMyers from "@/pages/SAT-ACT-Myers";
import AIImmersionAssessment from "@/pages/AI-Immersion-Assessment";

// EiQ Analytics Sub-sections  
import FICOScoring from "@/pages/FICO-Scoring";
import BehavioralAnalytics from "@/pages/Behavioral-Analytics";

// AI Features Sub-sections
import MultiAIProviders from "@/pages/Multi-AI-Providers";
import AdvancedVoice from "@/pages/Advanced-Voice";
import TuringTest from "@/pages/TuringTest";

import { useAuth } from "@/hooks/useAuth";
import { useEffect } from "react";
import EiQLogo from "@/components/common/EiQLogo";
import NavMenu from "@/components/nav/NavMenu";
import AppRoutes from "@/routes/AppRoutes";

// Enhanced error boundary for unhandled promise rejections
window.addEventListener('unhandledrejection', (event) => {
  console.error('Unhandled promise rejection:', event.reason);
  
  // Filter out known non-critical rejections (like network timeouts)
  const reason = event.reason?.message || event.reason;
  if (typeof reason === 'string') {
    // Don't prevent default for authentication errors (expected behavior)
    if (reason.includes('401') || reason.includes('Unauthorized')) {
      return;
    }
    // Don't prevent default for network errors during development
    if (reason.includes('NetworkError') || reason.includes('fetch')) {
      return;
    }
  }
  
  event.preventDefault();
});

// Enhanced error boundary for unhandled errors
window.addEventListener('error', (event) => {
  console.error('Unhandled error:', event.error);
});

// Clear any legacy authentication tokens on app load
if (typeof window !== 'undefined') {
  localStorage.removeItem('token');
  sessionStorage.clear();
}



function Landing() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-100 dark:from-gray-900 dark:to-green-900 flex items-center justify-center">
      <div className="max-w-md w-full bg-white dark:bg-gray-800 rounded-lg shadow-lg p-8">
        <div className="text-center">
          <div className="flex justify-center mb-6">
            <EiQLogo size="lg" variant="full" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
            Assessment Platform
          </h1>
          <p className="text-gray-600 dark:text-gray-300 mb-4">
            Powered by SikatLabs™ and IDFS Pathway™
          </p>
          <p className="text-gray-600 dark:text-gray-300 mb-8">
            Transform your potential with AI-powered assessments across all age levels.
          </p>
          <div className="space-y-3">
            <a 
              href="/login"
              className="w-full bg-green-600 hover:bg-green-700 text-white font-medium py-3 px-4 rounded-lg transition-colors duration-200 inline-block text-center"
            >
              Sign In / Get Started
            </a>
            <div className="flex gap-2">
              <a 
                href="/challenge"
                className="flex-1 bg-purple-600 hover:bg-purple-700 text-white font-medium py-2 px-3 rounded-lg transition-colors duration-200 inline-block text-center text-sm"
              >
                15s Challenge
              </a>
              <a 
                href="/api"
                className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-3 rounded-lg transition-colors duration-200 inline-block text-center text-sm"
              >
                Public API
              </a>
            </div>
          </div>
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-4">
            Supports Google, Apple, GitHub, and X sign-in
          </p>
        </div>
      </div>
    </div>
  );
}

function Router() {
  const { isAuthenticated, isLoading, user } = useAuth();

  // Handle OAuth redirects and token authentication
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const token = params.get('token');
    const provider = params.get('provider');
    const demo = params.get('demo');
    const name = params.get('name');
    const error = params.get('error');
    
    if (error) {
      console.error('OAuth error:', error);
      // Show error message and clean URL
      window.history.replaceState({}, document.title, '/login');
      return;
    }
    
    if (token) {
      console.log(`OAuth login successful with ${provider}:`, name || 'User');
      localStorage.setItem('auth_token', token);
      // Remove token from URL and redirect to dashboard
      window.history.replaceState({}, document.title, '/');
      window.location.reload();
    } else if (demo === '1') {
      // Auto-trigger demo login for unsupported OAuth providers
      console.log(`Demo login triggered for ${provider || 'unknown'} provider`);
      fetch('/api/auth/demo-token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      }).then(res => res.json()).then(data => {
        if (data.success && data.data.token) {
          localStorage.setItem('auth_token', data.data.token);
          window.history.replaceState({}, document.title, '/');
          window.location.reload();
        }
      }).catch(console.error);
    }
  }, []);

  // Show loading only while actually fetching
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-500"></div>
      </div>
    );
  }

  // Public routes that work for everyone (authenticated or not)
  return (
    <Switch>
      {/* Public routes accessible without authentication */}
      <Route path="/challenge" component={ViralChallengePage} />
      <Route path="/api" component={PublicAPIPage} />
      <Route path="/demo-login" component={DemoLogin} />
      <Route path="/login" component={DemoLogin} />
      
      {/* Authentication flow routes */}
      <Route path="/username-setup" component={UsernameSetup} />
      <Route path="/check-username" component={CheckUsername} />
      
      {/* Authenticated routes */}
      {user ? (
        // If user is authenticated but hasn't set username, redirect to username setup
        !user.usernameSet ? (
          <Route component={() => {
            window.location.href = '/username-setup';
            return null;
          }} />
        ) : (
          <div>
            {/* Navigation Menu for authenticated users */}
            <div className="border-b border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 p-4">
              <NavMenu />
            </div>
            <div className="min-h-screen bg-background">
              <Switch>
                {/* New centralized routes from AppRoutes */}
                <AppRoutes />
                {/* All existing authenticated routes */}
                <Route path="/onboarding" component={OnboardingWizard} />
            <Route path="/welcome" component={PersonalizedWelcome} />
            <Route path="/k12-dashboard" component={K12Dashboard} />
            <Route path="/higher-education" component={HigherEducationDashboard} />
            <Route path="/assessment" component={AdaptiveAssessment} />
            <Route path="/ai-tutor" component={AITutor} />
            <Route path="/skills" component={SkillRecommendations} />
            <Route path="/skill-engine" component={SkillRecommendationEngine} />
            <Route path="/voice-assessment" component={VoiceAssessment} />
            <Route path="/idfs-assessment" component={IDFSAssessment} />
            <Route path="/ml-analytics" component={MLAnalytics} />
            <Route path="/collaboration" component={RealTimeCollaboration} />
            <Route path="/study-cohorts" component={StudyCohorts} />
            <Route path="/achievements" component={AchievementsPage} />
            <Route path="/tracks" component={TracksPage} />
            <Route path="/hint-demo" component={HintDemo} />
            <Route path="/chat" component={ChatPage} />
            <Route path="/staff" component={StaffDashboard} />
            <Route path="/admin" component={AdminDashboard} />
            <Route path="/developer-portal" component={DeveloperPortal} />
            <Route path="/enhanced-challenge" component={EnhancedViralChallenge} />
            <Route path="/multi-modal" component={MultiModalAssessment} />
            <Route path="/social" component={SocialEIQPage} />
            <Route path="/social-collaboration" component={SocialCollaboration} />
            <Route path="/role-models" component={RoleModelMatching} />
            <Route path="/enhanced-role-models" component={EnhancedRoleModelMatching} />
            <Route path="/ai-meta-learning" component={AIMetaLearning} />
            <Route path="/admin-analytics" component={AdminAnalyticsPage} />
            <Route path="/enterprise" component={EnterpriseDashboard} />
            <Route path="/custom-questions-staff" component={CustomQuestionsStaff} />
            <Route path="/custom-questions-student" component={CustomQuestionsStudent} />
            <Route path="/personality-assessment" component={PersonalityAssessment} />
            <Route path="/ai-agents" component={AIAgentManagement} />
            <Route path="/assessment-center" component={AssessmentCenter} />
            <Route path="/eiq-analytics" component={EiQAnalytics} />
            <Route path="/eiq-score" component={EiqScoreDisplay} />
            <Route path="/ai-features" component={AIFeatures} />
            <Route path="/learning-paths" component={LearningPaths} />
            <Route path="/standardized-tests" component={StandardizedTests} />
            <Route path="/multi-iq-scoring" component={MultiIQScoring} />
            <Route path="/dsm-integration" component={DSMIntegration} />
            <Route path="/quiz-rooms-ai" component={QuizRoomsAI} />
            <Route path="/test-ai-immersion" component={TestAIImmersion} />
            <Route path="/math-testing" component={MathTesting} />
            <Route path="/choose-level" component={EducationLevelSelector} />
            
            {/* Assessment Center Sub-sections */}
            <Route path="/sat-act-myers" component={SATACTMyers} />
            <Route path="/ai-immersion-assessment" component={AIImmersionAssessment} />
            <Route path="/role-model-matching-new" component={RoleModelMatching} />
            
            {/* EiQ Analytics Sub-sections */}
            <Route path="/fico-scoring" component={FICOScoring} />
            <Route path="/behavioral-analytics" component={BehavioralAnalytics} />
            
            {/* AI Features Sub-sections */}
            <Route path="/multi-ai-providers" component={MultiAIProviders} />
            <Route path="/advanced-voice" component={AdvancedVoice} />
            <Route path="/turing-test" component={TuringTest} />
            <Route path="/" component={Dashboard} />
            <Route component={NotFound} />
              </Switch>
            </div>
          </div>
        )
      ) : (
        <>
          {/* Landing page for unauthenticated users */}
          <Route path="/" component={Landing} />
          <Route component={NotFound} />
        </>
      )}
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <I18nProvider>
        <AccessibilityProvider>
          <TooltipProvider>
            <div className="dark min-h-screen bg-background text-foreground">
              <main id="main-content" tabIndex={-1}>
                <Toaster />
                <Router />
              </main>
            </div>
          </TooltipProvider>
        </AccessibilityProvider>
      </I18nProvider>
    </QueryClientProvider>
  );
}

export default App;