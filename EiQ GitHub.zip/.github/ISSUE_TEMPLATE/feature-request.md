---
name: Feature Request
about: Suggest a new feature
---
**Feature Description**:  
**Problem Statement**:  
**Proposed Solution**:  
**Alternative Solutions**:  
**User Stories**:  
- As a [user type], I want [goal] so that [benefit]

**Acceptance Criteria**:  
- [ ] 
- [ ] 

**Priority**: Low | Medium | High | Critical  
**Effort**: Small | Medium | Large