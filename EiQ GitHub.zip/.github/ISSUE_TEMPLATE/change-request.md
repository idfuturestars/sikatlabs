---
name: Change Request
about: Propose a change
---
**Type**: Feature | Enhancement | UI/UX | Integration | Docs  
**Summary**:  
**Expected Outcome**:  
**Impact/Risks**:  
**Tasks/ETA**: