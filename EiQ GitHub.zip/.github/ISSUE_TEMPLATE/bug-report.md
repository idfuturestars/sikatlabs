---
name: Bug Report
about: Report a bug or issue
---
**Bug Description**:  
**Steps to Reproduce**:  
1. 
2. 
3. 

**Expected Behavior**:  
**Actual Behavior**:  
**Environment**:  
- Browser/OS:
- Version:

**Screenshots/Logs**:  
**Priority**: Low | Medium | High | Critical