#!/usr/bin/env node

/**
 * EiQ™ Platform Rollback Script
 * Automated rollback functionality for deployments
 */

const { exec, spawn } = require('child_process');
const fs = require('fs');
const path = require('path');

class RollbackManager {
  constructor() {
    this.config = {
      environments: ['staging', 'production'],
      maxRollbackHistory: 10,
      rollbackTimeout: 300000, // 5 minutes
      healthCheckRetries: 30,
      healthCheckInterval: 10000, // 10 seconds
    };
    
    this.rollbackHistory = this.loadRollbackHistory();
  }

  loadRollbackHistory() {
    try {
      const historyPath = path.join(__dirname, '../data/rollback-history.json');
      if (fs.existsSync(historyPath)) {
        return JSON.parse(fs.readFileSync(historyPath, 'utf8'));
      }
    } catch (error) {
      console.warn('⚠️ Could not load rollback history:', error.message);
    }
    return {};
  }

  saveRollbackHistory() {
    try {
      const historyPath = path.join(__dirname, '../data/rollback-history.json');
      const dir = path.dirname(historyPath);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      fs.writeFileSync(historyPath, JSON.stringify(this.rollbackHistory, null, 2));
    } catch (error) {
      console.error('❌ Failed to save rollback history:', error.message);
    }
  }

  async executeCommand(command, options = {}) {
    return new Promise((resolve, reject) => {
      console.log(`🔧 Executing: ${command}`);
      
      const process = exec(command, {
        timeout: this.config.rollbackTimeout,
        ...options
      });

      let stdout = '';
      let stderr = '';

      process.stdout.on('data', (data) => {
        stdout += data;
        console.log(data.toString().trim());
      });

      process.stderr.on('data', (data) => {
        stderr += data;
        console.error(data.toString().trim());
      });

      process.on('close', (code) => {
        if (code === 0) {
          resolve({ stdout, stderr, code });
        } else {
          reject(new Error(`Command failed with code ${code}: ${stderr}`));
        }
      });

      process.on('error', (error) => {
        reject(error);
      });
    });
  }

  async getDeploymentHistory(environment) {
    try {
      console.log(`📋 Getting deployment history for ${environment}...`);
      
      // Get Kubernetes deployment history
      const command = `kubectl rollout history deployment/eiq-platform-${environment} -n eiq-${environment}`;
      const result = await this.executeCommand(command);
      
      // Parse deployment history
      const history = this.parseDeploymentHistory(result.stdout);
      return history;
      
    } catch (error) {
      console.error(`❌ Failed to get deployment history for ${environment}:`, error.message);
      throw error;
    }
  }

  parseDeploymentHistory(output) {
    const lines = output.split('\n');
    const deployments = [];
    
    for (const line of lines) {
      if (line.includes('REVISION')) continue;
      if (!line.trim()) continue;
      
      const match = line.match(/(\d+)\s+(.+)/);
      if (match) {
        deployments.push({
          revision: parseInt(match[1]),
          changesCause: match[2].trim(),
          timestamp: new Date() // In real implementation, parse from kubectl output
        });
      }
    }
    
    return deployments.sort((a, b) => b.revision - a.revision);
  }

  async getCurrentDeployment(environment) {
    try {
      const command = `kubectl get deployment eiq-platform-${environment} -n eiq-${environment} -o jsonpath='{.metadata.annotations.deployment\\.kubernetes\\.io/revision}'`;
      const result = await this.executeCommand(command);
      return parseInt(result.stdout.trim());
    } catch (error) {
      console.error(`❌ Failed to get current deployment revision:`, error.message);
      throw error;
    }
  }

  async performRollback(environment, targetRevision = null) {
    try {
      console.log(`🔄 Starting rollback for ${environment} environment...`);
      
      // Get current deployment info
      const currentRevision = await this.getCurrentDeployment(environment);
      console.log(`📍 Current revision: ${currentRevision}`);
      
      // If no target revision specified, rollback to previous
      if (!targetRevision) {
        targetRevision = currentRevision - 1;
        console.log(`🎯 Rolling back to previous revision: ${targetRevision}`);
      } else {
        console.log(`🎯 Rolling back to specified revision: ${targetRevision}`);
      }

      // Record rollback initiation
      const rollbackId = this.recordRollbackStart(environment, currentRevision, targetRevision);
      
      // Perform the rollback
      await this.executeRollback(environment, targetRevision);
      
      // Verify rollback success
      const success = await this.verifyRollback(environment, rollbackId);
      
      if (success) {
        this.recordRollbackSuccess(rollbackId);
        console.log(`✅ Rollback completed successfully for ${environment}`);
        return { success: true, rollbackId };
      } else {
        this.recordRollbackFailure(rollbackId, 'Health check failed');
        throw new Error('Rollback verification failed');
      }
      
    } catch (error) {
      console.error(`❌ Rollback failed for ${environment}:`, error.message);
      await this.handleRollbackFailure(environment, error);
      throw error;
    }
  }

  recordRollbackStart(environment, fromRevision, toRevision) {
    const rollbackId = `rollback-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    
    if (!this.rollbackHistory[environment]) {
      this.rollbackHistory[environment] = [];
    }
    
    const rollbackRecord = {
      id: rollbackId,
      environment,
      fromRevision,
      toRevision,
      status: 'in_progress',
      startedAt: new Date().toISOString(),
      initiatedBy: process.env.USER || 'system',
    };
    
    this.rollbackHistory[environment].unshift(rollbackRecord);
    
    // Keep only last N rollbacks
    if (this.rollbackHistory[environment].length > this.config.maxRollbackHistory) {
      this.rollbackHistory[environment] = this.rollbackHistory[environment].slice(0, this.config.maxRollbackHistory);
    }
    
    this.saveRollbackHistory();
    return rollbackId;
  }

  async executeRollback(environment, targetRevision) {
    try {
      console.log(`🚀 Executing rollback to revision ${targetRevision}...`);
      
      // Kubernetes rollback command
      const command = `kubectl rollout undo deployment/eiq-platform-${environment} --to-revision=${targetRevision} -n eiq-${environment}`;
      await this.executeCommand(command);
      
      // Wait for rollout to complete
      console.log(`⏳ Waiting for rollback to complete...`);
      const waitCommand = `kubectl rollout status deployment/eiq-platform-${environment} -n eiq-${environment} --timeout=300s`;
      await this.executeCommand(waitCommand);
      
      console.log(`✅ Rollback deployment completed`);
      
    } catch (error) {
      console.error(`❌ Failed to execute rollback:`, error.message);
      throw error;
    }
  }

  async verifyRollback(environment, rollbackId) {
    try {
      console.log(`🔍 Verifying rollback success for ${environment}...`);
      
      const baseUrl = environment === 'production' 
        ? 'https://eiq.sikatlabs.com'
        : 'https://staging.eiq.sikatlabs.com';
      
      // Perform health checks
      for (let attempt = 1; attempt <= this.config.healthCheckRetries; attempt++) {
        console.log(`🏥 Health check attempt ${attempt}/${this.config.healthCheckRetries}...`);
        
        try {
          // Check health endpoint
          const healthResult = await this.executeCommand(`curl -f -s ${baseUrl}/health`);
          const healthData = JSON.parse(healthResult.stdout);
          
          if (healthData.status === 'healthy') {
            console.log(`✅ Health check passed`);
            
            // Additional functional checks
            const functionalChecks = await this.performFunctionalChecks(baseUrl);
            if (functionalChecks) {
              console.log(`✅ Functional checks passed`);
              return true;
            }
          }
          
        } catch (error) {
          console.log(`❌ Health check failed: ${error.message}`);
        }
        
        if (attempt < this.config.healthCheckRetries) {
          console.log(`⏳ Waiting ${this.config.healthCheckInterval/1000}s before next attempt...`);
          await new Promise(resolve => setTimeout(resolve, this.config.healthCheckInterval));
        }
      }
      
      console.error(`❌ All health checks failed`);
      return false;
      
    } catch (error) {
      console.error(`❌ Verification failed:`, error.message);
      return false;
    }
  }

  async performFunctionalChecks(baseUrl) {
    try {
      console.log(`🧪 Performing functional checks...`);
      
      // Check critical endpoints
      const endpoints = [
        '/api/health',
        '/api/auth/user',
        '/api/assessment/types',
        '/api/eiq/current'
      ];
      
      for (const endpoint of endpoints) {
        try {
          await this.executeCommand(`curl -f -s ${baseUrl}${endpoint}`);
          console.log(`✅ ${endpoint} check passed`);
        } catch (error) {
          console.log(`❌ ${endpoint} check failed`);
          return false;
        }
      }
      
      return true;
      
    } catch (error) {
      console.error(`❌ Functional checks failed:`, error.message);
      return false;
    }
  }

  recordRollbackSuccess(rollbackId) {
    this.updateRollbackRecord(rollbackId, {
      status: 'completed',
      completedAt: new Date().toISOString()
    });
  }

  recordRollbackFailure(rollbackId, reason) {
    this.updateRollbackRecord(rollbackId, {
      status: 'failed',
      failedAt: new Date().toISOString(),
      failureReason: reason
    });
  }

  updateRollbackRecord(rollbackId, updates) {
    for (const environment in this.rollbackHistory) {
      const rollback = this.rollbackHistory[environment].find(r => r.id === rollbackId);
      if (rollback) {
        Object.assign(rollback, updates);
        this.saveRollbackHistory();
        break;
      }
    }
  }

  async handleRollbackFailure(environment, error) {
    console.error(`💥 Handling rollback failure for ${environment}:`, error.message);
    
    try {
      // Send alert notification
      await this.sendFailureAlert(environment, error);
      
      // Attempt emergency procedures if needed
      if (error.message.includes('timeout')) {
        console.log(`⚠️ Rollback timeout detected, attempting emergency recovery...`);
        await this.attemptEmergencyRecovery(environment);
      }
      
    } catch (alertError) {
      console.error(`❌ Failed to handle rollback failure:`, alertError.message);
    }
  }

  async sendFailureAlert(environment, error) {
    // Implementation would send alerts via Slack, email, etc.
    console.log(`🚨 ALERT: Rollback failed for ${environment}: ${error.message}`);
  }

  async attemptEmergencyRecovery(environment) {
    // Implementation would perform emergency recovery procedures
    console.log(`🆘 Attempting emergency recovery for ${environment}...`);
  }

  async listRollbackHistory(environment) {
    const history = this.rollbackHistory[environment] || [];
    
    console.log(`\n📚 Rollback History for ${environment}:`);
    console.log('═'.repeat(80));
    
    if (history.length === 0) {
      console.log('No rollback history found.');
      return;
    }
    
    for (const rollback of history) {
      console.log(`ID: ${rollback.id}`);
      console.log(`Status: ${rollback.status}`);
      console.log(`From Revision: ${rollback.fromRevision} → To Revision: ${rollback.toRevision}`);
      console.log(`Started: ${rollback.startedAt}`);
      console.log(`Initiated By: ${rollback.initiatedBy}`);
      if (rollback.completedAt) console.log(`Completed: ${rollback.completedAt}`);
      if (rollback.failureReason) console.log(`Failure Reason: ${rollback.failureReason}`);
      console.log('-'.repeat(40));
    }
  }
}

// CLI Interface
async function main() {
  const args = process.argv.slice(2);
  const action = args[0];
  const environment = args.find(arg => arg.startsWith('--environment='))?.split('=')[1];
  const revision = args.find(arg => arg.startsWith('--revision='))?.split('=')[1];
  
  if (!environment || !['staging', 'production'].includes(environment)) {
    console.error('❌ Please specify valid environment: --environment=staging or --environment=production');
    process.exit(1);
  }
  
  const rollbackManager = new RollbackManager();
  
  try {
    switch (action) {
      case 'rollback':
        await rollbackManager.performRollback(environment, revision ? parseInt(revision) : null);
        break;
        
      case 'history':
        await rollbackManager.listRollbackHistory(environment);
        break;
        
      case 'status':
        const deploymentHistory = await rollbackManager.getDeploymentHistory(environment);
        console.log(`Current deployments for ${environment}:`, deploymentHistory);
        break;
        
      default:
        console.log(`
EiQ™ Platform Rollback Manager

Usage:
  node rollback.js rollback --environment=<env> [--revision=<num>]
  node rollback.js history --environment=<env>
  node rollback.js status --environment=<env>

Examples:
  node rollback.js rollback --environment=staging
  node rollback.js rollback --environment=production --revision=5
  node rollback.js history --environment=production
        `);
        break;
    }
    
  } catch (error) {
    console.error('💥 Operation failed:', error.message);
    process.exit(1);
  }
}

if (require.main === module) {
  main();
}

module.exports = RollbackManager;