#!/usr/bin/env node

/**
 * EiQ™ Platform Smoke Tests
 * Critical functionality verification for post-deployment
 */

const https = require('https');
const http = require('http');

class SmokeTestSuite {
  constructor(environment = 'staging') {
    this.environment = environment;
    this.baseUrl = this.getBaseUrl(environment);
    this.testResults = [];
    this.startTime = Date.now();
  }

  getBaseUrl(env) {
    const urls = {
      staging: 'https://staging.eiq.sikatlabs.com',
      production: 'https://eiq.sikatlabs.com',
      local: 'http://localhost:5000'
    };
    return urls[env] || urls.staging;
  }

  async makeRequest(endpoint, options = {}) {
    return new Promise((resolve, reject) => {
      const url = `${this.baseUrl}${endpoint}`;
      const isHttps = url.startsWith('https');
      const client = isHttps ? https : http;
      
      const requestOptions = {
        timeout: 10000,
        headers: {
          'User-Agent': 'EiQ-SmokeTest/1.0',
          'Accept': 'application/json',
          ...options.headers
        },
        ...options
      };

      const req = client.get(url, requestOptions, (res) => {
        let data = '';
        res.on('data', chunk => data += chunk);
        res.on('end', () => {
          try {
            const parsedData = data ? JSON.parse(data) : {};
            resolve({
              status: res.statusCode,
              headers: res.headers,
              data: parsedData,
              rawData: data
            });
          } catch (error) {
            resolve({
              status: res.statusCode,
              headers: res.headers,
              data: null,
              rawData: data
            });
          }
        });
      });

      req.on('error', reject);
      req.on('timeout', () => {
        req.destroy();
        reject(new Error('Request timeout'));
      });
    });
  }

  async runTest(testName, testFunction) {
    const startTime = Date.now();
    console.log(`🧪 Running test: ${testName}`);
    
    try {
      const result = await testFunction();
      const duration = Date.now() - startTime;
      
      this.testResults.push({
        name: testName,
        status: 'PASS',
        duration,
        result
      });
      
      console.log(`✅ ${testName} - PASSED (${duration}ms)`);
      return { success: true, result };
      
    } catch (error) {
      const duration = Date.now() - startTime;
      
      this.testResults.push({
        name: testName,
        status: 'FAIL',
        duration,
        error: error.message
      });
      
      console.log(`❌ ${testName} - FAILED (${duration}ms): ${error.message}`);
      return { success: false, error: error.message };
    }
  }

  async testHealthEndpoint() {
    return this.runTest('Health Endpoint', async () => {
      const response = await this.makeRequest('/health');
      
      if (response.status !== 200) {
        throw new Error(`Health check returned status ${response.status}`);
      }
      
      if (!response.data || response.data.status !== 'healthy') {
        throw new Error('Health check returned unhealthy status');
      }
      
      return response.data;
    });
  }

  async testReadinessEndpoint() {
    return this.runTest('Readiness Endpoint', async () => {
      const response = await this.makeRequest('/ready');
      
      if (response.status !== 200) {
        throw new Error(`Readiness check returned status ${response.status}`);
      }
      
      return response.data;
    });
  }

  async testFrontendLoading() {
    return this.runTest('Frontend Loading', async () => {
      const response = await this.makeRequest('/', {
        headers: { 'Accept': 'text/html' }
      });
      
      if (response.status !== 200) {
        throw new Error(`Frontend returned status ${response.status}`);
      }
      
      if (!response.rawData.includes('EiQ')) {
        throw new Error('Frontend does not contain expected content');
      }
      
      return { loaded: true, size: response.rawData.length };
    });
  }

  async testAuthEndpoints() {
    return this.runTest('Authentication Endpoints', async () => {
      // Test login endpoint accessibility
      const loginResponse = await this.makeRequest('/api/login');
      
      // Should redirect or return 401/403, but not 500
      if (loginResponse.status >= 500) {
        throw new Error(`Login endpoint returned server error: ${loginResponse.status}`);
      }
      
      // Test user endpoint (should return 401 without auth)
      const userResponse = await this.makeRequest('/api/auth/user');
      
      if (userResponse.status !== 401 && userResponse.status !== 403) {
        throw new Error(`User endpoint should return 401/403, got ${userResponse.status}`);
      }
      
      return { loginStatus: loginResponse.status, userStatus: userResponse.status };
    });
  }

  async testAssessmentEndpoints() {
    return this.runTest('Assessment Endpoints', async () => {
      // Test assessment types endpoint
      const typesResponse = await this.makeRequest('/api/assessment/types');
      
      if (typesResponse.status !== 200) {
        throw new Error(`Assessment types returned status ${typesResponse.status}`);
      }
      
      if (!Array.isArray(typesResponse.data)) {
        throw new Error('Assessment types should return an array');
      }
      
      return { types: typesResponse.data.length };
    });
  }

  async testEiQScoringEndpoints() {
    return this.runTest('EiQ Scoring Endpoints', async () => {
      // Test scoring endpoint (may require auth, but should not 500)
      const scoringResponse = await this.makeRequest('/api/eiq/scoring/test');
      
      if (scoringResponse.status >= 500) {
        throw new Error(`EiQ scoring returned server error: ${scoringResponse.status}`);
      }
      
      return { status: scoringResponse.status };
    });
  }

  async testAIProviderEndpoints() {
    return this.runTest('AI Provider Endpoints', async () => {
      // Test AI providers status
      const providersResponse = await this.makeRequest('/api/ai-agents');
      
      if (providersResponse.status !== 200 && providersResponse.status !== 401) {
        throw new Error(`AI providers returned unexpected status: ${providersResponse.status}`);
      }
      
      return { status: providersResponse.status };
    });
  }

  async testMathTestingEndpoints() {
    return this.runTest('Math Testing Endpoints', async () => {
      // Test math problems endpoint
      const mathResponse = await this.makeRequest('/api/math/problems');
      
      if (mathResponse.status !== 200 && mathResponse.status !== 401) {
        throw new Error(`Math testing returned unexpected status: ${mathResponse.status}`);
      }
      
      return { status: mathResponse.status };
    });
  }

  async testAnalyticsEndpoints() {
    return this.runTest('Analytics Endpoints', async () => {
      // Test analytics dashboard
      const analyticsResponse = await this.makeRequest('/api/analytics/dashboard-metrics');
      
      if (analyticsResponse.status !== 200 && analyticsResponse.status !== 401) {
        throw new Error(`Analytics returned unexpected status: ${analyticsResponse.status}`);
      }
      
      return { status: analyticsResponse.status };
    });
  }

  async testDatabaseConnectivity() {
    return this.runTest('Database Connectivity', async () => {
      // Health endpoint should verify DB connectivity
      const response = await this.makeRequest('/health');
      
      if (response.data && response.data.database === false) {
        throw new Error('Database connectivity check failed');
      }
      
      return { connected: true };
    });
  }

  async testPerformanceMetrics() {
    return this.runTest('Performance Metrics', async () => {
      const startTime = Date.now();
      
      // Test multiple concurrent requests
      const promises = Array(5).fill().map(() => 
        this.makeRequest('/health')
      );
      
      const responses = await Promise.all(promises);
      const duration = Date.now() - startTime;
      
      const allSuccessful = responses.every(r => r.status === 200);
      if (!allSuccessful) {
        throw new Error('Not all concurrent requests succeeded');
      }
      
      const avgResponseTime = duration / responses.length;
      
      if (avgResponseTime > 2000) {
        throw new Error(`Average response time too high: ${avgResponseTime}ms`);
      }
      
      return { 
        concurrentRequests: responses.length,
        totalDuration: duration,
        averageResponseTime: avgResponseTime
      };
    });
  }

  async runAllTests() {
    console.log(`🚀 Starting smoke tests for ${this.environment} environment`);
    console.log(`🌐 Base URL: ${this.baseUrl}`);
    console.log('═'.repeat(80));
    
    const tests = [
      () => this.testHealthEndpoint(),
      () => this.testReadinessEndpoint(),
      () => this.testFrontendLoading(),
      () => this.testAuthEndpoints(),
      () => this.testAssessmentEndpoints(),
      () => this.testEiQScoringEndpoints(),
      () => this.testAIProviderEndpoints(),
      () => this.testMathTestingEndpoints(),
      () => this.testAnalyticsEndpoints(),
      () => this.testDatabaseConnectivity(),
      () => this.testPerformanceMetrics()
    ];

    let passedTests = 0;
    let failedTests = 0;

    for (const test of tests) {
      const result = await test();
      if (result.success) {
        passedTests++;
      } else {
        failedTests++;
      }
    }

    const totalDuration = Date.now() - this.startTime;
    
    console.log('\n' + '═'.repeat(80));
    console.log('📊 SMOKE TEST RESULTS');
    console.log('═'.repeat(80));
    console.log(`Environment: ${this.environment}`);
    console.log(`Base URL: ${this.baseUrl}`);
    console.log(`Total Duration: ${totalDuration}ms`);
    console.log(`Tests Passed: ${passedTests}`);
    console.log(`Tests Failed: ${failedTests}`);
    console.log(`Success Rate: ${Math.round((passedTests / (passedTests + failedTests)) * 100)}%`);
    
    if (failedTests > 0) {
      console.log('\n❌ FAILED TESTS:');
      this.testResults
        .filter(test => test.status === 'FAIL')
        .forEach(test => {
          console.log(`  • ${test.name}: ${test.error}`);
        });
    }
    
    // Generate report
    this.generateReport();
    
    return {
      success: failedTests === 0,
      passed: passedTests,
      failed: failedTests,
      total: passedTests + failedTests,
      duration: totalDuration
    };
  }

  generateReport() {
    const reportData = {
      environment: this.environment,
      baseUrl: this.baseUrl,
      timestamp: new Date().toISOString(),
      duration: Date.now() - this.startTime,
      results: this.testResults,
      summary: {
        total: this.testResults.length,
        passed: this.testResults.filter(t => t.status === 'PASS').length,
        failed: this.testResults.filter(t => t.status === 'FAIL').length
      }
    };

    // Save report
    const fs = require('fs');
    const reportPath = `smoke-test-report-${this.environment}-${Date.now()}.json`;
    
    try {
      fs.writeFileSync(reportPath, JSON.stringify(reportData, null, 2));
      console.log(`\n📄 Report saved: ${reportPath}`);
    } catch (error) {
      console.error('❌ Failed to save report:', error.message);
    }
  }
}

// CLI Interface
async function main() {
  const environment = process.argv.find(arg => arg.startsWith('--environment='))?.split('=')[1] || 'staging';
  
  if (!['staging', 'production', 'local'].includes(environment)) {
    console.error('❌ Invalid environment. Use: staging, production, or local');
    process.exit(1);
  }
  
  const smokeTests = new SmokeTestSuite(environment);
  
  try {
    const results = await smokeTests.runAllTests();
    
    if (results.success) {
      console.log('\n🎉 All smoke tests passed!');
      process.exit(0);
    } else {
      console.log('\n💥 Some smoke tests failed!');
      process.exit(1);
    }
    
  } catch (error) {
    console.error('💥 Smoke test suite failed:', error.message);
    process.exit(1);
  }
}

if (require.main === module) {
  main();
}

module.exports = SmokeTestSuite;