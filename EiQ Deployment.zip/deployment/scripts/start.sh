#!/bin/bash

# EiQ™ Platform Production Startup Script
# This script handles graceful startup with proper error handling and logging

set -euo pipefail

# Environment validation
echo "🚀 Starting EiQ™ Platform..."
echo "Environment: ${NODE_ENV:-development}"
echo "Port: ${PORT:-5000}"
echo "Host: ${HOST:-0.0.0.0}"

# Validate required environment variables
required_vars=(
    "DATABASE_URL"
    "JWT_SECRET"
)

for var in "${required_vars[@]}"; do
    if [[ -z "${!var:-}" ]]; then
        echo "❌ Error: Required environment variable $var is not set"
        exit 1
    fi
done

echo "✅ Environment validation passed"

# Database connectivity check
echo "🔍 Checking database connectivity..."
max_retries=30
retry_count=0

while [ $retry_count -lt $max_retries ]; do
    if node -e "
        const { Pool } = require('pg');
        const pool = new Pool({ connectionString: process.env.DATABASE_URL });
        pool.query('SELECT 1')
            .then(() => { console.log('✅ Database connection successful'); process.exit(0); })
            .catch((err) => { console.error('❌ Database connection failed:', err.message); process.exit(1); });
    "; then
        echo "✅ Database is ready"
        break
    else
        retry_count=$((retry_count + 1))
        echo "⏳ Database not ready, retrying in 5 seconds... ($retry_count/$max_retries)"
        sleep 5
    fi
done

if [ $retry_count -eq $max_retries ]; then
    echo "❌ Failed to connect to database after $max_retries attempts"
    exit 1
fi

# Run database migrations if needed
echo "🔄 Running database migrations..."
if npm run db:push; then
    echo "✅ Database migrations completed"
else
    echo "❌ Database migrations failed"
    exit 1
fi

# Create necessary directories
mkdir -p /app/logs /app/temp

# Set up log rotation for production
if [[ "${NODE_ENV}" == "production" ]]; then
    echo "📝 Setting up production logging..."
    
    # Configure log rotation
    cat > /app/config/logrotate.conf << EOF
/app/logs/*.log {
    daily
    missingok
    rotate 30
    compress
    delaycompress
    notifempty
    create 644 eiq eiq
    postrotate
        /bin/kill -USR1 \$(cat /app/app.pid 2>/dev/null) 2>/dev/null || true
    endscript
}
EOF
fi

# Performance optimizations
export NODE_OPTIONS="--max-old-space-size=2048 --enable-source-maps"

# Graceful shutdown handler
cleanup() {
    echo "🛑 Received shutdown signal, gracefully shutting down..."
    if [[ -f /app/app.pid ]]; then
        kill -TERM "$(cat /app/app.pid)" 2>/dev/null || true
        wait "$(cat /app/app.pid)" 2>/dev/null || true
        rm -f /app/app.pid
    fi
    echo "✅ Shutdown complete"
    exit 0
}

# Set up signal handlers
trap cleanup SIGTERM SIGINT

# Health check endpoint validation
echo "🏥 Starting health check validation..."
start_health_check() {
    local max_attempts=60
    local attempt=0
    
    while [ $attempt -lt $max_attempts ]; do
        if curl -f -s "http://${HOST}:${PORT}/health" > /dev/null 2>&1; then
            echo "✅ Health check endpoint is responsive"
            return 0
        fi
        
        attempt=$((attempt + 1))
        echo "⏳ Waiting for health check endpoint... ($attempt/$max_attempts)"
        sleep 2
    done
    
    echo "❌ Health check endpoint failed to respond after $max_attempts attempts"
    return 1
}

# Start the application
echo "🌟 Starting EiQ™ Platform server..."

if [[ "${NODE_ENV}" == "production" ]]; then
    # Production mode with PM2 for process management
    if command -v pm2 >/dev/null 2>&1; then
        echo "🔧 Using PM2 for production process management"
        pm2 start dist/server/index.js \
            --name "eiq-platform" \
            --instances 2 \
            --max-memory-restart 1G \
            --node-args="--max-old-space-size=2048" \
            --log /app/logs/app.log \
            --error /app/logs/error.log \
            --pid /app/app.pid \
            --merge-logs \
            --time
        
        # Start health check validation in background
        start_health_check &
        
        # Keep the script running to handle signals
        pm2 logs --raw
    else
        echo "📦 Starting without PM2"
        node dist/server/index.js &
        echo $! > /app/app.pid
        
        # Start health check validation
        start_health_check
        
        # Wait for the background process
        wait
    fi
else
    # Development/staging mode
    echo "🛠️ Running in ${NODE_ENV} mode"
    node dist/server/index.js &
    echo $! > /app/app.pid
    
    # Start health check validation
    start_health_check
    
    # Wait for the background process
    wait
fi